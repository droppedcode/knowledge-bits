﻿using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Text;

namespace PerformanceProfiling
{
  public class Program
  {
    public static void Main(string[] args)
    {
      //var summary = BenchmarkRunner.Run<LinqCycle>();
      var summary = BenchmarkRunner.Run<ContainsInt>();

      Console.WriteLine("Press [ENTER] to exit...");
      Console.ReadLine();
    }
  }
}
