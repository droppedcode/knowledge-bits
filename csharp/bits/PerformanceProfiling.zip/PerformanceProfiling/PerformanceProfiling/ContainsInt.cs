﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Jobs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PerformanceProfiling
{
  [SimpleJob(RuntimeMoniker.Net472, baseline: true)]
  [MemoryDiagnoser]
  public class ContainsInt
  {
    private class HasInt
    {
      public int Value { get; set; }
    }

    [Params(10, 1000, 100000)]
    public int SearchInCount;

    private HasInt[] _searchIn;

    [Params(10, 1000, 100000)]
    public int SearchWhatCount;

    private int[] _searchWhat;

    [GlobalSetup]
    public void Setup()
    {
      var random = new Random(42);

      _searchIn = new HasInt[SearchInCount];
      
      for (var i = 0; i < SearchInCount; i++)
      {
        _searchIn[i] = new HasInt { Value = random.Next(int.MaxValue) };
      }

      _searchWhat = new int[SearchWhatCount];

      for (var i = 0; i < SearchWhatCount; i++)
      {
        _searchWhat[i] = random.Next(int.MaxValue);
      }
    }

    [Benchmark(Baseline = true)]
    public int Select()
    {
      var searchIn = _searchIn.Select(s => s.Value);

      return _searchWhat.Count(c => searchIn.Contains(c));
    }

    [Benchmark]
    public int HashSet()
    {
      var searchIn = new HashSet<int>(_searchIn.Select(s => s.Value));

      return _searchWhat.Count(c => searchIn.Contains(c));
    }

  }
}
