﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Jobs;
using System;
using System.Linq;
using System.Security.Cryptography;

namespace PerformanceProfiling
{
  [SimpleJob(RuntimeMoniker.Net472, baseline: true)]
  //[SimpleJob(RuntimeMoniker.NetCoreApp21)]
  //[SimpleJob(RuntimeMoniker.NetCoreApp30)]
  //[SimpleJob(RuntimeMoniker.CoreRt30)]
  [MemoryDiagnoser]
  public class LinqCycle
  {
    [Params(10, 1000, 10000)]
    public int _count;

    private int[] _data;

    private int _modulo = 2;

    [GlobalSetup]
    public void Setup()
    {
      _data = new int[_count];

      var random = new Random(42);
      for (var i = 0; i < _count; i++)
      {
        _data[i] = random.Next(int.MaxValue);
      }
    }

    [Benchmark(Baseline = true)]
    public int NoLinqFor()
    {
      var count = 0;
      for (var i = 0; i < _data.Length; i++)
      {
        if (_data[i] % _modulo == 0)
        {
          count++;
        }
      }
      return count;
    }

    [Benchmark]
    public int NoLinqForeach()
    {
      var count = 0;
      foreach (var value in _data)
      {
        if (value % _modulo == 0)
        {
          count++;
        }
      }
      return count;
    }

    [Benchmark]
    public int LinqCaptureThis()
    {
      return _data.Where(w => w % _modulo == 0).Count();
    }

    [Benchmark]
    public int LinqCaptureLocal()
    {
      var modulo = _modulo;

      return _data.Where(w => w % modulo == 0).Count();
    }

  }
}
