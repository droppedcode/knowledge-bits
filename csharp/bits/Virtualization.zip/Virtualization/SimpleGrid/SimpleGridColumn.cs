using Cae.Iss.InstructionEditor;
using Cae.Iss.IosControlLibrary.Controls.SimpleGrid.Converters;
using Cae.Iss.IosControlLibrary.Controls.SimpleGrid.Wrappers;
using Cae.Iss.IosControlLibrary.Helpers;
using Cae.Iss.IosControlLibrary.Resources.Localization;
using Cae.Synapse.Foundation.Toolkit;
using Cae.Synapse.Foundation.Toolkit.Extensions;
using Cae.Synapse.PageEditor.Foundation;
using Cae.Synapse.PageEditor.Foundation.Toolkit.Library;
using Cae.Synapse.PageEditor.Foundation.Toolkit.Library.Attributes;
using Microsoft.Practices.Unity;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Markup;
using System.Windows.Media;
using System.Linq;
using Cae.Iss.IosControlLibrary.Controls.LatLong;
using Cae.Synapse.PageEditor.Presentation.Helpers;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid
{
  [TypeConverter(typeof(IndentedJsonTypeConverter))]
  public class SimpleGridColumn : JsonData
  {
    private IUnityContainer mUnityContainer;

    [JsonIgnore]
    [Dependency]
    public IUnityContainer UnityContainer
    {
      get
      {
        return mUnityContainer;
      }
      set
      {
        if (mUnityContainer == value) return;

        mUnityContainer = value;

        NotifyPropertyChanged(this.NameOf(p => p.UnityContainer));
      }
    }

    private readonly static ParserContext mParserContext;

    private const double mDefaultColumnWidth = 100;

    private const string CONST_MAPPING = "";
    private const string CONST_STRING_FORMAT = "{0}";
    private const string CONST_FOREGROUND = "";

    private string mMapping;
    private string mLatitudeMapping;
    private string mLongitudeMapping;
    private string mStringFormat;
    private string mForeground;
    private double mWidth = double.NaN;
    private double mComputedWidth = double.NaN;
    private double mComputedLeft = double.NaN;
    private Style mCellStyle;
    private int mIndex;
    private Style mCellStyleBasedOn;

    private SimpleGridColumnTemplate mTemplate;
    private SimpleGridTextColumnConverter mTextConverter;
    private string mTrueText;
    private string mFalseText;
    private string mTrimBy;
    private string mXaml;
    private string mValidXaml;

    private KeyboardType mInputKeyboardType;
    private string mInputFormat;
    private string mInputUnit;

    private KeyboardType mLatLongKeyboardType;
    private string mLatLongHookCoordinate;
    private LatLongPrecisionMode mLatLongPrecisionMode;
    private string mLatLongLatitudeText;
    private string mLatLongLongitudeText;
    private string mLatLongFormat;

    private List<FrameworkElement> mUsedElements = new List<FrameworkElement>();
    private List<FrameworkElement> mElementCache = new List<FrameworkElement>();

    static SimpleGridColumn()
    {
      mParserContext = new ParserContext();

      mParserContext.XmlnsDictionary.Add("", "http://schemas.microsoft.com/winfx/2006/xaml/presentation");
      mParserContext.XmlnsDictionary.Add("x", "http://schemas.microsoft.com/winfx/2006/xaml");
      mParserContext.XmlnsDictionary.Add("system", "clr-namespace:System;assembly=mscorlib");
      mParserContext.XmlnsDictionary.Add("d", "http://schemas.microsoft.com/expression/blend/2008");
      mParserContext.XmlnsDictionary.Add("foundation", "http://schemas.cae.com/pageeditorfoundation/2013");
      mParserContext.XmlnsDictionary.Add("editor", "http://schemas.cae.com/pageeditorpresentation/2014");
      mParserContext.XmlnsDictionary.Add("ios", "clr-namespace:Cae.Iss.IosControlLibrary.Controls;assembly=" + typeof(SimpleGridColumn).Assembly.FullName);
    }

    [ControlProperty(localeKeys.cWidth, localeKeys.cWidth, false, typeof(locale))]
    [DefaultValue(double.NaN)]
    public double Width
    {
      get { return mWidth; }
      set
      {
        if (mWidth.Equals(value)) return;
        mWidth = value;
        NotifyPropertyChanged(this.NameOf(p => p.Width));
      }
    }

    [JsonIgnore]
    public double ComputedWidth
    {
      get { return mWidth != double.NaN ? mWidth : mComputedWidth; }
      set
      {
        if (mComputedWidth.Equals(value)) return;
        mComputedWidth = value;
        NotifyPropertyChanged(this.NameOf(p => p.ComputedWidth));
      }
    }

    [JsonIgnore]
    public double ComputedLeft
    {
      get { return mComputedLeft; }
      set
      {
        if (mComputedLeft.Equals(value)) return;
        mComputedLeft = value;
        NotifyPropertyChanged(this.NameOf(p => p.ComputedLeft));
      }
    }

    [JsonIgnore]
    public int Index
    {
      get { return mIndex; }
      set
      {
        if (mIndex.Equals(value)) return;
        mIndex = value;
        NotifyPropertyChanged(this.NameOf(p => p.Index));
      }
    }

    [LocalizedCategory(localeKeys.cMappingProperties, typeof(locale))]
    [ControlProperty(localeKeys.cText, localeKeys.cText, false, typeof(locale))]
    [DefaultValue(CONST_MAPPING)]
    [VisibleIf("IsLatLongInput", CompareType.EqualTo, false)]
    public string Mapping
    {
      get { return mMapping; }
      set
      {
        if (mMapping == value) return;
        mMapping = value;
        if (mCellStyle != null)
        {
          BuildCellStyle(mCellStyleBasedOn);
        }
        NotifyPropertyChanged(this.NameOf(p => p.Mapping));
      }
    }

    [LocalizedCategory(localeKeys.cMappingProperties, typeof(locale))]
    [ControlProperty(localeKeys.cTextFormat, localeKeys.cTextFormat, false, typeof(locale))]
    [DefaultValue(CONST_STRING_FORMAT)]
    public string StringFormat
    {
      get { return mStringFormat; }
      set
      {
        if (mStringFormat == value) return;
        mStringFormat = value;
        if (mCellStyle != null)
        {
          BuildCellStyle(mCellStyleBasedOn);
        }
        NotifyPropertyChanged(this.NameOf(p => p.StringFormat));
      }
    }

    [LocalizedCategory(localeKeys.cTextFormat, typeof(locale))]
    [ControlProperty(localeKeys.cColor, localeKeys.cColor, false, typeof(locale))]
    [DefaultValue(CONST_FOREGROUND)]
    public string Foreground
    {
      get { return mForeground; }
      set
      {
        if (mForeground == value) return;
        mForeground = value;
        if (mCellStyle != null)
        {
          BuildCellStyle(mCellStyleBasedOn);
        }
        NotifyPropertyChanged(this.NameOf(p => p.Foreground));
      }
    }

    [ControlProperty(localeKeys.cTemplate, localeKeys.cTemplate, false, typeof(locale))]
    [DefaultValue(SimpleGridColumnTemplate.Text)]
    [AffectsProperties]
    public SimpleGridColumnTemplate Template
    {
      get { return mTemplate; }
      set
      {
        if (mTemplate == value) return;
        mTemplate = value;
        UpdateElementType();
        NotifyPropertyChanged(this.NameOf(p => p.Template));
      }
    }

    [ControlProperty(localeKeys.cConverter, localeKeys.cConverter, false, typeof(locale))]
    [DefaultValue(SimpleGridTextColumnConverter.None)]
    [AffectsProperties]
    [VisibleIf("IsText", CompareType.EqualTo, true)]
    public SimpleGridTextColumnConverter TextConverter
    {
      get { return mTextConverter; }
      set
      {
        if (mTextConverter == value) return;
        mTextConverter = value;
        UpdateElementType();
        NotifyPropertyChanged(this.NameOf(p => p.TextConverter));
      }
    }

    [ControlProperty(localeKeys.cTrueText, localeKeys.cTrueText, false, typeof(locale))]
    [DefaultValue(localeKeys.cTrue)]
    [VisibleIf("IsBoolean", CompareType.EqualTo, true)]
    public string TrueText
    {
      get { return mTrueText; }
      set
      {
        if (mTrueText == value) return;
        mTrueText = value;
        NotifyPropertyChanged(this.NameOf(p => p.TrueText));
      }
    }

    [ControlProperty(localeKeys.cFalseText, localeKeys.cFalseText, false, typeof(locale))]
    [DefaultValue(localeKeys.cFalse)]
    [VisibleIf("IsBoolean", CompareType.EqualTo, true)]
    public string FalseText
    {
      get { return mFalseText; }
      set
      {
        if (mFalseText == value) return;
        mFalseText = value;
        NotifyPropertyChanged(this.NameOf(p => p.FalseText));
      }
    }

    [ControlProperty(localeKeys.cTrimBy, localeKeys.cTrimBy, false, typeof(locale))]
    [DefaultValue(null)]
    [VisibleIf("IsLeftTrimmed", CompareType.EqualTo, true)]
    public string TrimBy
    {
      get { return mTrimBy; }
      set
      {
        if (mTrimBy == value) return;
        mTrimBy = value;
        NotifyPropertyChanged(this.NameOf(p => p.TrimBy));
      }
    }

    [ControlProperty(localeKeys.cXaml, localeKeys.cXamlDescription, false, typeof(locale))]
    [DefaultValue(null)]
    [VisibleIf("IsXaml", CompareType.EqualTo, true)]
    public string Xaml
    {
      get { return mXaml; }
      set
      {
        if (mXaml == value) return;
        mXaml = value;
        UpdateElementType();
        NotifyPropertyChanged(this.NameOf(p => p.Xaml));
      }
    }

    [ControlProperty(localeKeys.cFormat, localeKeys.cFormat, false, typeof(locale))]
    [DefaultValue("")]
    [VisibleIf("IsInput", CompareType.EqualTo, true)]
    public string InputFormat
    {
      get { return mInputFormat; }
      set
      {
        if (mInputFormat == value || string.IsNullOrEmpty(value)) return;
        mInputFormat = value;

        UpdateElement<InputWrapper>(w => w.InputVM.Format = value);

        NotifyPropertyChanged(this.NameOf(p => p.InputFormat));
      }
    }

    [ControlProperty(localeKeys.cUnit, localeKeys.cUnit, false, typeof(locale))]
    [DefaultValue("")]
    [VisibleIf("IsInput", CompareType.EqualTo, true)]
    public string InputUnit
    {
      get { return mInputUnit; }
      set
      {
        if (mInputUnit == value || string.IsNullOrEmpty(value)) return;
        mInputUnit = value;

        NotifyPropertyChanged(this.NameOf(p => p.InputUnit));
      }
    }

    [LocalizedCategory(localeKeys.cProperties)]
    [ControlProperty(localeKeys.cKeyboardType, localeKeys.cKeyboardType, false, typeof(locale))]
    [DefaultValue(KeyboardType.AlphaNumericSymbols)]
    [LocalizedEnumValueDisplayName("Alpha", localeKeys.cKeyboardTypeAlpha, typeof(locale))]
    [LocalizedEnumValueDisplayName("SignedNumeric", localeKeys.cKeyboardTypeSignedNumeric, typeof(locale))]
    [LocalizedEnumValueDisplayName("UnsignedNumeric", localeKeys.cKeyboardTypeUnsignedNumeric, typeof(locale))]
    [VisibleIf("IsInput", CompareType.EqualTo, true)]
    public KeyboardType InputKeyboardType
    {
      get { return mInputKeyboardType; }
      set
      {
        if (mInputKeyboardType == value) return;
        mInputKeyboardType = value;

        UpdateElement<InputWrapper>(w => w.InputVM.KeyboardType = value);

        NotifyPropertyChanged(this.NameOf(p => p.InputKeyboardType));
      }
    }

    #region LatLong

    [LocalizedCategory(localeKeys.cMappingProperties, typeof(locale))]
    [ControlProperty(localeKeys.cLatitude, localeKeys.cLatitude, false, typeof(locale))]
    [DefaultValue(CONST_MAPPING)]
    [VisibleIf("IsLatLongInput", CompareType.EqualTo, true)]
    public string LatitudeMapping
    {
      get { return mLatitudeMapping; }
      set
      {
        if (mLatitudeMapping == value) return;
        mLatitudeMapping = value;
        if (mCellStyle != null)
        {
          BuildCellStyle(mCellStyleBasedOn);
        }
        NotifyPropertyChanged(this.NameOf(p => p.LatitudeMapping));
      }
    }

    [LocalizedCategory(localeKeys.cMappingProperties, typeof(locale))]
    [ControlProperty(localeKeys.cLongitude, localeKeys.cLongitude, false, typeof(locale))]
    [DefaultValue(CONST_MAPPING)]
    [VisibleIf("IsLatLongInput", CompareType.EqualTo, true)]
    public string LongitudeMapping
    {
      get { return mLongitudeMapping; }
      set
      {
        if (mLongitudeMapping == value) return;
        mLongitudeMapping = value;
        if (mCellStyle != null)
        {
          BuildCellStyle(mCellStyleBasedOn);
        }
        NotifyPropertyChanged(this.NameOf(p => p.LongitudeMapping));
      }
    }

    [ControlProperty(localeKeys.cFormat, localeKeys.cFormat, false, typeof(locale))]
    [DefaultValue("{0}{1} / {2}{3}")]
    [VisibleIf("IsLatLongInput", CompareType.EqualTo, true)]
    public string LatLongFormat
    {
      get { return mLatLongFormat; }
      set
      {
        if (mLatLongFormat == value || string.IsNullOrEmpty(value)) return;
        mLatLongFormat = value;

        UpdateElement<LatLongInputWrapper>(w => w.InputVM.Format = value);

        NotifyPropertyChanged(this.NameOf(p => p.LatLongFormat));
      }
    }

    [LocalizedCategory(localeKeys.cProperties)]
    [ControlProperty(localeKeys.cKeyboardType, localeKeys.cKeyboardType, false, typeof(locale))]
    [DefaultValue(KeyboardType.NumericSigned)]
    [LocalizedEnumValueDisplayName("Alpha", localeKeys.cKeyboardTypeAlpha, typeof(locale))]
    [LocalizedEnumValueDisplayName("SignedNumeric", localeKeys.cKeyboardTypeSignedNumeric, typeof(locale))]
    [LocalizedEnumValueDisplayName("UnsignedNumeric", localeKeys.cKeyboardTypeUnsignedNumeric, typeof(locale))]
    [VisibleIf("IsLatLongInput", CompareType.EqualTo, true)]
    public KeyboardType LatLongKeyboardType
    {
      get { return mLatLongKeyboardType; }
      set
      {
        if (mLatLongKeyboardType == value) return;
        mLatLongKeyboardType = value;

        UpdateElement<LatLongInputWrapper>(w => w.InputVM.KeyboardType = value);

        NotifyPropertyChanged(this.NameOf(p => p.LatLongKeyboardType));
      }
    }

    [DefaultValue(null)]
    [InstructionBinding]
    [ControlProperty("HookCoordinate", "HookCoordinate", false, typeof(locale))]
    [VisibleIf("IsLatLongInput", CompareType.EqualTo, true)]
    public string LatLongHookCoordinateId
    {
      get { return mLatLongHookCoordinate; }
      set
      {
        if (Equals(mLatLongHookCoordinate, value)) return;
        mLatLongHookCoordinate = value;

        UpdateElement<LatLongInputWrapper>(w => w.InputVM.HookCoordinateId = value);

        NotifyPropertyChanged(this.NameOf(p => p.LatLongHookCoordinateId));
      }
    }

    [DefaultValue(LatLongPrecisionMode.TwoDecimalsMinute)]
    [ControlProperty("Predefined DMS Format", "Predefined DMSFormat")]
    [LocalizedEnumValueDisplayName("TwoDecimalsMinute", "N00:00.00 / E000:00.00", typeof(locale))]
    [LocalizedEnumValueDisplayName("ThreeDecimalsMinute", "N00:00.000 / E000:00.000", typeof(locale))]
    [LocalizedEnumValueDisplayName("OneDecimalSecond", "N00:00:00.0 / E000:00:00.0", typeof(locale))]
    [LocalizedEnumValueDisplayName("TwoDecimalsSecond", "N00:00:00.00 / E000:00:00.00", typeof(locale))]
    [VisibleIf("IsLatLongInput", CompareType.EqualTo, true)]
    public LatLongPrecisionMode LatLongPrecisionMode
    {
      get { return mLatLongPrecisionMode; }
      set
      {
        if (mLatLongPrecisionMode == value) return;
        mLatLongPrecisionMode = value;

        UpdateElement<LatLongInputWrapper>(w => w.InputVM.PrecisionMode = value);

        NotifyPropertyChanged(this.NameOf(p => p.LatLongPrecisionMode));
      }
    }

    [DefaultValue("Latitude")]
    [ControlProperty(localeKeys.cLatitudeText, localeKeys.cLatitudeText, false, typeof(locale))]
    [Localizable(true)]
    [AutoLocalizable]
    [VisibleIf("IsLatLongInput", CompareType.EqualTo, true)]
    public string LatLongLatitudeText
    {
      get { return mLatLongLatitudeText; }
      set
      {
        if (Equals(mLatLongLatitudeText, value)) return;
        mLatLongLatitudeText = value;

        UpdateElement<LatLongInputWrapper>(w => w.InputVM.LatitudeText = value);

        NotifyPropertyChanged(this.NameOf(p => p.LatLongLatitudeText));
      }
    }

    [DefaultValue("Longitude")]
    [ControlProperty(localeKeys.cLongitudeText, localeKeys.cLongitudeText, false, typeof(locale))]
    [Localizable(true)]
    [AutoLocalizable]
    [VisibleIf("IsLatLongInput", CompareType.EqualTo, true)]
    public string LatLongLongitudeText
    {
      get { return mLatLongLongitudeText; }
      set
      {
        if (Equals(mLatLongLongitudeText, value)) return;
        mLatLongLongitudeText = value;

        UpdateElement<LatLongInputWrapper>(w => w.InputVM.LongitudeText = value);

        NotifyPropertyChanged(this.NameOf(p => p.LatLongLongitudeText));
      }
    }

    #endregion

    [JsonIgnore]
    public Style CellStyle
    {
      get { return mCellStyle; }
    }

    [JsonIgnore]
    public bool IsText
    {
      get { return Template == SimpleGridColumnTemplate.Text || Template == SimpleGridColumnTemplate.LeftTrimmedText; }
    }

    [JsonIgnore]
    public bool IsBoolean
    {
      get { return IsText && (TextConverter == SimpleGridTextColumnConverter.BooleanToString || TextConverter == SimpleGridTextColumnConverter.NumberBooleanToString); }
    }

    [JsonIgnore]
    public bool IsLeftTrimmed
    {
      get { return Template == SimpleGridColumnTemplate.LeftTrimmedText; }
    }

    [JsonIgnore]
    public bool IsLatLongInput
    {
      get { return Template == SimpleGridColumnTemplate.LatLongInput; }
    }

    [JsonIgnore]
    public bool IsInput
    {
      get { return Template == SimpleGridColumnTemplate.Input; }
    }

    [JsonIgnore]
    public bool IsXaml
    {
      get { return Template == SimpleGridColumnTemplate.Xaml; }
    }

    private int mCacheLength = 5;

    [JsonIgnore]
    public int CacheLength
    {
      get { return mCacheLength; }
      set
      {
        if (mCacheLength == value) return;

        mCacheLength = value;

        if (mCacheLength < mElementCache.Count)
        {
          mElementCache.RemoveRange(mCacheLength, mElementCache.Count - mCacheLength);
        }

        NotifyPropertyChanged(this.NameOf(p => p.CacheLength));
      }
    }

    private Type mElementType = typeof(TextBlock);

    [JsonIgnore]
    public Type ElementType
    {
      get { return mElementType; }
      set
      {
        if (mElementType == value) return;

        mElementType = value;

        BuildCellStyle(mCellStyleBasedOn);

        NotifyPropertyChanged(this.NameOf(p => p.ElementType));
      }
    }

    /// <summary>
    /// Returns the calculated width for the column or the default value
    /// </summary>
    public double GetWidth()
    {
      var wValue = ComputedWidth;
      return wValue != double.NaN ? wValue : mDefaultColumnWidth;
    }

    public void BuildCellStyle(Style basedOn)
    {
      if (basedOn != null && basedOn.TargetType == ElementType)
      {
        mCellStyleBasedOn = basedOn;
      }
      else
      {
        mCellStyleBasedOn = null;
      }

      if (ElementType == null)
      {
        mCellStyle = null;
        return;
      }

      var wStyle = new Style(ElementType, mCellStyleBasedOn);

      var wTextBindingPath = GetBindingPath(Mapping);

      switch (Template)
      {
        case SimpleGridColumnTemplate.Text:
          {
            var wTextBinding = new Binding(wTextBindingPath);

            if (!string.IsNullOrEmpty(StringFormat))
            {
              wTextBinding.StringFormat = StringFormat;
            }

            if (IsBoolean)
            {
              wTextBinding.Converter = new BooleanToStringConverter(TrueText, FalseText);
            }

            wStyle.Setters.Add(new Setter(TextBlock.TextProperty, wTextBinding));
          }
          break;
        case SimpleGridColumnTemplate.LeftTrimmedText:
          {
            var wTextBinding = new MultiBinding();

            if (!string.IsNullOrEmpty(StringFormat))
            {
              wTextBinding.StringFormat = StringFormat;
            }

            wTextBinding.Converter = new TextTrimConverter();
            wTextBinding.Bindings.Add(new Binding() { RelativeSource = new RelativeSource(RelativeSourceMode.Self) });
            wTextBinding.Bindings.Add(new Binding(wTextBindingPath));
            wTextBinding.Bindings.Add(new Binding("TrimBy") { Source = this });
            // Force update on size change
            wTextBinding.Bindings.Add(new Binding(FrameworkElement.ActualWidthProperty.Name) { RelativeSource = new RelativeSource(RelativeSourceMode.Self) });

            wStyle.Setters.Add(new Setter(TextBlock.TextProperty, wTextBinding));
          }
          break;
        case SimpleGridColumnTemplate.Input:
          wStyle.Setters.Add(new Setter(InputWrapper.ValueProperty, new Binding(wTextBindingPath)));
          break;
        case SimpleGridColumnTemplate.LatLongInput:
          wStyle.Setters.Add(new Setter(LatLongInputWrapper.LatitudeProperty, new Binding(GetBindingPath(LatitudeMapping)) { Converter = new ToDoubleConverter() }));
          wStyle.Setters.Add(new Setter(LatLongInputWrapper.LongitudeProperty, new Binding(GetBindingPath(LongitudeMapping)) { Converter = new ToDoubleConverter() }));
          break;
        case SimpleGridColumnTemplate.Xaml:
          break;
      }

      // Text block common styles
      if (typeof(TextBlock).IsAssignableFrom(ElementType))
      {
        // Foreground color
        if (!string.IsNullOrEmpty(Foreground))
        {
          if (Foreground.StartsWith("#"))
          {
            try
            {
              wStyle.Setters.Add(new Setter(TextBlock.ForegroundProperty, new SolidColorBrush((Color)ColorConverter.ConvertFromString(Foreground))));
            }
            catch (FormatException)
            {

            }
          }
          else
          {
            var wColorBinding = new Binding(GetBindingPath(Foreground))
            {
              Converter = new StringToColorConverter()
            };

            wStyle.Setters.Add(new Setter(TextBlock.ForegroundProperty, wColorBinding));
          }
        }
      }

      mCellStyle = wStyle;
    }

    private string GetBindingPath(string mapping)
    {
      string wBindingPath;

      if (string.IsNullOrEmpty(mapping) || mapping == ".")
      {
        wBindingPath = "Data";
      }
      else if (mapping.StartsWith("["))
      {
        wBindingPath = "Data" + mapping;
      }
      else
      {
        wBindingPath = "Data." + mapping;
      }

      return wBindingPath;
    }

    private void UpdateElementType()
    {
      switch (Template)
      {
        case SimpleGridColumnTemplate.Text:
        case SimpleGridColumnTemplate.LeftTrimmedText:
          ElementType = typeof(TextBlock);
          break;
        case SimpleGridColumnTemplate.Input:
          ElementType = typeof(InputWrapper);
          break;
        case SimpleGridColumnTemplate.LatLongInput:
          ElementType = typeof(LatLongInputWrapper);
          break;
        case SimpleGridColumnTemplate.Xaml:
          if (string.IsNullOrEmpty(Xaml))
          {
            mValidXaml = null;
            ElementType = null;
          }
          else
          {
            try
            {
              var wElement = (FrameworkElement)XamlReader.Parse(Xaml, mParserContext);
              mValidXaml = Xaml;
              ElementType = wElement == null
                ? null
                : wElement.GetType();
            }
            catch
            {
              mValidXaml = null;
              ElementType = null;
            }
          }
          break;
      }

      mElementCache.Clear();
      mUsedElements.Clear();
    }

    public FrameworkElement CreateElement()
    {
      FrameworkElement wElement;

      if (mElementCache.Count > 0)
      {
        wElement = mElementCache[mElementCache.Count - 1];
        mElementCache.RemoveAt(mElementCache.Count - 1);
      }
      else
      {
        switch (Template)
        {
          case SimpleGridColumnTemplate.Text:
          case SimpleGridColumnTemplate.LeftTrimmedText:
            wElement = new TextBlock();
            break;
          case SimpleGridColumnTemplate.Input:
            {
              var wWrapper = new InputWrapper();

              var wVM = UnityContainer.Resolve<InputVM>();
              wVM.Format = InputFormat;
              wVM.KeyboardType = InputKeyboardType;

              wWrapper.InputVM = wVM;
              wElement = wWrapper;
            }
            break;
          case SimpleGridColumnTemplate.LatLongInput:
            {
              var wWrapper = new LatLongInputWrapper();

              var wVM = UnityContainer.Resolve<LatLongInputVM>();
              wVM.Format = LatLongFormat;
              wVM.KeyboardType = LatLongKeyboardType;
              wVM.HookCoordinateId = LatLongHookCoordinateId;
              wVM.PrecisionMode = LatLongPrecisionMode;
              wVM.LatitudeText = LatLongLatitudeText;
              wVM.LongitudeText = LatLongLongitudeText;

              wWrapper.InputVM = wVM;
              wElement = wWrapper;
            }
            break;
          case SimpleGridColumnTemplate.Xaml:
            if (string.IsNullOrEmpty(mValidXaml))
            {
              return null;
            }
            else
            {
              wElement = (FrameworkElement)XamlReader.Parse(mValidXaml, mParserContext);
              wElement = UnityContainer.BuildUp(wElement);
            }
            break;
          default:
            return null;
        }
      }

      mUsedElements.Add(wElement);

      return wElement;
    }

    // For caching elements so we don't need to create a new
    public void ReleaseElement(FrameworkElement element)
    {
      if (element != null && mUsedElements.Remove(element))
      {
        if (mElementCache.Count < CacheLength)
        {
          mElementCache.Add(element);
        }
      }
    }

    private void UpdateElement<T>(Action<T> update)
    {
      foreach (var wItem in mUsedElements.OfType<T>())
      {
        update(wItem);
      }
      foreach (var wItem in mElementCache.OfType<T>())
      {
        update(wItem);
      }
    }

  }

}
