﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid
{
  public class ElementChangedEventArgs : EventArgs
  {
    public object Element { get; private set; }
    public ElementChangedType Type { get; private set; }
    public string PropertyName { get; private set; }
    public ElementChangedEventArgs InnerEvent { get; private set; }

    public ElementChangedEventArgs(object element, ElementChangedType type, string propertyName = null, ElementChangedEventArgs innerEvent = null)
    {
      Element = element;
      Type = type;
      PropertyName = propertyName;
      InnerEvent = innerEvent;
    }
  }

  public enum ElementChangedType
  {
    PropertyChanged,
    CollectionChanged,
    SubElementChanged
  }
}
