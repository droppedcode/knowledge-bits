﻿using Cae.Iss.InstructionEditor.Core.Toolkit;
using Cae.Synapse.Foundation.Toolkit.Extensions;
using System;
using System.Windows;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid
{
  /// <summary>
  /// Small wrapper object for a cell
  /// </summary>
  public class SimpleGridCell : NotificationObject
  {
    public event EventHandler<Tuple<FrameworkElement, FrameworkElement>> ElementChanged;

    private SimpleGridColumn mColumn;

    public SimpleGridColumn Column
    {
      get { return mColumn; }
      set
      {
        if (mColumn == value) return;

        var wReleased = false;
        var wOrigElement = Element;

        if (mColumn != null)
        {
          wReleased = true;
          Element = null;
          mColumn.ReleaseElement(Element);
          mColumn.PropertyChanged -= ColumnPropertyChanged;
        }

        mColumn = value;

        if (mColumn != null)
        {
          mColumn.PropertyChanged += ColumnPropertyChanged;
        }

        UpdateElement(wReleased, wOrigElement);

        NotifyPropertyChanged(this.NameOf(p => p.Column));
      }
    }

    private void UpdateElement(bool columnHasChanged, FrameworkElement origElement)
    {
      var wOrigElement = origElement ?? Element;
      if (mColumn != null)
      {
        if (mColumn.ElementType == null)
        {
          Element = null;
        }
        else if (Element == null || Element.GetType() != mColumn.ElementType)
        {
          Element = Column.CreateElement();
        }

        if (Element != null)
        {
          if (Element.Style != mColumn.CellStyle)
          {
            if (mColumn.CellStyle == null || mColumn.CellStyle.TargetType.IsAssignableFrom(Element.GetType()))
            {
              Element.Style = mColumn.CellStyle;
            }
          }
          Element.Width = mColumn.GetWidth();
        }
      }
      else
      {
        Element.Style = null;
        Element = null;
      }

      if (columnHasChanged || wOrigElement != Element)
      {
        if (!columnHasChanged && mColumn != null)
        {
          mColumn.ReleaseElement(wOrigElement);
        }

        var wHandler = ElementChanged;
        if (wHandler != null)
        {
          wHandler(this, new Tuple<FrameworkElement, FrameworkElement>(wOrigElement, Element));
        }
      }
    }

    private void ColumnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
      UpdateElement(false, null);
    }

    private SimpleGridRow mRow;

    public SimpleGridRow Row
    {
      get { return mRow; }
      set
      {
        if (mRow == value) return;

        mRow = value;
        NotifyPropertyChanged(this.NameOf(p => p.Row));
      }
    }

    private object mData;

    public object Data
    {
      get { return mData; }
      set
      {
        if (mData == value) return;

        mData = value;
        NotifyPropertyChanged(this.NameOf(p => p.Data));
      }
    }

    private FrameworkElement mElement;

    public FrameworkElement Element
    {
      get { return mElement; }
      set
      {
        if (mElement == value) return;

        if (mElement != null && mElement.DataContext == this)
        {
          mElement.DataContext = null;
        }

        mElement = value;

        if (mElement != null)
        {
          mElement.DataContext = this;
        }

        NotifyPropertyChanged(this.NameOf(p => p.Element));
      }
    }

  }
}
