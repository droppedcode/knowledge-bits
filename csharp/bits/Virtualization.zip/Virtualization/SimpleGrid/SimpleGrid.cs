﻿using Cae.Iss.IosControlLibrary.Controls.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid
{
  /// <summary>
  /// Simple but performant grid to display text data in a grid
  /// </summary>
  [TemplatePart(Name = PART_CanvasName, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_HorizontalScrollBarName, Type = typeof(ScrollBar))]
  [TemplatePart(Name = PART_VerticalScrollBarName, Type = typeof(ScrollBar))]
  [TemplatePart(Name = PART_TouchScrollerName, Type = typeof(TouchScrollerWrapper))]
  public class SimpleGrid : Control
  {
    #region Fields

    private const int mRowZIndex = 0;
    private const int mCellZIndex = 1;

    private const string PART_CanvasName = "PART_Canvas";
    private const string PART_HorizontalScrollBarName = "PART_HorizontalScrollBar";
    private const string PART_VerticalScrollBarName = "PART_VerticalScrollBar";
    private const string PART_TouchScrollerName = "PART_TouchScroller";

    private static long mScrollToAnimationPerItemDuration = 50;
    private static long mScrollToAnimationMaxDuration = 500;

    private WeakReference<object> mPossibleMouseClickItem;
    private Point mPossibleMouseClickPosition;
    private int mSuspendDrawCount;
    private int mRowCount;

    private bool mScrollDisabledDueToInternalManipulation;
    private bool mIsUpdateingSelection;

    private int mFirstVisibleRow;
    /// <summary>
    /// Tehe currently visible row count
    /// </summary>
    private int mVisibleRowCount;

    private int mLastClickedIndex;

    // The visible columns
    private readonly List<SimpleGridColumn> mVisibleColumns = new List<SimpleGridColumn>();

    private readonly List<SimpleGridRow> mVisibleRows = new List<SimpleGridRow>();

    private readonly List<SimpleGridColumn> mAddedColumns = new List<SimpleGridColumn>();
    private readonly ObservableCollection<SimpleGridColumn> mColumns;

    private Storyboard mScrollToStoryboard;
    private DoubleAnimation mScrollToAnimation;

    #endregion //Fields

    public bool IsTemplateApplied { get; protected set; }
    public TouchScrollerWrapper TouchScroller { get; protected set; }
    public Canvas Canvas { get; protected set; }
    public ScrollBar HorizontalScrollBar { get; protected set; }
    public ScrollBar VerticalScrollBar { get; protected set; }

    protected virtual bool IsDrawEnabled
    {
      get { return IsTemplateApplied && mSuspendDrawCount == 0 && IsLoaded; }
    }

    protected virtual double ControlWidth
    {
      get { return ActualWidth; }
    }

    protected virtual double ControlHeight
    {
      get { return ActualHeight; }
    }

    public ObservableCollection<SimpleGridColumn> Columns
    {
      get { return mColumns; }
    }

    #region Dependency properties

    public IEnumerable<object> ItemsSource
    {
      get { return (IEnumerable<object>)GetValue(ItemsSourceProperty); }
      set { SetValue(ItemsSourceProperty, value); }
    }

    public static readonly DependencyProperty ItemsSourceProperty =
      DependencyProperty.Register("ItemsSource", typeof(IEnumerable<object>), typeof(SimpleGrid), new PropertyMetadata(null, OnItemsSourceChanged));

    private static void OnItemsSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((SimpleGrid)d).OnItemsSourceChanged(e.OldValue as IEnumerable<object>, e.NewValue as IEnumerable<object>);
    }

    private void OnItemsSourceChanged(IEnumerable<object> oldValue, IEnumerable<object> newValue)
    {
      var wCollection = oldValue as INotifyCollectionChanged;
      if (wCollection != null)
      {
        wCollection.CollectionChanged -= OnItemsChanged;
      }

      wCollection = newValue as INotifyCollectionChanged;
      if (wCollection != null)
      {
        wCollection.CollectionChanged += OnItemsChanged;
      }

      ValidateRows();
    }

    private void OnItemsChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
      if (e.Action == NotifyCollectionChangedAction.Move)
      {
        UpdateVisibleItems();
      }
      else if (e.Action == NotifyCollectionChangedAction.Replace)
      {
        var wRow = mVisibleRows.FirstOrDefault(a => a.Index == e.NewStartingIndex);
        if (wRow != null)
        {
          wRow.Data = e.NewItems[0];
          wRow.IsSelected = SelectedItems.Contains(wRow.Data);
        }
      }
      else
      {
        ValidateRows();
      }

      if (SelectedItem != null)
      {
        if (e.Action == NotifyCollectionChangedAction.Replace)
        {
          // Handle 1 change per event
          if (e.OldItems[0] == SelectedItem && e.NewItems[0] != SelectedItem)
          {
            SelectedItem = null;
          }
        }
        else if (e.Action != NotifyCollectionChangedAction.Move)
        {
          if (ItemsSource == null || !ItemsSource.Contains(SelectedItem))
          {
            SelectedItem = null;
          }
        }
      }

      // TODO: handle selecteditems
    }

    public double VirtualHeight
    {
      get { return (double)GetValue(VirtualHeightProperty); }
      set { SetValue(VirtualHeightProperty, value); }
    }

    public static readonly DependencyProperty VirtualHeightProperty =
      DependencyProperty.Register("VirtualHeight", typeof(double), typeof(SimpleGrid), new PropertyMetadata(double.NaN));

    public double VirtualWidth
    {
      get { return (double)GetValue(VirtualWidthProperty); }
      set { SetValue(VirtualWidthProperty, value); }
    }

    public static readonly DependencyProperty VirtualWidthProperty =
      DependencyProperty.Register("VirtualWidth", typeof(double), typeof(SimpleGrid), new PropertyMetadata(double.NaN));

    public double ScrollTop
    {
      get { return (double)GetValue(ScrollTopProperty); }
      set { SetValue(ScrollTopProperty, value); }
    }

    public static readonly DependencyProperty ScrollTopProperty =
      DependencyProperty.Register("ScrollTop", typeof(double), typeof(SimpleGrid), new PropertyMetadata(0d, OnScrollTopChanged, OnScrollTopCoerce));

    private static void OnScrollTopChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      var self = (SimpleGrid)d;

      if (self.mScrollDisabledDueToInternalManipulation) return;

      self.UpdateVerticalScroll(true);
    }

    private static object OnScrollTopCoerce(DependencyObject d, object baseValue)
    {
      var self = (SimpleGrid)d;
      if (baseValue is double)
      {
        if (self.ScrollableHeight < (double)baseValue)
        {
          return self.ScrollableHeight;
        }
        else if ((double)baseValue < 0)
        {
          return 0d;
        }
        else
        {
          return baseValue;
        }
      }
      else
      {
        return ((SimpleGrid)d).ScrollTop;
      }
    }

    public double ScrollLeft
    {
      get { return (double)GetValue(ScrollLeftProperty); }
      set { SetValue(ScrollLeftProperty, value); }
    }

    public static readonly DependencyProperty ScrollLeftProperty =
      DependencyProperty.Register("ScrollLeft", typeof(double), typeof(SimpleGrid), new PropertyMetadata(0d, OnScrollLeftChanged, OnScrollLeftCoerce));

    private static void OnScrollLeftChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      var self = (SimpleGrid)d;

      if (self.mScrollDisabledDueToInternalManipulation) return;

      self.ValidateColumns();
      self.UpdateCanvasPosition();
      self.UpdateVisibleItems();
    }

    private static object OnScrollLeftCoerce(DependencyObject d, object baseValue)
    {
      var self = (SimpleGrid)d;
      if (baseValue is double)
      {
        if (self.ScrollableWidth < (double)baseValue)
        {
          return self.ScrollableWidth;
        }
        else if ((double)baseValue < 0)
        {
          return 0d;
        }
        else
        {
          return baseValue;
        }
      }
      else
      {
        return ((SimpleGrid)d).ScrollLeft;
      }
    }

    public Visibility ComputedVerticalScrollBarVisibility
    {
      get { return (Visibility)GetValue(ComputedVerticalScrollBarVisibilityProperty); }
      private set { SetValue(ComputedVerticalScrollBarVisibilityPropertyKey, value); }
    }
    private static DependencyPropertyKey ComputedVerticalScrollBarVisibilityPropertyKey =
        DependencyProperty.RegisterReadOnly("ComputedVerticalScrollBarVisibility", typeof(Visibility), typeof(SimpleGrid), new PropertyMetadata(Visibility.Collapsed));

    public static DependencyProperty ComputedVerticalScrollBarVisibilityProperty = ComputedVerticalScrollBarVisibilityPropertyKey.DependencyProperty;

    public Visibility ComputedHorizontalScrollBarVisibility
    {
      get { return (Visibility)GetValue(ComputedHorizontalScrollBarVisibilityProperty); }
      private set { SetValue(ComputedHorizontalScrollBarVisibilityPropertyKey, value); }
    }
    private static DependencyPropertyKey ComputedHorizontalScrollBarVisibilityPropertyKey =
        DependencyProperty.RegisterReadOnly("ComputedHorizontalScrollBarVisibility", typeof(Visibility), typeof(SimpleGrid), new PropertyMetadata(Visibility.Collapsed));

    public static DependencyProperty ComputedHorizontalScrollBarVisibilityProperty = ComputedHorizontalScrollBarVisibilityPropertyKey.DependencyProperty;

    public ScrollBarVisibility VerticalScrollBarVisibility
    {
      get { return (ScrollBarVisibility)GetValue(VerticalScrollBarVisibilityProperty); }
      set { SetValue(VerticalScrollBarVisibilityProperty, value); }
    }

    public static readonly DependencyProperty VerticalScrollBarVisibilityProperty =
      DependencyProperty.Register("VerticalScrollBarVisibility", typeof(ScrollBarVisibility), typeof(SimpleGrid), new PropertyMetadata(ScrollBarVisibility.Auto));

    public ScrollBarVisibility HorizontalScrollBarVisibility
    {
      get { return (ScrollBarVisibility)GetValue(HorizontalScrollBarVisibilityProperty); }
      set { SetValue(HorizontalScrollBarVisibilityProperty, value); }
    }

    public static readonly DependencyProperty HorizontalScrollBarVisibilityProperty =
      DependencyProperty.Register("HorizontalScrollBarVisibility", typeof(ScrollBarVisibility), typeof(SimpleGrid), new PropertyMetadata(ScrollBarVisibility.Hidden));

    public bool IsVerticalScrollBarEnabled
    {
      get { return (bool)GetValue(IsVerticalScrollBarEnabledProperty); }
      private set { SetValue(IsVerticalScrollBarEnabledPropertyKey, value); }
    }
    private static DependencyPropertyKey IsVerticalScrollBarEnabledPropertyKey =
        DependencyProperty.RegisterReadOnly("IsVerticalScrollBarEnabled", typeof(bool), typeof(SimpleGrid), new PropertyMetadata(true));
    public static DependencyProperty IsVerticalScrollBarEnabledProperty = IsVerticalScrollBarEnabledPropertyKey.DependencyProperty;

    public bool IsHorizontalScrollBarEnabled
    {
      get { return (bool)GetValue(IsHorizontalScrollBarEnabledProperty); }
      private set { SetValue(IsHorizontalScrollBarEnabledPropertyKey, value); }
    }
    private static DependencyPropertyKey IsHorizontalScrollBarEnabledPropertyKey =
        DependencyProperty.RegisterReadOnly("IsHorizontalScrollBarEnabled", typeof(bool), typeof(SimpleGrid), new PropertyMetadata(true));
    public static DependencyProperty IsHorizontalScrollBarEnabledProperty = IsHorizontalScrollBarEnabledPropertyKey.DependencyProperty;

    public bool HasLineSeparators
    {
      get { return (bool)GetValue(HasLineSeparatorsProperty); }
      set { SetValue(HasLineSeparatorsProperty, value); }
    }

    public static readonly DependencyProperty HasLineSeparatorsProperty =
      DependencyProperty.Register("HasLineSeparators", typeof(bool), typeof(SimpleGrid), new PropertyMetadata(false));

    public double RowHeight
    {
      get { return (double)GetValue(RowHeightProperty); }
      set { SetValue(RowHeightProperty, value); }
    }

    public static readonly DependencyProperty RowHeightProperty =
      DependencyProperty.Register("RowHeight", typeof(double), typeof(SimpleGrid), new PropertyMetadata(30d, OnRowHeightChanged));

    private static void OnRowHeightChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      var self = (SimpleGrid)d;

      self.Redraw();
    }

    public double ColumnGap
    {
      get { return (double)GetValue(ColumnGapProperty); }
      set { SetValue(ColumnGapProperty, value); }
    }

    public static readonly DependencyProperty ColumnGapProperty =
      DependencyProperty.Register("ColumnGap", typeof(double), typeof(SimpleGrid), new PropertyMetadata(0d));

    public double ScrollableWidth
    {
      get { return (double)GetValue(ScrollableWidthProperty); }
      private set { SetValue(ScrollableWidthPropertyKey, value); }
    }
    private static DependencyPropertyKey ScrollableWidthPropertyKey =
        DependencyProperty.RegisterReadOnly("ScrollableWidth", typeof(double), typeof(SimpleGrid), new PropertyMetadata(0d));
    public static DependencyProperty ScrollableWidthProperty = ScrollableWidthPropertyKey.DependencyProperty;

    public double ScrollableHeight
    {
      get { return (double)GetValue(ScrollableHeightProperty); }
      private set { SetValue(ScrollableHeightPropertyKey, value); }
    }
    private static DependencyPropertyKey ScrollableHeightPropertyKey =
        DependencyProperty.RegisterReadOnly("ScrollableHeight", typeof(double), typeof(SimpleGrid), new PropertyMetadata(0d));
    public static DependencyProperty ScrollableHeightProperty = ScrollableHeightPropertyKey.DependencyProperty;

    public bool IsSmoothRowScrolling
    {
      get { return (bool)GetValue(IsSmoothRowScrollingProperty); }
      set { SetValue(IsSmoothRowScrollingProperty, value); }
    }

    public static readonly DependencyProperty IsSmoothRowScrollingProperty =
      DependencyProperty.Register("IsSmoothRowScrolling", typeof(bool), typeof(SimpleGrid), new PropertyMetadata(false, OnIsSmoothRowScrollingChanged));

    private static void OnIsSmoothRowScrollingChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      var self = (SimpleGrid)d;
      self.ScrollVerticalSmallChange = self.GetVerticalScrollBarSmallChange();
      self.ValidateRows();
    }

    public bool IsSmoothColumnScrolling
    {
      get { return (bool)GetValue(IsSmoothColumnScrollingProperty); }
      set { SetValue(IsSmoothColumnScrollingProperty, value); }
    }

    public static readonly DependencyProperty IsSmoothColumnScrollingProperty =
      DependencyProperty.Register("IsSmoothColumnScrolling", typeof(bool), typeof(SimpleGrid), new PropertyMetadata(false, OnSmoothColumnScrollingChanged));

    private static void OnSmoothColumnScrollingChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((SimpleGrid)d).ValidateColumns();
    }

    public double ClientWidth
    {
      get { return (double)GetValue(ClientWidthProperty); }
      private set { SetValue(ClientWidthPropertyKey, value); }
    }
    private static DependencyPropertyKey ClientWidthPropertyKey =
        DependencyProperty.RegisterReadOnly("ClientWidth", typeof(double), typeof(SimpleGrid), new PropertyMetadata(0d));
    public static DependencyProperty ClientWidthProperty = ClientWidthPropertyKey.DependencyProperty;

    public double ClientHeight
    {
      get { return (double)GetValue(ClientHeightProperty); }
      private set { SetValue(ClientHeightPropertyKey, value); }
    }
    private static DependencyPropertyKey ClientHeightPropertyKey =
        DependencyProperty.RegisterReadOnly("ClientHeight", typeof(double), typeof(SimpleGrid), new PropertyMetadata(0d));
    public static DependencyProperty ClientHeightProperty = ClientHeightPropertyKey.DependencyProperty;

    public double ScrollHorizontalSmallChange
    {
      get { return (double)GetValue(ScrollHorizontalSmallChangeProperty); }
      private set { SetValue(ScrollHorizontalSmallChangePropertyKey, value); }
    }
    private static DependencyPropertyKey ScrollHorizontalSmallChangePropertyKey =
        DependencyProperty.RegisterReadOnly("ScrollHorizontalSmallChange", typeof(double), typeof(SimpleGrid), new PropertyMetadata(1d));
    public static DependencyProperty ScrollHorizontalSmallChangeProperty = ScrollHorizontalSmallChangePropertyKey.DependencyProperty;

    public double ScrollVerticalSmallChange
    {
      get { return (double)GetValue(ScrollVerticalSmallChangeProperty); }
      private set { SetValue(ScrollVerticalSmallChangePropertyKey, value); }
    }
    private static DependencyPropertyKey ScrollVerticalSmallChangePropertyKey =
        DependencyProperty.RegisterReadOnly("ScrollVerticalSmallChange", typeof(double), typeof(SimpleGrid), new PropertyMetadata(1d));
    public static DependencyProperty ScrollVerticalSmallChangeProperty = ScrollVerticalSmallChangePropertyKey.DependencyProperty;

    public IEnumerable<Style> CellStyles
    {
      get { return (IEnumerable<Style>)GetValue(CellStylesProperty); }
      set { SetValue(CellStylesProperty, value); }
    }

    public static readonly DependencyProperty CellStylesProperty =
      DependencyProperty.Register("CellStyles", typeof(IEnumerable<Style>), typeof(SimpleGrid), new PropertyMetadata(null, OnCellStyleChanged));

    private static void OnCellStyleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((SimpleGrid)d).Redraw();
    }

    public Style RowStyle
    {
      get { return (Style)GetValue(RowStyleProperty); }
      set { SetValue(RowStyleProperty, value); }
    }

    public static readonly DependencyProperty RowStyleProperty =
      DependencyProperty.Register("RowStyle", typeof(Style), typeof(SimpleGrid), new PropertyMetadata(null, OnRowStyleChanged));

    private static void OnRowStyleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((SimpleGrid)d).UpdateRowStyle();
    }

    public Style SelectedRowStyle
    {
      get { return (Style)GetValue(SelectedRowStyleProperty); }
      set { SetValue(SelectedRowStyleProperty, value); }
    }

    public static readonly DependencyProperty SelectedRowStyleProperty =
      DependencyProperty.Register("SelectedRowStyle", typeof(Style), typeof(SimpleGrid), new PropertyMetadata(null, OnSelectedRowStyleChanged));

    private static void OnSelectedRowStyleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((SimpleGrid)d).UpdateSelectedRowStyle();
    }

    public object SelectedItem
    {
      get { return (object)GetValue(SelectedItemProperty); }
      set { SetCurrentValue(SelectedItemProperty, value); }
    }

    public static readonly DependencyProperty SelectedItemProperty =
      DependencyProperty.Register("SelectedItem", typeof(object), typeof(SimpleGrid), new PropertyMetadata(null, OnSelectedItemChanged, CoerceSelectedItem));

    private static void OnSelectedItemChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((SimpleGrid)d).UpdateSelectedItem();
    }

    private static object CoerceSelectedItem(DependencyObject d, object baseValue)
    {
      var self = (SimpleGrid)d;

      if (baseValue == null || self.ItemsSource == null || !self.ItemsSource.Contains(baseValue)) return null;

      return baseValue;
    }

    public int? SelectedIndex
    {
      get { return (int?)GetValue(SelectedIndexProperty); }
      set { SetCurrentValue(SelectedIndexProperty, value); }
    }

    // Using a DependencyProperty as the backing store for SelectedIndex.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty SelectedIndexProperty =
        DependencyProperty.Register("SelectedIndex", typeof(int?), typeof(SimpleGrid), new PropertyMetadata(null, OnSelectedIndexChanged, CoerceSelectedIndex));

    private static void OnSelectedIndexChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((SimpleGrid)d).UpdateSelectedIndex();
    }

    private static object CoerceSelectedIndex(DependencyObject d, object baseValue)
    {
      var self = (SimpleGrid)d;
      var wIndex = baseValue as int?;

      if (!wIndex.HasValue || self.ItemsSource == null || wIndex < 0 || wIndex >= self.ItemsSource.Count()) return null;

      return baseValue;
    }

    /// <summary>
    /// Is multi selection enabled
    /// </summary>
    public bool IsMultiSelectEnabled
    {
      get { return (bool)GetValue(IsMultiSelectEnabledProperty); }
      set { SetValue(IsMultiSelectEnabledProperty, value); }
    }

    public static readonly DependencyProperty IsMultiSelectEnabledProperty = DependencyProperty.Register("IsMultiSelectEnabled", typeof(bool), typeof(SimpleGrid), new PropertyMetadata(false));

    public IEnumerable<object> SelectedItems
    {
      get { return (IEnumerable<object>)GetValue(SelectedItemsProperty); }
      set { SetValue(SelectedItemsProperty, value != null ? value.ToArray() : null); }
    }

    public static readonly DependencyProperty SelectedItemsProperty = DependencyProperty.Register("SelectedItems", typeof(IEnumerable<object>), typeof(SimpleGrid), new PropertyMetadata(null, OnSelectedItemsChanged));

    private static void OnSelectedItemsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((SimpleGrid)d).UpdateSelectedItems();
    }

    public bool IsTopOverflowIndicator
    {
      get { return (bool)GetValue(IsTopOverflowIndicatorProperty); }
      set { SetValue(IsTopOverflowIndicatorProperty, value); }
    }

    public static readonly DependencyProperty IsTopOverflowIndicatorProperty =
      DependencyProperty.Register("IsTopOverflowIndicator", typeof(bool), typeof(SimpleGrid), new PropertyMetadata(false));

    public bool IsBottomOverflowIndicator
    {
      get { return (bool)GetValue(IsBottomOverflowIndicatorProperty); }
      set { SetValue(IsBottomOverflowIndicatorProperty, value); }
    }

    public static readonly DependencyProperty IsBottomOverflowIndicatorProperty =
      DependencyProperty.Register("IsBottomOverflowIndicator", typeof(bool), typeof(SimpleGrid), new PropertyMetadata(false));

    public int FirstVisibleRow
    {
      get { return (int)GetValue(FirstVisibleRowProperty); }
      set { SetCurrentValue(FirstVisibleRowProperty, value); }
    }

    public static readonly DependencyProperty FirstVisibleRowProperty =
        DependencyProperty.Register("FirstVisibleRow", typeof(int), typeof(SimpleGrid), new PropertyMetadata(0));

    /// <summary>
    /// Possibly visible row count
    /// </summary>
    public int VisibleRowCount
    {
      get { return (int)GetValue(VisibleRowCountProperty); }
      set { SetCurrentValue(VisibleRowCountProperty, value); }
    }

    public static readonly DependencyProperty VisibleRowCountProperty =
        DependencyProperty.Register("VisibleRowCount", typeof(int), typeof(SimpleGrid), new PropertyMetadata(0));

    public Func<IEnumerable<object>, IEnumerable<object>> Sort
    {
      get { return (Func<IEnumerable<object>, IEnumerable<object>>)GetValue(SortProperty); }
      set { SetValue(SortProperty, value); }
    }

    public static readonly DependencyProperty SortProperty =
        DependencyProperty.Register("Sort", typeof(Func<IEnumerable<object>, IEnumerable<object>>), typeof(SimpleGrid), new PropertyMetadata(null, OnSortChanged));

    private static void OnSortChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((SimpleGrid)d).UpdateVisibleItems();
    }

    #endregion //Dependency properties

    static SimpleGrid()
    {
      DefaultStyleKeyProperty.OverrideMetadata(typeof(SimpleGrid), new FrameworkPropertyMetadata(typeof(SimpleGrid)));
    }

    public SimpleGrid()
    {
      mColumns = new ObservableCollection<SimpleGridColumn>();
      mColumns.CollectionChanged += OnColumnsCollectionChanged;

      ScrollVerticalSmallChange = GetVerticalScrollBarSmallChange();

      SizeChanged += OnSizeChanged;
      Loaded += OnLoaded;
    }

    #region Event handlers

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
      // While it is not loaded we don't draw anything
      Redraw();
    }

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();

      ApplyTemplateParts();
    }

    protected void ApplyTemplateParts()
    {
      if (HorizontalScrollBar != null)
      {
        HorizontalScrollBar.PreviewMouseLeftButtonDown -= OnScrollBarPreviewMouseLeftButtonDown;
        HorizontalScrollBar.PreviewTouchDown -= OnScrollBarPreviewTouchDown;
      }
      if (VerticalScrollBar != null)
      {
        VerticalScrollBar.PreviewMouseLeftButtonDown -= OnScrollBarPreviewMouseLeftButtonDown;
        VerticalScrollBar.PreviewTouchDown -= OnScrollBarPreviewTouchDown;
      }
      if (TouchScroller != null)
      {
        TouchScroller.BeforePreviewMouseLeftButtonDown -= OnTouchScrollerBeforePreviewMouseLeftButtonDown;
      }

      OnApplyTemplateParts();

      // Without the canvas we don't have a valid template
      IsTemplateApplied = Canvas != null;

      if (HorizontalScrollBar != null)
      {
        HorizontalScrollBar.PreviewMouseLeftButtonDown += OnScrollBarPreviewMouseLeftButtonDown;
        HorizontalScrollBar.PreviewTouchDown += OnScrollBarPreviewTouchDown;
      }
      if (VerticalScrollBar != null)
      {
        VerticalScrollBar.PreviewMouseLeftButtonDown += OnScrollBarPreviewMouseLeftButtonDown;
        VerticalScrollBar.PreviewTouchDown += OnScrollBarPreviewTouchDown;
      }
      if (TouchScroller != null)
      {
        TouchScroller.BeforePreviewMouseLeftButtonDown += OnTouchScrollerBeforePreviewMouseLeftButtonDown;
      }

      UpdateSize();
      Redraw();
    }

    protected virtual void OnApplyTemplateParts()
    {
      TouchScroller = GetTemplateChild(PART_TouchScrollerName) as TouchScrollerWrapper;
      if (TouchScroller != null)
      {
        TouchScroller.Create(this, ScrollLeftProperty, ScrollTopProperty);
      }

      Canvas = GetTemplateChild(PART_CanvasName) as Canvas;
      HorizontalScrollBar = GetTemplateChild(PART_HorizontalScrollBarName) as ScrollBar;
      VerticalScrollBar = GetTemplateChild(PART_VerticalScrollBarName) as ScrollBar;
    }

    private void OnTouchScrollerBeforePreviewMouseLeftButtonDown(object sender, HandledEventArgs<MouseButtonEventArgs> e)
    {
      if (HandlePointerDown(e.Data.GetPosition(Canvas), e.Data.ClickCount == 1))
      {
        e.Data.Handled = true;
      }
    }

    private bool HandlePointerDown(Point position, bool isPossiblyClick)
    {
      var wResult = false;

      // When mouse is down we flag what will be clicked
      mPossibleMouseClickItem = null;

      var wStoppedAnimation = StopAnimations();

      if (!wStoppedAnimation && isPossiblyClick)
      {
        var wVisibleIndex = GetVisibleRowIndex(position.Y);
        if (wVisibleIndex >= 0 && wVisibleIndex < mVisibleRows.Count)
        {
          var wClickedItem = mVisibleRows[wVisibleIndex];

          mPossibleMouseClickItem = new WeakReference<object>(wClickedItem.Data);
          mPossibleMouseClickPosition = position;

          if (SelectedItem == null || SelectedItem != wClickedItem.Data)
          {
            wResult = true;
          }
        }

        this.Focus();
      }

      if (wStoppedAnimation)
      {
        wResult = true;
      }

      return wResult;
    }

    private void OnScrollBarPreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      StopAnimations();
    }

    private void OnScrollBarPreviewTouchDown(object sender, TouchEventArgs e)
    {
      StopAnimations();
    }

    private void OnSizeChanged(object sender, SizeChangedEventArgs e)
    {
      // We need to validate the layout
      ValidateLayout();
      // and update the positions
      UpdateCanvasPosition();
    }

    private void OnColumnsCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
      switch (e.Action)
      {
        case NotifyCollectionChangedAction.Reset:
          {
            foreach (var wColumn in mAddedColumns)
            {
              RemoveColumn(wColumn);
            }

            mAddedColumns.Clear();
          }
          break;
        case NotifyCollectionChangedAction.Add:
          {
            foreach (SimpleGridColumn wColumn in e.NewItems)
            {
              AddColumn(wColumn);
              mAddedColumns.Add(wColumn);
            }
          }
          break;
        case NotifyCollectionChangedAction.Remove:
          {
            foreach (SimpleGridColumn wColumn in e.OldItems)
            {
              if (mAddedColumns.Remove(wColumn))
              {
                RemoveColumn(wColumn);
              }
            }
          }
          break;
        case NotifyCollectionChangedAction.Replace:
          {
            foreach (SimpleGridColumn wColumn in e.OldItems)
            {
              if (mAddedColumns.Remove(wColumn))
              {
                RemoveColumn(wColumn);
              }
            }

            foreach (SimpleGridColumn wColumn in e.NewItems)
            {
              AddColumn(wColumn);
              mAddedColumns.Add(wColumn);
            }
          }
          break;
      }

      if (!IsDrawEnabled) return;

      var wIndex = 0;
      foreach (var wColumn in Columns)
      {
        wColumn.Index = wIndex;
        wIndex++;
      }

      Redraw();
    }

    private void AddColumn(SimpleGridColumn column)
    {
      column.PropertyChanged += OnColumnPropertyChanged;
    }

    private void RemoveColumn(SimpleGridColumn column)
    {
      column.PropertyChanged -= OnColumnPropertyChanged;
    }

    private void OnColumnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
      Redraw();
    }

    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e)
    {
      if (HandlePointerUp(e.GetPosition(Canvas), e.ClickCount == 1))
      {
        e.Handled = true;
      }

      base.OnPreviewMouseLeftButtonUp(e);
    }

    private bool HandlePointerUp(Point position, bool isPossiblyClick)
    {
      var wResult = false;

      try
      {
        mIsUpdateingSelection = true;

        // If we really clicked select the element
        var wVisibleIndex = GetVisibleRowIndex(position.Y);

        if (wVisibleIndex >= 0 && wVisibleIndex < mVisibleRows.Count)
        {
          var wClickedItem = mVisibleRows[wVisibleIndex];

          var wIndex = wVisibleIndex + mFirstVisibleRow;
          var wPrevSelectedItem = SelectedItem;

          object wPossibleMouseClickItem;
          if (isPossiblyClick && mPossibleMouseClickItem != null && mPossibleMouseClickItem.TryGetTarget(out wPossibleMouseClickItem) && wClickedItem.Data == wPossibleMouseClickItem && GetDistance(position, mPossibleMouseClickPosition) < 4)
          {
            var wData = wClickedItem.Data;

            if (SelectedIndex.HasValue && IsMultiSelectEnabled && (Keyboard.Modifiers.HasFlag(ModifierKeys.Control) || Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)))
            {
              if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
              {
                // Select continiously from currently selected
                SelectedItem = wData;
                SelectedIndex = wIndex;

                if (mLastClickedIndex < wIndex)
                {
                  var wSelectedItems = GetSelectedItems();
                  var wHasChanged = false;

                  foreach (var wItem in ItemsSource.Skip(mLastClickedIndex + 1).Take(wIndex - mLastClickedIndex))
                  {
                    if (wSelectedItems.Add(wItem))
                    {
                      wHasChanged = true;
                    }
                  }

                  if (wHasChanged)
                  {
                    SelectedItems = wSelectedItems;
                  }
                }
                else
                {
                  var wSelectedItems = GetSelectedItems();
                  var wHasChanged = false;

                  foreach (var wItem in ItemsSource.Skip(wIndex).Take(mLastClickedIndex - wIndex))
                  {
                    if (wSelectedItems.Add(wItem))
                    {
                      wHasChanged = true;
                    }
                  }

                  if (wHasChanged)
                  {
                    SelectedItems = wSelectedItems;
                  }
                }
              }
              else
              {
                // Add to/remove from selection
                if (mVisibleRows[wVisibleIndex].IsSelected)
                {
                  var wSelectedItems = GetSelectedItems();
                  if (wSelectedItems.Remove(wData))
                  {
                    SelectedItems = wSelectedItems;
                  }

                  if (SelectedItem == wData)
                  {
                    SelectedItem = SelectedItems.LastOrDefault();
                    SelectedIndex = FindIndexOf(SelectedItem);
                  }
                }
                else
                {
                  SelectedItem = wData;
                  SelectedIndex = wVisibleIndex + mFirstVisibleRow;

                  var wSelectedItems = GetSelectedItems();
                  wSelectedItems.Add(wData);
                  SelectedItems = wSelectedItems;
                }

                mLastClickedIndex = wIndex;
              }
            }
            else
            {
              SelectedItem = wData;
              SelectedIndex = wIndex;
              SetSelectedItemsTo(wData);

              mLastClickedIndex = wIndex;
            }

            if (wPrevSelectedItem == null || wPrevSelectedItem != wClickedItem.Data)
            {
              wResult = true;
            }
          }
        }

        UpdateIsSelected();
      }
      finally
      {
        mIsUpdateingSelection = false;
        mPossibleMouseClickItem = null;
      }

      return wResult;
    }

    private double GetDistance(Point a, Point b)
    {
      var wX = a.X - b.X;
      var wY = a.Y - b.Y;
      return Math.Sqrt(wX * wX + wY * wY);
    }

    /// <summary>
    /// Returns the cell based on the visible index of row and column
    /// </summary>
    private SimpleGridCell GetCell(int rowIndex, int columnIndex)
    {
      if (rowIndex < 0 || rowIndex >= mVisibleRows.Count || columnIndex < 0 || columnIndex >= mVisibleColumns.Count) return null;

      return mVisibleRows[rowIndex].Cells[columnIndex];
    }

    private HashSet<object> GetSelectedItems()
    {
      HashSet<object> wHash = SelectedItems as HashSet<object>;
      if (wHash == null)
      {
        if (SelectedItems != null)
        {
          wHash = new HashSet<object>(SelectedItems);
        }
        else
        {
          wHash = new HashSet<object>();
        }
      }

      return wHash;
    }

    private void SetSelectedItemsTo(object data)
    {
      SelectedItems = new HashSet<object>
      {
        data
      };
    }

    protected override void OnTouchDown(TouchEventArgs e)
    {
      if (HandlePointerDown(e.GetTouchPoint(Canvas).Position, true))
      {
        e.Handled = true;
      }

      base.OnTouchDown(e);
    }

    protected override void OnTouchUp(TouchEventArgs e)
    {
      if (HandlePointerUp(e.GetTouchPoint(Canvas).Position, true))
      {
        e.Handled = true;
      }

      base.OnTouchUp(e);
    }

    protected override void OnMouseWheel(MouseWheelEventArgs e)
    {
      base.OnMouseWheel(e);
      StopVerticalAnimations();

      var wOrig = ScrollTop;
      ScrollTop -= e.Delta;

      if (wOrig != ScrollTop)
      {
        e.Handled = true;
      }
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
      switch (e.Key)
      {
        case Key.Up:
        case Key.Down:
        case Key.PageUp:
        case Key.PageDown:
        case Key.Home:
        case Key.End:
          HandleKey(e.Key, Keyboard.Modifiers);
          e.Handled = true;
          break;
        default:
          base.OnKeyDown(e);
          break;
      }
    }

    private void ChangeSelectedIndexBy(int diff)
    {
      ChangeSelectedIndexTo(SelectedIndex.HasValue ? SelectedIndex.Value + diff : diff);
    }

    private void ChangeSelectedIndexTo(int value)
    {
      if (value < 0)
      {
        value = 0;
      }
      else if (value > mRowCount - 1)
      {
        value = mRowCount - 1;
      }

      SelectedIndex = value;
      ScrollToIndex(value);
    }

    /// <summary>
    /// Handles a key press
    /// </summary>
    private void HandleKey(Key key, ModifierKeys modifier)
    {
      if (mRowCount == 0) return;

      switch (key)
      {
        case Key.Up:
          if (modifier == ModifierKeys.Control)
          {
            ChangeSelectedIndexTo(0);
          }
          else
          {
            ChangeSelectedIndexBy(-1);
          }
          break;
        case Key.Down:
          if (modifier == ModifierKeys.Control)
          {
            ChangeSelectedIndexTo(mRowCount - 1);
          }
          else
          {
            ChangeSelectedIndexBy(1);
          }
          break;
        case Key.PageUp:
          ChangeSelectedIndexBy(-mVisibleRows.Count);
          break;
        case Key.PageDown:
          ChangeSelectedIndexBy(mVisibleRows.Count);
          break;
        case Key.Home:
          ChangeSelectedIndexTo(0);
          break;
        case Key.End:
          ChangeSelectedIndexTo(mRowCount - 1);
          break;
      }
    }

    #endregion //Event handlers

    #region Update state

    /// <summary>
    /// Check if the visible column/row count is valid for the actual size
    /// </summary>
    private void ValidateLayout()
    {
      UpdateSize();
      ValidateColumns();
      ValidateRows();
    }

    /// <summary>
    /// Remove all visuals from the canvas
    /// </summary>
    private void Clear()
    {
      Canvas.Children.Clear();
      mVisibleRows.Clear();

      ValidateLayout();
    }

    private void UpdateSize()
    {
      if (!IsDrawEnabled) return;

      ClientWidth = ControlWidth - Padding.Left - Padding.Right;
      ClientHeight = ControlHeight - Padding.Top - Padding.Bottom;

      foreach (var wRow in mVisibleRows)
      {
        wRow.Element.Width = ControlWidth;
      }
    }

    private void UpdateRowStyle()
    {
      foreach (var row in mVisibleRows)
      {
        row.Style = RowStyle;
      }
    }

    private void UpdateSelectedRowStyle()
    {
      foreach (var row in mVisibleRows)
      {
        row.SelectedStyle = SelectedRowStyle;
      }
    }

    /// <summary>
    /// Check if the visible column count is valid for the actual width / column count
    /// </summary>
    private void ValidateColumns()
    {
      var wNext = Padding.Left;
      foreach (var wColumn in Columns)
      {
        wColumn.ComputedLeft = wNext;
        wNext += wColumn.GetWidth();
        wNext += ColumnGap;
      }

      VirtualWidth = wNext - ColumnGap;
      ScrollableWidth = Math.Max(0, VirtualWidth - ClientWidth);

      // We don't need to scroll this much
      if (ScrollLeft > ScrollableWidth)
      {
        mScrollDisabledDueToInternalManipulation = true;
        ScrollLeft = ScrollableWidth;
        mScrollDisabledDueToInternalManipulation = false;
      }

      var wNeedsScrolling = ScrollableWidth > 0;

      var wPrevVisibleColumnCount = mVisibleColumns.Count;
      mVisibleColumns.Clear();
      foreach (var wColumn in Columns)
      {
        var wLeft = wColumn.ComputedLeft;
        var wRight = wLeft + wColumn.GetWidth();

        if (!(wRight < ScrollLeft || wLeft > ScrollLeft + ClientWidth))
        {
          mVisibleColumns.Add(wColumn);
        }
      }

      var wDiff = mVisibleColumns.Count - wPrevVisibleColumnCount;
      // Column count changed
      if (wDiff > 0)
      {
        // Add elements
        for (var r = 0; r < mVisibleRows.Count; r++)
        {
          var wRow = mVisibleRows[r];
          for (var i = 0; i < wDiff; i++)
          {
            var wCell = CreateCell(mVisibleColumns[wPrevVisibleColumnCount + i]);
            wRow.AddCell(wCell);
            SetCanvasPosition(wCell);
          }
        }
      }
      else
      {
        // Remove elements
        wDiff = -wDiff;

        for (var r = 0; r < mVisibleRows.Count; r++)
        {
          var wRow = mVisibleRows[r];
          for (var i = 0; i < wDiff; i++)
          {
            var wCell = wRow.RemoveLastCell();
            RemoveCell(wCell);
          }
        }
      }

      foreach (var wRow in mVisibleRows)
      {
        var wColumnIndex = 0;
        foreach (var wCell in wRow.Cells)
        {
          wCell.Column = mVisibleColumns[wColumnIndex];

          wColumnIndex++;
        }
      }

      IsHorizontalScrollBarEnabled = wNeedsScrolling || HorizontalScrollBarVisibility == ScrollBarVisibility.Disabled;
      ComputedHorizontalScrollBarVisibility =
        HorizontalScrollBarVisibility == ScrollBarVisibility.Visible || (HorizontalScrollBarVisibility == ScrollBarVisibility.Auto && wNeedsScrolling)
          ? Visibility.Visible
          : Visibility.Collapsed;
    }

    private void RemoveCell(SimpleGridCell wCell)
    {
      wCell.ElementChanged -= OnCellElementChanged;

      if (wCell.Element != null)
      {
        RemoveCellElement(wCell.Element);
      }
    }

    /// <summary>
    /// Check if the visible row count is valid for the actual height / row count
    /// </summary>
    private void ValidateRows()
    {
      if (Canvas == null) return;

      mRowCount = ItemsSource != null ? ItemsSource.Count() : 0;

      VirtualHeight = mRowCount * RowHeight;

      UpdateVerticalScroll(false);

      if (ScrollTop > ScrollableHeight)
      {
        mScrollDisabledDueToInternalManipulation = true;
        ScrollTop = ScrollableHeight;
        mScrollDisabledDueToInternalManipulation = false;
      }

      var wNeedsScrolling = ScrollableHeight > 0;

      var wOrigVisbleRowCount = VisibleRowCount;

      mVisibleRowCount = Math.Min((int)Math.Ceiling(ClientHeight / RowHeight) + 1, mRowCount);
      VisibleRowCount = (int)Math.Ceiling(ClientHeight / RowHeight);

      if (VisibleRowCount != wOrigVisbleRowCount)
      {
        foreach (var wColumn in mColumns)
        {
          wColumn.CacheLength = VisibleRowCount + 2;
        }
      }

      var wDiff = mVisibleRowCount - mVisibleRows.Count;
      // Row count changed
      if (wDiff != 0)
      {
        if (wDiff > 0)
        {
          // Add elements
          for (var r = 0; r < wDiff; r++)
          {
            var wRow = new SimpleGridRow()
            {
              Style = RowStyle,
              SelectedStyle = SelectedRowStyle,
              Element = new Border(),
              Index = mFirstVisibleRow + mVisibleRows.Count
            };
            Canvas.SetZIndex(wRow.Element, mRowZIndex);
            wRow.Element.Height = RowHeight;
            wRow.Element.Width = ControlWidth;
            Canvas.Children.Add(wRow.Element);

            mVisibleRows.Add(wRow);
            for (var c = 0; c < mVisibleColumns.Count; c++)
            {
              var wCell = CreateCell(mVisibleColumns[c]);
              wCell.Row = wRow;
              wRow.AddCell(wCell);
            }

            SetCanvasPosition(wRow);
          }
        }
        else
        {
          // Remove elements
          wDiff = -wDiff;

          for (var r = 0; r < wDiff; r++)
          {
            var wRow = mVisibleRows[mVisibleRows.Count - 1];
            mVisibleRows.RemoveAt(mVisibleRows.Count - 1);
            Canvas.Children.Remove(wRow.Element);
            for (var c = 0; c < wRow.Cells.Count; c++)
            {
              RemoveCell(wRow.Cells[c]);
            }
          }
        }
      }

      IsVerticalScrollBarEnabled = wNeedsScrolling || VerticalScrollBarVisibility == ScrollBarVisibility.Disabled;
      ComputedVerticalScrollBarVisibility =
        VerticalScrollBarVisibility == ScrollBarVisibility.Visible || (VerticalScrollBarVisibility == ScrollBarVisibility.Auto && wNeedsScrolling)
          ? Visibility.Visible
          : Visibility.Collapsed;

      UpdateVisibleItems();
    }

    /// <summary>
    /// Update the positions on the canvas
    /// </summary>
    private void UpdateCanvasPosition()
    {
      foreach (var wRow in mVisibleRows)
      {
        SetCanvasPosition(wRow);
      }
    }

    /// <summary>
    /// Update the currently visible rows
    /// </summary>
    private void UpdateVisibleItems()
    {
      if (ItemsSource == null) return;

      var wRowIndex = 0;

      var itemsSource = ItemsSource;
      if (Sort != null)
      {
        itemsSource = Sort(itemsSource);
      }

      var wDataEnumerator = itemsSource.Skip(mFirstVisibleRow).GetEnumerator();
      foreach (var wRow in mVisibleRows)
      {
        wDataEnumerator.MoveNext();
        wRow.Index = wRowIndex + mFirstVisibleRow;
        wRow.IsFirst = wRow.Index == 0;
        wRow.IsLast = wRow.Index == mRowCount - 1;
        wRow.Data = wDataEnumerator.Current;
        wRow.IsSelected = SelectedItems != null && SelectedItems.Contains(wRow.Data);

        var wColumnIndex = 0;
        foreach (var wCell in wRow.Cells)
        {
          var wColumn = mVisibleColumns[wColumnIndex];
          wCell.Column = wColumn;

          wColumnIndex++;
        }

        wRowIndex++;
      }
    }

    /// <summary>
    /// Update the selected item
    /// </summary>
    private void UpdateSelectedItem()
    {
      if (mIsUpdateingSelection || ItemsSource == null) return;

      try
      {
        mIsUpdateingSelection = true;

        SelectedIndex = FindIndexOf(SelectedItem);
        SetSelectedItemsTo(SelectedItem);

        UpdateIsSelected();
      }
      finally
      {
        mIsUpdateingSelection = false;
      }
    }

    /// <summary>
    /// Update the selected item from index
    /// </summary>
    private void UpdateSelectedIndex()
    {
      if (mIsUpdateingSelection || ItemsSource == null) return;

      try
      {
        mIsUpdateingSelection = true;

        SelectedItem = SelectedIndex.HasValue ? ItemsSource.Skip(SelectedIndex.Value).FirstOrDefault() : null;
        SetSelectedItemsTo(SelectedItem);

        UpdateIsSelected();
      }
      finally
      {
        mIsUpdateingSelection = false;
      }
    }

    private void UpdateSelectedItems()
    {
      if (mIsUpdateingSelection || ItemsSource == null) return;

      try
      {
        mIsUpdateingSelection = true;

        SelectedItem = SelectedItems.LastOrDefault();
        SelectedIndex = (SelectedItems != null && SelectedItems.Any()) ? FindIndexOf(SelectedItem) : null;
        mLastClickedIndex = SelectedIndex ?? -1;

        UpdateIsSelected();
      }
      finally
      {
        mIsUpdateingSelection = false;
      }
    }

    private int? FindIndexOf(object data)
    {
      var wIndex = 0;

      foreach (var wItem in ItemsSource)
      {
        if (wItem == data) return wIndex;

        wIndex++;
      }

      return null;
    }

    private void UpdateIsSelected()
    {
      foreach (var wRow in mVisibleRows)
      {
        wRow.IsSelected = SelectedItems.Contains(wRow.Data);
      }
    }

    /// <summary>
    /// Updates the row height
    /// </summary>
    private void UpdateRowHeight()
    {
      ScrollVerticalSmallChange = GetVerticalScrollBarSmallChange();

      foreach (var wRow in mVisibleRows)
      {
        wRow.Element.Height = RowHeight;

        foreach (var wCell in wRow.Cells)
        {
          if (wCell.Element != null)
          {
            wCell.Element.Height = RowHeight;
          }
        }
      }
    }

    /// <summary>
    /// Updates the properties based on the vertical scroll state
    /// </summary>
    private void UpdateVerticalScroll(bool callUpdate)
    {
      ScrollableHeight = Math.Max(0, VirtualHeight - ClientHeight);

      if (ScrollTop > ScrollableHeight)
      {
        ScrollTop = ScrollableHeight;
      }

      IsTopOverflowIndicator = IsSmoothRowScrolling ? ScrollTop != 0 : ScrollTop >= RowHeight;
      IsBottomOverflowIndicator = ScrollTop + 1 < ScrollableHeight;

      var wPrevFirstVisibleRow = mFirstVisibleRow;
      mFirstVisibleRow = (int)Math.Floor(ScrollTop / RowHeight);
      FirstVisibleRow = mFirstVisibleRow;

      if (callUpdate)
      {
        if (IsSmoothRowScrolling || mFirstVisibleRow + mVisibleRowCount == mRowCount || wPrevFirstVisibleRow + mVisibleRowCount == mRowCount)
        {
          ValidateRows();
          UpdateCanvasPosition();
        }
        else
        {
          UpdateVisibleItems();
        }
      }
    }

    #endregion //Update state

    #region Drawing

    /// <summary>
    /// Invalidate the whole grid and redraw it
    /// </summary>
    private void Redraw()
    {
      if (!IsDrawEnabled) return;

      foreach (var wColumn in Columns)
      {
        wColumn.BuildCellStyle(CellStyles != null ? CellStyles.FirstOrDefault(f => f.TargetType.IsAssignableFrom(wColumn.ElementType)) : null);
      }

      Clear();
      ValidateLayout();
      ValidateRows();
    }

    /// <summary>
    /// Sets the position of a row on the canvas
    /// </summary>
    private void SetCanvasPosition(SimpleGridRow row)
    {
      var wTop = (row.Index - mFirstVisibleRow) * RowHeight;
      wTop -= GetVerticalOffset();

      var wColumnIndex = 0;
      foreach (var wCell in row.Cells)
      {
        if (wCell.Element != null)
        {
          Canvas.SetLeft(wCell.Element, mVisibleColumns[wColumnIndex].ComputedLeft - ScrollLeft);
          Canvas.SetTop(wCell.Element, wTop);
        }

        wColumnIndex++;
      }

      Canvas.SetTop(row.Element, wTop);
    }

    /// <summary>
    /// Sets the position of a cell on the canvas
    /// </summary>
    private void SetCanvasPosition(SimpleGridCell cell)
    {
      if (cell.Element != null)
      {
        Canvas.SetLeft(cell.Element, cell.Column.ComputedLeft - ScrollLeft);

        var wCellTop = Canvas.GetTop(cell.Row.Element);

        Canvas.SetTop(cell.Element, wCellTop);
      }
    }

    /// <summary>
    /// Suspend the drawing of the grid
    /// </summary>
    public void SuspendDraw()
    {
      mSuspendDrawCount++;
    }

    /// <summary>
    /// Resume drawing of the grid
    /// </summary>
    public void ResumeDraw()
    {
      mSuspendDrawCount--;
      Redraw();
    }

    #endregion //Drawing

    #region Helpers

    /// <summary>
    /// Creates a cell and adds it to the canvas
    /// </summary>
    /// <returns></returns>
    private SimpleGridCell CreateCell(SimpleGridColumn column)
    {
      var wCell = new SimpleGridCell()
      {
        Column = column
      };
      wCell.ElementChanged += OnCellElementChanged;

      if (wCell.Element != null)
      {
        AddCellElement(wCell.Element);
      }

      return wCell;
    }

    private void OnCellElementChanged(object sender, Tuple<FrameworkElement, FrameworkElement> e)
    {
      if (e.Item1 != null)
      {
        RemoveCellElement(e.Item1);
      }

      if (e.Item2 != null)
      {
        AddCellElement(e.Item2);
      }
    }

    private void AddCellElement(FrameworkElement element)
    {
      element.Height = RowHeight;

      Canvas.SetZIndex(element, mCellZIndex);
      Canvas.Children.Add(element);
    }

    private void RemoveCellElement(FrameworkElement element)
    {
      Canvas.Children.Remove(element);
    }

    /// <summary>
    /// Calculates the vertical position modifier based on scroll state
    /// </summary>
    /// <returns>Offset in pixels</returns>
    private double GetVerticalOffset()
    {
      if (IsSmoothRowScrolling)
      {
        return ScrollTop % RowHeight;
      }
      else if (mFirstVisibleRow + mVisibleRowCount == mRowCount && ScrollableHeight > 0 && ScrollTop > ScrollableHeight - RowHeight / 2)
      {
        return RowHeight - (ClientHeight % RowHeight);
      }

      return 0;
    }

    /// <summary>
    /// Returns the column index from the x position relative to the canvas
    /// </summary>
    protected int GetVisibleColumnIndex(double x)
    {
      x += ScrollLeft;

      return mVisibleColumns.FindIndex(f => f.ComputedLeft <= x && f.ComputedLeft + f.ComputedWidth > x);
    }

    /// <summary>
    /// Returns the row index from the y position relative to the canvas
    /// </summary>
    protected int GetVisibleRowIndex(double y)
    {
      y += GetVerticalOffset();

      return (int)Math.Floor((y - Padding.Top) / RowHeight);
    }

    private double GetVerticalScrollBarSmallChange()
    {
      return IsSmoothRowScrolling ? Math.Floor(Math.Max(1, RowHeight / 4)) : RowHeight;
    }

    #endregion //Helpers

    #region Animation

    private bool StopAnimations()
    {
      // Use of only 1 "|" is intentional
      return StopHorizontalAnimations() | StopVerticalAnimations();
    }

    private bool StopHorizontalAnimations()
    {
      return TouchScroller.TouchScroller.IsAnimating ? TouchScroller.TouchScroller.StopHorizontalAnimation() : false;
    }

    private bool StopVerticalAnimations()
    {
      // Use of only 1 "|" is intentional
      return (TouchScroller.TouchScroller.IsAnimating ? TouchScroller.TouchScroller.StopVerticalAnimation() : false) | StopScrollToAnimation(false);
    }

    public void ScrollToIndex(int value)
    {
      if (value < 0) return;
      if (value >= mRowCount) return;

      var wPartialHeight = ClientHeight % RowHeight;

      if (mFirstVisibleRow < value && (mFirstVisibleRow + mVisibleRowCount - (wPartialHeight > 0 ? 2 : 1)) > value) return;

      double wTop;

      if (mFirstVisibleRow >= value)
      {
        // Scroll to top
        wTop = RowHeight * value;
      }
      else
      {
        // Scroll to bottom
        wTop = RowHeight * (value - mVisibleRowCount + 1);
        if (wPartialHeight != 0)
        {
          wTop += IsSmoothRowScrolling ? (RowHeight - wPartialHeight) : RowHeight;
        }
      }

      if (Math.Abs(ScrollTop - wTop) < RowHeight * 2)
      {
        // Do not animate too small change
        ScrollTop = wTop;
      }
      else
      {
        ScrollToPixel(wTop);
      }
    }

    private void ScrollToPixel(double value)
    {
      StopVerticalAnimations();

      mScrollToStoryboard = new Storyboard();
      mScrollToAnimation = new DoubleAnimation()
      {
        To = value,
        Duration = TimeSpan.FromMilliseconds(Math.Min(mScrollToAnimationMaxDuration, mScrollToAnimationPerItemDuration * (Math.Abs(ScrollTop - value) / RowHeight))),
        EasingFunction = new ExponentialEase
        {
          EasingMode = EasingMode.EaseOut,
          Exponent = 1.05
        },
        FillBehavior = FillBehavior.HoldEnd
      };
      mScrollToStoryboard.Children.Add(mScrollToAnimation);

      Storyboard.SetTarget(mScrollToAnimation, this);
      Storyboard.SetTargetProperty(mScrollToAnimation, new PropertyPath(ScrollTopProperty.Name));

      mScrollToStoryboard.Completed += OnScrollToStoryboardCompleted;

      mScrollToStoryboard.Begin();
    }

    private bool StopScrollToAnimation(bool completed)
    {
      if (mScrollToStoryboard == null) return false;

      mScrollToStoryboard.Completed -= OnScrollToStoryboardCompleted;

      double wValue = completed ? mScrollToAnimation.To.Value : ScrollTop;

      mScrollToStoryboard.Stop();
      mScrollToStoryboard.Remove();

      ScrollTop = wValue;

      mScrollToAnimation = null;
      mScrollToStoryboard = null;

      return true;
    }

    private void OnScrollToStoryboardCompleted(object sender, EventArgs e)
    {
      StopScrollToAnimation(true);
    }

    #endregion //Animation

  }
}
