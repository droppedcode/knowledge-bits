﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid
{
  public enum SimpleGridColumnTemplate
  {
    Text,
    LeftTrimmedText,
    Input,
    LatLongInput,
    Xaml
  }
}
