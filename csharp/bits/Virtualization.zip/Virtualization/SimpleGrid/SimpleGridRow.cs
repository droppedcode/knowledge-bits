﻿using Cae.Iss.InstructionEditor.Core.Toolkit;
using Cae.Synapse.Foundation.Toolkit.Extensions;
using System.Collections.Generic;
using System.Windows;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid
{
  /// <summary>
  /// Simple wrapper for a row
  /// </summary>
  public class SimpleGridRow : NotificationObject
  {
    private int mIndex;

    public int Index
    {
      get { return mIndex; }
      set
      {
        if (mIndex == value) return;

        mIndex = value;
        NotifyPropertyChanged(this.NameOf(p => p.Index));
      }
    }

    private bool mIsFirst;

    public bool IsFirst
    {
      get { return mIsFirst; }
      set
      {
        if (mIsFirst == value) return;

        mIsFirst = value;
        NotifyPropertyChanged(this.NameOf(p => p.IsFirst));
      }
    }

    private bool mIsLast;

    public bool IsLast
    {
      get { return mIsLast; }
      set
      {
        if (mIsLast == value) return;

        mIsLast = value;
        NotifyPropertyChanged(this.NameOf(p => p.IsLast));
      }
    }

    private Style mStyle;

    public Style Style
    {
      get { return mStyle; }
      set
      {
        if (mStyle == value) return;

        mStyle = value;

        if (!IsSelected && Element != null)
        {
          Element.Style = mStyle;
        }

        NotifyPropertyChanged(this.NameOf(p => p.Style));
      }
    }

    private Style mSelectedStyle;

    public Style SelectedStyle
    {
      get { return mSelectedStyle; }
      set
      {
        if (mSelectedStyle == value) return;

        mSelectedStyle = value;

        if (IsSelected && Element != null)
        {
          Element.Style = mSelectedStyle;
        }

        NotifyPropertyChanged(this.NameOf(p => p.SelectedStyle));
      }
    }

    private bool mIsSelected;

    public bool IsSelected
    {
      get { return mIsSelected; }
      set
      {
        if (mIsSelected == value) return;

        mIsSelected = value;

        if (Element != null)
        {
          Element.Style = IsSelected ? (mSelectedStyle ?? mStyle) : mStyle;
        }

        NotifyPropertyChanged(this.NameOf(p => p.IsSelected));
      }
    }

    private FrameworkElement mElement;

    public FrameworkElement Element
    {
      get { return mElement; }
      set
      {
        if (mElement == value) return;

        if (mElement != null && mElement.DataContext == this)
        {
          mElement.DataContext = null;
        }

        mElement = value;

        if (mElement != null)
        {
          mElement.DataContext = this;
          mElement.Style = IsSelected ? (mSelectedStyle ?? mStyle) : mStyle;
        }

        NotifyPropertyChanged(this.NameOf(p => p.Element));
      }
    }

    private object mData;

    public object Data
    {
      get { return mData; }
      set
      {
        if (mData == value) return;

        mData = value;

        foreach (var wCell in Cells)
        {
          wCell.Data = mData;
        }

        NotifyPropertyChanged(this.NameOf(p => p.Data));
      }
    }

    private List<SimpleGridCell> mCells = new List<SimpleGridCell>();

    public IReadOnlyList<SimpleGridCell> Cells
    {
      get
      {
        return mCells;
      }
    }

    public void AddCell(SimpleGridCell cell)
    {
      cell.Row = this;
      cell.Data = Data;
      mCells.Add(cell);
    }

    public SimpleGridCell RemoveLastCell()
    {
      var wCell = mCells[mCells.Count - 1];
      mCells.RemoveAt(mCells.Count - 1);
      return wCell;
    }

  }
}