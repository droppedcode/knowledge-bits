﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid
{
  public class ElementDictionary<TKey, TValue> : IDictionary<TKey, TValue>, INotifyCollectionChanged, INotifyPropertyChanged
  {
    private const string cCount = "Count";
    private const string cIndexer = "Item[]";
    private const string cKeys = "Keys";
    private const string cValues = "Values";

    private IDictionary<TKey, TValue> mDictionary;

    protected IDictionary<TKey, TValue> Dictionary
    {
      get { return mDictionary; }
    }

    private bool mHasDefaultValue;
    private TValue mDefaultValue;

    public event EventHandler<ElementChangedEventArgs> ItemChanged;

    #region Constructors

    public ElementDictionary()
    {
      mDictionary = new Dictionary<TKey, TValue>();
    }

    public ElementDictionary(TValue defaultValue) : this()
    {
      SetDefaultValue(defaultValue);
    }

    public ElementDictionary(IDictionary<TKey, TValue> dictionary)
    {
      mDictionary = new Dictionary<TKey, TValue>(dictionary);
      foreach (var wItem in mDictionary)
      {
        BindValue(wItem.Value);
      }
    }

    public ElementDictionary(IEqualityComparer<TKey> comparer)
    {
      mDictionary = new Dictionary<TKey, TValue>(comparer);
    }

    public ElementDictionary(int capacity)
    {
      mDictionary = new Dictionary<TKey, TValue>(capacity);
    }

    public ElementDictionary(IDictionary<TKey, TValue> dictionary, IEqualityComparer<TKey> comparer)
    {
      mDictionary = new Dictionary<TKey, TValue>(dictionary, comparer);
      foreach (var wItem in mDictionary)
      {
        BindValue(wItem.Value);
      }
    }

    public ElementDictionary(int capacity, IEqualityComparer<TKey> comparer)
    {
      mDictionary = new Dictionary<TKey, TValue>(capacity, comparer);
    }

    #endregion

    #region IDictionary<TKey,TValue> Members

    public void Add(TKey key, TValue value)
    {
      Insert(key, value, true);
    }

    public bool ContainsKey(TKey key)
    {
      return Dictionary.ContainsKey(key);
    }

    public ICollection<TKey> Keys
    {
      get { return Dictionary.Keys; }
    }

    public bool Remove(TKey key)
    {
      if (key == null) throw new ArgumentNullException("key");

      TValue wValue;
      var wRemoved = Dictionary.TryGetValue(key, out wValue) && Dictionary.Remove(key);

      if (wRemoved)
      {
        UnbindValue(wValue);
        OnCollectionChanged(NotifyCollectionChangedAction.Remove, new KeyValuePair<TKey, TValue>(key, wValue));
      }

      return wRemoved;
    }

    public bool TryGetValue(TKey key, out TValue value)
    {
      return Dictionary.TryGetValue(key, out value);
    }

    public ICollection<TValue> Values
    {
      get { return Dictionary.Values; }
    }

    public TValue this[TKey key]
    {
      get
      {
        if (mHasDefaultValue)
        {
          TValue wValue;
          return Dictionary.TryGetValue(key, out wValue) ? wValue : mDefaultValue;
        }
        else
        {
          return Dictionary[key];
        }
      }
      set
      {
        Insert(key, value, false);
      }
    }

    #endregion

    #region ICollection<KeyValuePair<TKey,TValue>> Members

    public void Add(KeyValuePair<TKey, TValue> item)
    {
      Insert(item.Key, item.Value, true);
    }

    public void Clear()
    {
      if (Dictionary.Count > 0)
      {
        Dictionary.Clear();
        OnCollectionChanged();
      }
    }

    public bool Contains(KeyValuePair<TKey, TValue> item)
    {
      return Dictionary.Contains(item);
    }

    public void CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex)
    {
      Dictionary.CopyTo(array, arrayIndex);
    }

    public int Count
    {
      get { return Dictionary.Count; }
    }

    public bool IsReadOnly
    {
      get { return Dictionary.IsReadOnly; }
    }

    public bool Remove(KeyValuePair<TKey, TValue> item)
    {
      return Remove(item.Key);
    }

    #endregion

    #region IEnumerable<KeyValuePair<TKey,TValue>> Members

    public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
    {
      return Dictionary.GetEnumerator();
    }

    #endregion

    #region IEnumerable Members

    IEnumerator IEnumerable.GetEnumerator()
    {
      return ((IEnumerable)Dictionary).GetEnumerator();
    }

    #endregion

    #region INotifyCollectionChanged Members

    public event NotifyCollectionChangedEventHandler CollectionChanged;

    #endregion

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    #endregion

    public void AddRange(IDictionary<TKey, TValue> items)
    {
      if (items == null) throw new ArgumentNullException("items");

      if (items.Count > 0)
      {
        if (Dictionary.Count > 0)
        {
          if (items.Keys.Any((k) => Dictionary.ContainsKey(k)))
          {
            throw new ArgumentException("An item with the same key has already been added.");
          }
          else
          {
            foreach (var item in items)
            {
              Dictionary.Add(item);
            }
          }
        }
        else
        {
          mDictionary = new Dictionary<TKey, TValue>(items);
        }

        if (items.Count == 1)
        {
          OnCollectionChanged(NotifyCollectionChangedAction.Add, items.First());
        }
        else
        {
          OnCollectionChanged();
        }
      }
    }

    private void Insert(TKey key, TValue value, bool add)
    {
      if (key == null) throw new ArgumentNullException("key");

      TValue item;
      if (Dictionary.TryGetValue(key, out item))
      {
        if (add) throw new ArgumentException("An item with the same key has already been added.");
        if (Equals(item, value)) return;

        BindValue(value);
        Dictionary[key] = value;
        UnbindValue(item);

        OnCollectionChanged(NotifyCollectionChangedAction.Replace, new KeyValuePair<TKey, TValue>(key, value), new KeyValuePair<TKey, TValue>(key, item));
      }
      else
      {
        BindValue(value);
        Dictionary[key] = value;

        OnCollectionChanged(NotifyCollectionChangedAction.Add, new KeyValuePair<TKey, TValue>(key, value));
      }
    }

    private void BindValue(TValue value)
    {
      if (Values.Contains(value)) return;

      var wProperty = value as INotifyPropertyChanged;
      if (wProperty != null)
      {
        wProperty.PropertyChanged += OnItemPropertyChanged;
      }

      var wCollection = value as INotifyCollectionChanged;
      if (wCollection != null)
      {
        wCollection.CollectionChanged += OnItemCollectionChanged;
      }

      var wItem = value as ElementDictionary<TKey, TValue>;
      if (wItem != null)
      {
        wItem.ItemChanged += OnSubItemChanged;
      }
    }

    protected void RaiseItemChanged(TValue item, ElementChangedType type, string propertyName = null, ElementChangedEventArgs innerEvent = null)
    {
      var wHandler = ItemChanged;
      if (wHandler != null)
      {
        wHandler(this, new ElementChangedEventArgs(item, type, propertyName, innerEvent));
      }
    }

    private void OnItemPropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      RaiseItemChanged((TValue)sender, ElementChangedType.PropertyChanged, e.PropertyName);
    }

    private void OnItemCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
      RaiseItemChanged((TValue)sender, ElementChangedType.CollectionChanged);
    }

    private void OnSubItemChanged(object sender, ElementChangedEventArgs e)
    {
      RaiseItemChanged((TValue)sender, ElementChangedType.SubElementChanged, null, e);
    }

    private void UnbindValue(TValue value)
    {
      if (Values.Contains(value)) return;

      var wProperty = value as INotifyPropertyChanged;
      if (wProperty != null)
      {
        wProperty.PropertyChanged -= OnItemPropertyChanged;
      }

      var wCollection = value as INotifyCollectionChanged;
      if (wCollection != null)
      {
        wCollection.CollectionChanged -= OnItemCollectionChanged;
      }
    }

    private void OnPropertyChanged()
    {
      OnPropertyChanged(cCount);
      OnPropertyChanged(cIndexer);
      OnPropertyChanged(cKeys);
      OnPropertyChanged(cValues);
    }

    protected virtual void OnPropertyChanged(string propertyName)
    {
      var wHandler = PropertyChanged;
      if (wHandler != null)
      {
        wHandler(this, new PropertyChangedEventArgs(propertyName));
      }
    }


    private void OnCollectionChanged()
    {
      OnPropertyChanged();

      var wHandler = CollectionChanged;
      if (wHandler != null)
      {
        wHandler(this, new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
      }
    }

    private void OnCollectionChanged(NotifyCollectionChangedAction action, KeyValuePair<TKey, TValue> changedItem)
    {
      OnPropertyChanged();

      var wHandler = CollectionChanged;
      if (wHandler != null)
      {
        CollectionChanged(this, new NotifyCollectionChangedEventArgs(action, changedItem));
      }
    }

    private void OnCollectionChanged(NotifyCollectionChangedAction action, KeyValuePair<TKey, TValue> newItem, KeyValuePair<TKey, TValue> oldItem)
    {
      OnPropertyChanged();

      var wHandler = CollectionChanged;
      if (wHandler != null)
      {
        CollectionChanged(this, new NotifyCollectionChangedEventArgs(action, newItem, oldItem));
      }
    }

    public void SetDefaultValue(TValue value)
    {
      mHasDefaultValue = true;
      mDefaultValue = value;
    }

    public void RemoveDefaultValue()
    {
      mHasDefaultValue = false;
      mDefaultValue = default(TValue);
    }
  }
}
