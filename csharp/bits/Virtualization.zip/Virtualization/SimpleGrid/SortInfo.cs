﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid
{
  public class SortInfo
  {
    public string Path { get; set; }

    public bool IsDescending { get; set; }

  }
}
