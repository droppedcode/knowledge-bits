﻿// =====================================================================================================================
//  Avis de propriété:
//  L'information ci-incluse est confidentielle et/ou appartient à CAE Inc. Elle ne peut être reproduite ou divulguée,
//  en tout ou en partie, et ne peut être utilisée que selon les termes du contrat de licence conclu avec CAE Inc.
//  Copyright CAE Inc., 2017. Tous droits réservés.
// 
//  Proprietary notice:
//  The information contained herein is confidential and/or proprietary to CAE Inc. It shall not be reproduced or
//  disclosed in whole or in part, and may only be used in accordance with the terms of the License Agreement entered
//  into with CAE Inc.
//  Copyright CAE Inc., 2017. All Rights Reserved.
// =====================================================================================================================

using Cae.Synapse.Foundation.Toolkit;
using System.ComponentModel;
using System.Windows;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid
{
  partial class SimpleGridElement : IViewModel<SimpleGridElementVM>
  {
    public SimpleGridElement()
    {
      InitializeComponent();

      Loaded += CustomGrid_Loaded;
      Unloaded += CustomGrid_Unloaded;
    }

    public SimpleGridElementVM ViewModel { get; set; }

    private void CustomGrid_Loaded(object sender, RoutedEventArgs e)
    {
      if (ViewModel != null)
      {
        ViewModel.PropertyChanged += ViewModel_PropertyChanged;
        LoadGridColumns();
      }
    }

    private void CustomGrid_Unloaded(object sender, RoutedEventArgs e)
    {
      if (ViewModel != null) ViewModel.PropertyChanged -= ViewModel_PropertyChanged;
    }

    private void ViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      switch (e.PropertyName)
      {
        case "Columns":
          LoadGridColumns();
          break;
      }
    }

    private void LoadGridColumns()
    {
      if (mainGrid == null)
        return;

      mainGrid.SuspendDraw();
      mainGrid.Columns.Clear();

      if (ViewModel.Columns != null)
      {
        for (var wIndex = 0; wIndex < ViewModel.Columns.Length; wIndex++)
        {
          var wItem = ViewModel.Columns[wIndex];

          mainGrid.Columns.Add(wItem);
        }
      }

      mainGrid.ResumeDraw();
    }

  }
}