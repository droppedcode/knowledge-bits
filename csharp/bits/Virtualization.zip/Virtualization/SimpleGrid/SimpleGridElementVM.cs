﻿// =====================================================================================================================
//  Avis de propriété:
//  L'information ci-incluse est confidentielle et/ou appartient à CAE Inc. Elle ne peut être reproduite ou divulguée,
//  en tout ou en partie, et ne peut être utilisée que selon les termes du contrat de licence conclu avec CAE Inc.
//  Copyright CAE Inc., 2017. Tous droits réservés.
// 
//  Proprietary notice:
//  The information contained herein is confidential and/or proprietary to CAE Inc. It shall not be reproduced or
//  disclosed in whole or in part, and may only be used in accordance with the terms of the License Agreement entered
//  into with CAE Inc.
//  Copyright CAE Inc., 2017. All Rights Reserved.
// =====================================================================================================================

using Cae.Iss.Foundation.Contracts;
using Cae.Iss.IosControlLibrary.Controls.GenericList.Base;
using Cae.Iss.IosControlLibrary.Helpers;
using Cae.Iss.IosControlLibrary.Models;
using Cae.Iss.IosControlLibrary.Resources.Localization;
using Cae.OneUi.Foundation.Toolkit.Data;
using Cae.Synapse.Foundation.Toolkit;
using Cae.Synapse.Foundation.Toolkit.Extensions;
using Cae.Synapse.PageEditor.Foundation;
using Cae.Synapse.PageEditor.Foundation.Toolkit.Library;
using Cae.Synapse.PageEditor.Foundation.Toolkit.Library.Attributes;
using Cae.Synapse.PageEditor.Presentation.Helpers;
using Microsoft.Practices.Unity;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Windows.Threading;
using ValueUnitPair = Cae.Synapse.Foundation.Toolkit.ValueUnitPair;
using Element = Cae.Iss.IosControlLibrary.Controls.SimpleGrid.ElementDictionary<string, object>;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid
{
  // Based on the GenericList component
  /// <summary>
  /// Simple grid view model
  /// </summary>
  public class SimpleGridElementVM : ItemListBaseVM<Element>, IInlineEditionAware
  {
    /// <summary>
    /// Internal special name used for row index
    /// </summary>
    private const string cIndexKey = "$index";
    /// <summary>
    /// Internal special name used for row index + 1
    /// </summary>
    private const string cDisplayIndexKey = "$displayIndex";
    /// <summary>
    /// Internal special name used for original source json
    /// </summary>
    private const string cSource = "$source";
    /// <summary>
    /// Internal special name used for simple top level values
    /// </summary>
    private const string cValue = "$value";

    /// <summary>
    /// The default id column property name
    /// </summary>
    private const string cIdMapping = "id";
    private static TimeSpan cIgnoreServerSelectItemFor = TimeSpan.FromMilliseconds(3000);
    private static TimeSpan cIgnoreGridSelectItemFor = TimeSpan.FromMilliseconds(500);

    private SimpleGridColumn[] mColumns;
    private bool mForceDefaultSelection;
    private bool mHasPadding;
    private bool mHasSeparator;
    private string mIdMapping;
    private string mSortId;
    private string mSelectedValuePath;
    private object mDefaultSelectedValue;
    private readonly Dictionary<int, ListSortDirection?> mCurrentColumnSort = new Dictionary<int, ListSortDirection?>();
    private bool mForceReplaceWholeList;
    private bool mIsSmoothRowScrolling;
    private string mEditValue;
    private bool mHasStaticItems;
    private string mStaticItems;
    private Element[] mStaticItemsValue;
    private bool mIsMultiSelectEnabled;
    private string mUpdateItemId;

    private PageEditorListBoxItemSize mSize;
    private PageEditorLabelSize mFontSize;
    private TextFontWeight mFontWeight;

    private DispatcherTimer mServerSetSelectedTimer;
    private DispatcherTimer mGridSetSelectedTimer;
    private string mServerSetSelectedItemId;
    private bool mHasServerSetSelectedItem;
    private string mGridSetSelectedItemId;
    private IEnumerable<string> mItemIds;

    private bool mIsVirtualDataQuery;
    private string mCurrentFromId;
    private string mCurrentCountId;
    private int mCurrentFrom;
    private int mCurrentCount;
    private int mFirstVisibleRow;
    private int mVisibleRowCount;
    private double mVirtualPageBuffer;
    private static TimeSpan cUpdateQueryTime = TimeSpan.FromMilliseconds(100);
    private DispatcherTimer mUpdateQueryTimer;
    private static TimeSpan cUpdateItemTime = TimeSpan.FromMilliseconds(100);
    private DispatcherTimer mUpdateItemTimer;
    private readonly HashSet<Element> mUpdateItemQueue = new HashSet<Element>();
    private bool mIsForcingDefaultSelection;
    private InstructionResponse mSortResponse;

    public SimpleGridElementVM()
    {
      // Default values
      IdMapping = cIdMapping;

      HasPadding = true;
      HasSeparator = true;
      ForceReplaceWholeList = true;
      IsSmoothRowScrolling = true;
      Size = PageEditorListBoxItemSize.XLarge;
      FontSizes = PageEditorLabelSize.Medium;

      SelectedItems = new ObservableCollection<object>();

      // Delay handling and timers
      SetOnServerDelay = 0;
      DelaySelectedItemResponse = true;

      mServerSetSelectedTimer = new DispatcherTimer();
      mServerSetSelectedTimer.Interval = cIgnoreServerSelectItemFor;
      mServerSetSelectedTimer.Tick += OnServerSetSelectedTimerElapsed;

      mGridSetSelectedTimer = new DispatcherTimer();
      mGridSetSelectedTimer.Interval = cIgnoreGridSelectItemFor;
      mGridSetSelectedTimer.Tick += OnGridSetSelectedTimerElapsed;

      mUpdateQueryTimer = new DispatcherTimer();
      mUpdateQueryTimer.Interval = cUpdateQueryTime;
      mUpdateQueryTimer.Tick += OnUpdateQuery;

      mUpdateItemTimer = new DispatcherTimer();
      mUpdateItemTimer.Interval = cUpdateItemTime;
      mUpdateItemTimer.Tick += OnUpdateItem;
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [ControlProperty(localeKeys.cHasSeparator, localeKeys.cHasSeparator, false, typeof(locale))]
    [DefaultValue(true)]
    public bool HasSeparator
    {
      get { return mHasSeparator; }
      set
      {
        if (Equals(mHasSeparator, value)) return;
        mHasSeparator = value;
        NotifyPropertyChanged(this.NameOf(p => p.HasSeparator));
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [ControlProperty(localeKeys.cHasPadding, localeKeys.cHasPadding, false, typeof(locale))]
    [DefaultValue(true)]
    public bool HasPadding
    {
      get { return mHasPadding; }
      set
      {
        if (Equals(mHasPadding, value)) return;
        mHasPadding = value;
        NotifyPropertyChanged(this.NameOf(p => p.HasPadding));
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [ControlProperty(localeKeys.cIsSmoothRowScrolling, localeKeys.cIsSmoothRowScrolling, false, typeof(locale))]
    [DefaultValue(true)]
    public bool IsSmoothRowScrolling
    {
      get { return mIsSmoothRowScrolling; }
      set
      {
        if (Equals(mIsSmoothRowScrolling, value)) return;
        mIsSmoothRowScrolling = value;
        NotifyPropertyChanged(this.NameOf(p => p.IsSmoothRowScrolling));
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [DefaultValue(false)]
    [ControlProperty(localeKeys.cForceDefaultSelection, localeKeys.cForceDefaultSelection, false, typeof(locale))]
    public bool ForceDefaultSelection
    {
      get { return mForceDefaultSelection; }
      set
      {
        if (Equals(mForceDefaultSelection, value)) return;
        mForceDefaultSelection = value;
        NotifyPropertyChanged(this.NameOf(p => p.ForceDefaultSelection));
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [DefaultValue(true)]
    [ControlProperty(localeKeys.cForceReplaceWholeList, localeKeys.cForceReplaceWholeListDescription, false, typeof(locale))]
    public bool ForceReplaceWholeList
    {
      get { return mForceReplaceWholeList; }
      set
      {
        if (Equals(mForceReplaceWholeList, value)) return;
        mForceReplaceWholeList = value;
        NotifyPropertyChanged(this.NameOf(p => p.ForceReplaceWholeList));
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [ControlProperty(localeKeys.cItemSizeDisplayName, localeKeys.cItemSizeDisplayName, false, typeof(locale))]
    [DefaultValue(PageEditorListBoxItemSize.XLarge)]
    [LocalizedEnumValueDisplayName("Medium", localeKeys.cPageEditorListBoxItemSizeMedium, typeof(locale))]
    [LocalizedEnumValueDisplayName("Large", localeKeys.cPageEditorListBoxItemSizeLarge, typeof(locale))]
    [LocalizedEnumValueDisplayName("XLarge", localeKeys.cPageEditorListBoxItemSizeXLarge, typeof(locale))]
    [LocalizedEnumValueDisplayName("XXLarge", localeKeys.cPageEditorListBoxItemSizeXXLarge, typeof(locale))]
    public PageEditorListBoxItemSize Size
    {
      get { return mSize; }
      set
      {
        mSize = value;
        NotifyPropertyChanged(this.NameOf(p => p.Size));
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [ControlProperty(localeKeys.cSize, "Font Size", false, typeof(locale))]
    [DefaultValue(PageEditorLabelSize.Medium)]
    public PageEditorLabelSize FontSizes
    {
      get { return mFontSize; }
      set
      {
        if (Equals(mFontSize, value)) return;
        mFontSize = value;
        NotifyPropertyChanged(this.NameOf(p => p.FontSizes));
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [ControlProperty(localeKeys.cFontWeightDisplayName, localeKeys.cFontWeightDisplayName, false, typeof(locale))]
    [LocalizedEnumValueDisplayName("Normal", localeKeys.cFontWeightNormal, typeof(locale))]
    [LocalizedEnumValueDisplayName("Light", localeKeys.cFontWeightLight, typeof(locale))]
    [LocalizedEnumValueDisplayName("Bold", localeKeys.cFontWeightBold, typeof(locale))]
    [DefaultValue(TextFontWeight.Normal)]
    public TextFontWeight TextFontWeight
    {
      get { return mFontWeight; }
      set
      {
        if (Equals(mFontWeight, value)) return;
        mFontWeight = value;
        NotifyPropertyChanged(this.NameOf(p => p.TextFontWeight));
      }
    }

    [LocalizedCategory(localeKeys.cMappingProperties, typeof(locale))]
    [ControlProperty(localeKeys.cId, localeKeys.cId, false, typeof(locale))]
    [DefaultValue(cIdMapping)]
    public string IdMapping
    {
      get { return mIdMapping; }
      set
      {
        if (mIdMapping == value) return;

        if (string.IsNullOrEmpty(mIdMapping))
        {
          mIdMapping = cIdMapping;
        }
        else
        {
          mIdMapping = value;
        }

        NotifyPropertyChanged(this.NameOf(p => p.IdMapping));
      }
    }

    [LocalizedCategory(localeKeys.cMappingProperties, typeof(locale))]
    [ControlProperty(localeKeys.cSelectedValuePath, localeKeys.cSelectedValuePath, false, typeof(locale))]
    [DefaultValue(false)]
    public string SelectedValuePath
    {
      get { return mSelectedValuePath; }
      set
      {
        if (mSelectedValuePath == value) return;

        mSelectedValuePath = value;
        NotifyPropertyChanged(this.NameOf(p => p.SelectedValuePath));
      }
    }

    [LocalizedCategory(localeKeys.cMappingProperties, typeof(locale))]
    [ControlProperty(localeKeys.cDefaultSelectedValue, localeKeys.cDefaultSelectedValueDescription, false, typeof(locale))]
    [DefaultValue(false)]
    public string DefaultSelectedValue
    {
      get { return JsonConvert.SerializeObject(mDefaultSelectedValue); }
      set
      {
        var wValue = string.IsNullOrEmpty(value) ? null : JsonConvert.DeserializeObject(value);

        if (mDefaultSelectedValue == wValue) return;

        mDefaultSelectedValue = wValue;
        NotifyPropertyChanged(this.NameOf(p => p.DefaultSelectedValue));
      }
    }

    [LocalizedCategory(localeKeys.cGrid, typeof(locale))]
    [ControlProperty(localeKeys.cColumns, localeKeys.cColumns, false, typeof(locale))]
    [InlineEdition(localeKeys.cAddColumn, typeof(locale))]
    public SimpleGridColumn[] Columns
    {
      get { return mColumns; }
      set
      {
        if (mColumns == value) return;

        mColumns = value;

        if (mColumns != null)
        {
          foreach (var wColumn in mColumns)
          {
            UnityContainer.BuildUp(wColumn);
          }
        }

        NotifyPropertyChanged(this.NameOf(p => p.Columns));
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [DefaultValue(false)]
    [ControlProperty(localeKeys.cVirtualDataQuery, localeKeys.cVirtualDataQueryDescription, false, typeof(locale))]
    [AffectsProperties]
    public bool IsVirtualDataQuery
    {
      get { return mIsVirtualDataQuery; }
      set
      {
        if (Equals(mIsVirtualDataQuery, value)) return;
        mIsVirtualDataQuery = value;
        NotifyPropertyChanged(this.NameOf(p => p.IsVirtualDataQuery));
      }
    }

    /// <summary>
    /// Currently needed first item
    /// </summary>
    [LocalizedCategory(localeKeys.cInstructionService, typeof(locale))]
    [DefaultValue(null)]
    [InstructionBinding]
    [CustomEditor]
    [ControlProperty(localeKeys.cCurrentFrom, localeKeys.cCurrentFrom, false, typeof(locale))]
    [VisibleIf("IsVirtualDataQuery", CompareType.EqualTo, true)]
    public string CurrentFromId
    {
      get { return mCurrentFromId; }
      set
      {
        if (Equals(mCurrentFromId, value)) return;
        mCurrentFromId = value;
        NotifyPropertyChanged(this.NameOf(p => p.CurrentFromId));
      }
    }

    /// <summary>
    /// Currently needed item count from the CurrentFromId
    /// </summary>
    [LocalizedCategory(localeKeys.cInstructionService, typeof(locale))]
    [DefaultValue(null)]
    [InstructionBinding]
    [CustomEditor]
    [ControlProperty(localeKeys.cCurrentCount, localeKeys.cCurrentCount, false, typeof(locale))]
    [VisibleIf("IsVirtualDataQuery", CompareType.EqualTo, true)]
    public string CurrentCountId
    {
      get { return mCurrentCountId; }
      set
      {
        if (Equals(mCurrentCountId, value)) return;
        mCurrentCountId = value;
        NotifyPropertyChanged(this.NameOf(p => p.CurrentCountId));
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [DefaultValue(false)]
    [ControlProperty(localeKeys.cVirtualDataQueryPageBuffer, localeKeys.cVirtualDataQueryPageBuffer, false, typeof(locale))]
    [VisibleIf("IsVirtualDataQuery", CompareType.EqualTo, true)]
    public double VirtualPageBuffer
    {
      get { return mVirtualPageBuffer; }
      set
      {
        if (Equals(mVirtualPageBuffer, value)) return;
        mVirtualPageBuffer = Math.Max(value, 0);

        UpdateCurrentValues(true);

        NotifyPropertyChanged(this.NameOf(p => p.VirtualPageBuffer));
      }
    }

    [ControlProperty(localeKeys.cEditValue, localeKeys.cEditValue, false, typeof(locale))]
    [DefaultValue(null)]
    public string EditValue
    {
      get { return mEditValue; }
      set
      {
        if (mEditValue == value) return;
        mEditValue = value;
        NotifyPropertyChanged(this.NameOf(p => p.EditValue));

        CallFillData();
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [DefaultValue(false)]
    [ControlProperty(localeKeys.cHasStaticItems, localeKeys.cHasStaticItemsDescription, false, typeof(locale))]
    [AffectsProperties]
    public bool HasStaticItems
    {
      get { return mHasStaticItems; }
      set
      {
        if (Equals(mHasStaticItems, value)) return;
        mHasStaticItems = value;
        NotifyPropertyChanged(this.NameOf(p => p.HasStaticItems));

        CallFillData();
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [DefaultValue(false)]
    [ControlProperty(localeKeys.cStaticItems, localeKeys.cStaticItemsDescription, false, typeof(locale))]
    [VisibleIf("HasStaticItems", CompareType.EqualTo, true)]
    public string StaticItems
    {
      get { return mStaticItems; }
      set
      {
        if (Equals(mStaticItems, value)) return;
        mStaticItems = value;
        try
        {
          mStaticItemsValue = string.IsNullOrEmpty(mStaticItems) ? null : JsonConvert.DeserializeObject<JToken[]>(value).Select(DeserializeItem).ToArray();
        }
        catch
        {
          mStaticItemsValue = null;
        }

        NotifyPropertyChanged(this.NameOf(p => p.StaticItems));

        CallFillData();
      }
    }

    [LocalizedCategory(localeKeys.cProperties, typeof(locale))]
    [DefaultValue(false)]
    [ControlProperty(localeKeys.cMultiSelect, localeKeys.cMultiSelectDescription, false, typeof(locale))]
    public bool IsMultiSelectEnabled
    {
      get { return mIsMultiSelectEnabled; }
      set
      {
        if (Equals(mIsMultiSelectEnabled, value)) return;
        mIsMultiSelectEnabled = value;
        NotifyPropertyChanged(this.NameOf(p => p.IsMultiSelectEnabled));
      }
    }

    /// <summary>
    /// Instruction to update a changed item
    /// </summary>
    [LocalizedCategory(localeKeys.cInstructionService, typeof(locale))]
    [DefaultValue(null)]
    [InstructionBinding]
    [CustomEditor]
    [ControlProperty(localeKeys.cUpdateChanged, localeKeys.cUpdateChangedDescription, false, typeof(locale))]
    public string UpdateItemId
    {
      get { return mUpdateItemId; }
      set
      {
        if (Equals(mUpdateItemId, value)) return;
        mUpdateItemId = value;
        NotifyPropertyChanged(this.NameOf(p => p.UpdateItemId));
      }
    }

    /// <summary>
    /// Instruction to sort the items
    /// </summary>
    [LocalizedCategory(localeKeys.cInstructionService, typeof(locale))]
    [DefaultValue(null)]
    [InstructionBinding]
    [CustomEditor]
    [ControlProperty(localeKeys.cSortId, localeKeys.cSortIdDescription, false, typeof(locale))]
    public string SortId
    {
      get { return mSortId; }
      set
      {
        if (Equals(mSortId, value)) return;
        mSortId = value;
        NotifyPropertyChanged(this.NameOf(p => p.SortId));
      }
    }

    /// <summary>
    /// Selected item ids according the instruction
    /// </summary>
    public IEnumerable<string> ItemIds
    {
      get { return mItemIds; }
      set
      {
        if (Equals(mItemIds, value)) return;

        mItemIds = value;
        UpdateSelected();

        NotifyPropertyChanged(this.NameOf(p => p.ItemId));
      }
    }

    private IEnumerable<object> mSelectedItems;

    public IEnumerable<object> SelectedItems
    {
      get { return mSelectedItems; }
      set
      {
        if (mSelectedItems == value) return;

        mSelectedItems = value;
        SetSelectedItems(mSelectedItems.Cast<Element>(), !IsRefreshing);

        NotifyPropertyChanged(this.NameOf(p => p.SelectedItems));
      }
    }

    public int CurrentFrom
    {
      get { return mCurrentFrom; }
      set
      {
        if (!Equals(mCurrentFrom, value))
        {
          mCurrentFrom = value;
          NotifyPropertyChanged(this.NameOf(p => p.CurrentFrom));
        }

        // Always update
        mUpdateQueryTimer.Start();
      }
    }

    public int CurrentCount
    {
      get { return mCurrentCount; }
      set
      {
        if (!Equals(mCurrentCount, value))
        {
          mCurrentCount = value;
          NotifyPropertyChanged(this.NameOf(p => p.CurrentCount));
        }

        // Always update
        mUpdateQueryTimer.Start();
      }
    }

    private void OnUpdateQuery(object sender, EventArgs e)
    {
      mUpdateQueryTimer.Stop();

      if (!string.IsNullOrEmpty(CurrentFromId))
      {
        ResourceController.SetValue(new ResourceDescriptor { Urn = CurrentFromId, ValueUnitPair = new ValueUnitPair() { Value = CurrentFrom, Unit = "" } }, false, false, 0, GetElementName(this));
      }
      if (!string.IsNullOrEmpty(CurrentCountId))
      {
        ResourceController.SetValue(new ResourceDescriptor { Urn = CurrentCountId, ValueUnitPair = new ValueUnitPair() { Value = CurrentCount, Unit = "" } }, false, false, 0, GetElementName(this));
      }
    }

    public int FirstVisibleRow
    {
      get { return mFirstVisibleRow; }
      set
      {
        if (Equals(mFirstVisibleRow, value)) return;
        mFirstVisibleRow = value;

        UpdateCurrentValues(false);

        NotifyPropertyChanged(this.NameOf(p => p.FirstVisibleRow));
      }
    }

    public int VisibleRowCount
    {
      get { return mVisibleRowCount; }
      set
      {
        if (Equals(mVisibleRowCount, value)) return;
        mVisibleRowCount = value;

        UpdateCurrentValues(true);

        NotifyPropertyChanged(this.NameOf(p => p.VisibleRowCount));
      }
    }

    public bool DelaySelectedItemResponse { get; set; }

    public override Element SelectedItem
    {
      get { return base.SelectedItem; }
      set
      {
        //if (base.SelectedItem == value) return;

        //if (Equals(GetItemId(base.SelectedItem), GetItemId(value))) return;
        var wNewId = GetItemId(value);
        if (Equals(GetItemId(base.SelectedItem), wNewId))
        {
          if (DelaySelectedItemResponse && IsRefreshing && mServerSetSelectedTimer.IsEnabled && mHasServerSetSelectedItem)
          {
            // Special case, we can't ignore the server set because delay will overwrite the current value
            mServerSetSelectedItemId = wNewId;
          }
          // return;
        }


        // Find it in the current items list
        if (value != null && !Items.Contains(value))
        {
          value = GetItemById(GetItemId(value));
        }

        if (DelaySelectedItemResponse && !mIsForcingDefaultSelection)
        {
          if (IsRefreshing)
          {
            // Set from server response
            if (mServerSetSelectedTimer.IsEnabled)
            {
              mServerSetSelectedItemId = wNewId;
              mHasServerSetSelectedItem = true;
              // Server request is ignored, except if we are forcing default selection
              // Server request is ignored
              return;
            }
          }
          else
          {
            // Set from the UI
            mServerSetSelectedTimer.Stop();

            // Ignore previous (not set) server value
            mServerSetSelectedItemId = null;
            mHasServerSetSelectedItem = false;

            mServerSetSelectedTimer.Start();
          }
        }

        if (DelaySelectedItemResponse && !mIsForcingDefaultSelection && !IsRefreshing)
        {
          mGridSetSelectedItemId = wNewId;

          mGridSetSelectedTimer.Start();

          // We don't want to set it on server yet
          try
          {
            IsRefreshing = true;
            base.SelectedItem = value;
          }
          finally
          {
            IsRefreshing = false;
          }
        }
        else
        {
          base.SelectedItem = value;
          // Force setting on sever for default selection
          if (mIsForcingDefaultSelection && IsRefreshing)
          {
            SetSelectedItem(value, true);
          }
        }
      }
    }

    public InstructionResponse SortResponse
    {
      get { return mSortResponse; }
      set
      {
        if (Equals(mSortResponse, value)) return;

        mSortResponse = value;

        if (mSortResponse != null)
        {
          var sortInfo = mSortResponse.ParseValueAsJson<SortInfo>(Helpers.Extensions.ParseType.Value).FirstOrDefault();

          SortFunction = sortInfo != null ? GetSortFunction(sortInfo) : null;
        }

        NotifyPropertyChanged(this.NameOf(p => p.SortResponse));
      }
    }

    private Func<IEnumerable<object>, IEnumerable<object>> mSortFunction;

    public Func<IEnumerable<object>, IEnumerable<object>> SortFunction
    {
      get
      {
        return mSortFunction;
      }
      set
      {
        if (mSortFunction == value) return;

        mSortFunction = value;
        NotifyPropertyChanged(this.NameOf(p => p.SortFunction));
      }
    }

    private Func<IEnumerable<object>, IEnumerable<object>> GetSortFunction(SortInfo sortInfo)
    {
      return source =>
      {
        if (sortInfo == null) return source;
        if (source == null) return null;

        object value;
        return sortInfo.IsDescending
          ? source.OfType<Element>().OrderByDescending(d => d.TryGetValue(sortInfo.Path, out value) ? value : null)
          : source.OfType<Element>().OrderBy(d => d.TryGetValue(sortInfo.Path, out value) ? value : null)
          ;
      };
    }

    private void OnServerSetSelectedTimerElapsed(object sender, EventArgs e)
    {
      mServerSetSelectedTimer.Stop();

      if (mHasServerSetSelectedItem)
      {
        mHasServerSetSelectedItem = false;

        IsRefreshing = true;
        SelectedItem = GetItemById(mServerSetSelectedItemId);
        IsRefreshing = false;

        mServerSetSelectedItemId = null;
      }
    }

    private void OnGridSetSelectedTimerElapsed(object sender, EventArgs e)
    {
      mGridSetSelectedTimer.Stop();

      // Ignore previous (not set) server value
      mServerSetSelectedItemId = null;
      mHasServerSetSelectedItem = false;

      SetSelectedItem(GetItemById(mGridSetSelectedItemId), true);

      mGridSetSelectedItemId = null;
    }

    public void OnInlinePropertyChanged(string propertyName, string itemPropertyName, object itemChanged, object newValue)
    {
      NotifyPropertyChanged(this.NameOf(p => p.Columns));
    }

    protected override void OnPropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      base.OnPropertyChanged(sender, e);

      switch (e.PropertyName)
      {
        case "Columns":
          CallFillData();
          break;
      }
    }

    protected internal override void FillData(InstructionResponse response)
    {
      var wInstructionItem = (response == null || response.Items == null || response.Items.Count <= 0) ? null : response.Items.First();

      try
      {
        IsRefreshing = true;
        UpdateRows(wInstructionItem);
      }
      finally
      {
        IsRefreshing = false;
      }
    }

    /// <summary>
    /// Fill the control with dummy data
    /// </summary>
    protected internal override void FillWithDummyData()
    {
      var wJsonValue = string.IsNullOrEmpty(EditValue)
        ? "[{\"id\":\"9c7c8429-9c8c-4f8d-8309-bf5886c081ea\",\"ImageName\":\"Fire\",\"Text\":25.123456789,\"Title\":85.52214789,\"Subtitle\":698.2548956,\"TextContent\":\"TextContent1\"}," +
        "{\"id\":\"dc18ef89-123b-4ae9-b2bc-fbdb21d33850\",\"ImageName\":\"LightStation\",\"Text\":\"Text2\",\"Title\":\"Title2\",\"Subtitle\":\"Subtitle2\",\"TextContent\":\"TextContent2\"}," +
        "{\"id\":\"44e6cc0c-ad9a-4e40-901c-642f6aa95588\",\"ImageName\":\"PowerLine\",\"Text\":\"Text3\",\"Title\":\"Title3\",\"Subtitle\":\"Subtitle3\",\"TextContent\":\"TextContent3\"}," +
        "{\"id\":\"23efff2e-f467-4348-9ffc-0aec400fc67b\",\"ImageName\":\"Rocks\",\"Text\":\"Text4\",\"Title\":\"Title4\",\"Subtitle\":\"Subtitle4\",\"TextContent\":\"TextContent4\"}," +
        "{\"id\":\"c35a1781-430e-4fa9-88db-34dfb7823ec2\",\"ImageName\":\"Tree\",\"Text\":\"Text5\",\"Title\":\"Title5\",\"Subtitle\":\"Subtitle5\",\"TextContent\":\"TextContent5\"}]"
        : EditValue;

      UpdateRows(new InstructionItem() { Value = wJsonValue, UnitSymbol = null, Format = null });
    }

    /// <summary>
    /// Update all rows
    /// </summary>
    /// <param name="instructionItem">Source of the update</param>
    private void UpdateRows(InstructionItem instructionItem)
    {
      var wSelectedItem = SelectedItem;

      if (IsVirtualDataQuery)
      {
        VirtualizedDataResponse<JToken> wResponse = null;

        if (instructionItem != null)
        {
          try
          {
            wResponse = JsonConvert.DeserializeObject<VirtualizedDataResponse<JToken>>(instructionItem.Value);
          }
          catch
          {
          }
        }

        if (wResponse == null)
        {
          wResponse = new VirtualizedDataResponse<JToken>() { From = 0, Items = new JToken[0], TotalCount = 0 };
        }

        var wItems = PrepareData(wResponse.From, wResponse.Items);

        var wDiff = wResponse.TotalCount - (Items != null ? Items.Count : 0);

        // Probably changes on server side we need to get the current values again
        if (wResponse.Items.Length == 0 && CurrentCount == 0 && wDiff != 0)
        {
          UpdateCurrentValues(true);
        }

        if (ForceReplaceWholeList || Items == null || Math.Abs(wDiff) > VisibleRowCount * 2)
        {
          var wArr = (Element[])Array.CreateInstance(typeof(Element), wResponse.TotalCount);

          if (wItems.Length > 0)
          {
            wItems.CopyTo(wArr, wResponse.From);
          }

          if (Items != null)
          {
            foreach (var wItem in Items)
            {
              UnbindItem(wItem);
            }
          }

          Items = new OneObservableCollection<Element>(wArr);

          foreach (var wItem in Items)
          {
            BindItem(wItem);
          }

          if (wSelectedItem != null)
          {
            var wSelectedItemId = GetItemId(wSelectedItem);

            var wNewSelectedItem = wItems.FirstOrDefault(f => GetItemId(f) == wSelectedItemId);

            if (wNewSelectedItem != null)
            {
              wSelectedItem = wNewSelectedItem;
            }
          }
        }
        else
        {
          if (wDiff < 0)
          {
            wDiff = -wDiff;

            for (var i = 0; i < wDiff; i++)
            {
              UnbindItem(Items[Items.Count - 1]);
              Items.RemoveAt(Items.Count - 1);
            }
          }
          else if (wDiff > 0)
          {
            for (var i = 0; i < wDiff; i++)
            {
              Items.Add(null);
            }
          }

          for (var i = 0; i < wItems.Length; i++)
          {
            var wOldItem = Items[wResponse.From + i];
            var wNewItem = wItems[i];

            if (!IsSame(wOldItem, wNewItem))
            {
              UnbindItem(wOldItem);
              BindItem(wNewItem);

              Items[wResponse.From + i] = wNewItem;

              if (wOldItem == wSelectedItem)
              {
                wSelectedItem = wNewItem;
              }
            }
          }
        }

        if (wResponse.From == CurrentFrom && (wResponse.Items.Length == CurrentCount || CurrentFrom + wResponse.Items.Length == wResponse.TotalCount))
        {
          // Set it to zero to limit server processing
          CurrentCount = 0;
        }
      }
      else
      {
        JToken[] wValues;

        if (instructionItem != null)
        {
          try
          {
            wValues = JsonConvert.DeserializeObject<JToken[]>(instructionItem.Value);
          }
          catch
          {
            wValues = new JToken[0];
          }
        }
        else
        {
          wValues = new JToken[0];
        }

        var wItems = PrepareData(0, wValues);

        wSelectedItem = UpdateWholeList(wItems, wSelectedItem);
      }

      // Select from server response
      if (wSelectedItem == null && !string.IsNullOrEmpty(ItemsId))
      {
        wSelectedItem = GetItemById(ItemsId);
      }

      try
      {
        // Force selection
        if (wSelectedItem == null && ForceDefaultSelection && (SelectedItemId == null || SelectedItemResponse != null))
        {
          wSelectedItem = Items.FirstOrDefault();
          mIsForcingDefaultSelection = wSelectedItem != null;
        }

        // Set the selected item
        if (SelectedItem != wSelectedItem)
        {
          SelectedItem = wSelectedItem;
        }
      }
      finally
      {
        mIsForcingDefaultSelection = false;
      }
    }

    private Element[] PrepareData(int startIndex, JToken[] tokens)
    {
      var wItemsTemp = tokens.Select(DeserializeItem);

      if (HasStaticItems)
      {
        if (mStaticItemsValue != null)
        {
          wItemsTemp = mStaticItemsValue.Concat(wItemsTemp);
        }
        else
        {
          wItemsTemp = new Element[] { new Element((object)null) }.Concat(wItemsTemp);
        }
      }

      var wItems = wItemsTemp.ToArray();

      // Add meta information to the items
      var wIndex = startIndex;
      foreach (var wItem in wItems)
      {
        wItem[cIndexKey] = wIndex;
        wIndex++;
        wItem[cDisplayIndexKey] = wIndex;
      }

      return wItems;
    }

    private void OnItemCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
      OnItemChanged((Element)sender);
    }

    private void OnItemSubItemChanged(object sender, ElementChangedEventArgs e)
    {
      OnItemChanged((Element)sender);
    }

    private void OnItemChanged(Element item)
    {
      lock (mUpdateItemQueue)
      {
        mUpdateItemTimer.Stop();
        mUpdateItemQueue.Add(item);
        mUpdateItemTimer.Start();
      }
    }

    private void OnUpdateItem(object sender, EventArgs e)
    {
      lock (mUpdateItemQueue)
      {
        mUpdateItemTimer.Stop();

        foreach (var wItem in mUpdateItemQueue)
        {
          var wDict = new Dictionary<string, object>(wItem);
          wDict.Remove(cDisplayIndexKey);
          wDict.Remove(cIndexKey);
          wDict.Remove(cSource);

          ResourceController.SetValue(new ResourceDescriptor { Urn = UpdateItemId, ValueUnitPair = new ValueUnitPair() { Value = JsonConvert.SerializeObject(wDict), Unit = "" } }, false, false, 0, GetElementName(this));
        }

        mUpdateItemQueue.Clear();
      }
    }

    /// <summary>
    /// Update the whole list, used only if IsVirtualDataQuery = false
    /// </summary>
    private Element UpdateWholeList(Element[] items, Element selectedItem)
    {
      var wDiff = Math.Abs(items.Length - (Items != null ? Items.Count : 0));

      if (Items == null || Items.Count == 0 || ForceReplaceWholeList || wDiff > VisibleRowCount * 2)
      {
        if (Items != null)
        {
          foreach (var wItem in Items)
          {
            UnbindItem(wItem);
          }
        }

        Items = new OneObservableCollection<Element>(items);

        foreach (var wItem in Items)
        {
          BindItem(wItem);
        }

        var selectedItemId = GetItemId(selectedItem);
        selectedItem = Items.FirstOrDefault(f => GetItemId(f) == selectedItemId);
      }
      else
      {
        var wNewItems = items.ToDictionary(d => GetItemId(d) ?? d[cIndexKey].ToString());

        for (var i = Items.Count - 1; i >= 0; i--)
        {
          Element wNewItem;
          var wOldItem = Items[i];
          var wId = GetItemId(wOldItem) ?? wOldItem[cIndexKey].ToString();

          if (wNewItems.TryGetValue(wId, out wNewItem))
          {
            wNewItems.Remove(wId);
            if (!IsSame(wOldItem, wNewItem))
            {
              UnbindItem(wOldItem);
              Items[i] = wNewItem;
              BindItem(wNewItem);

              if (wOldItem == selectedItem)
              {
                selectedItem = wNewItem;
              }
            }
          }
          else
          {
            // It was removed
            Items.RemoveAt(i);

            UnbindItem(wOldItem);

            if (wOldItem == selectedItem)
            {
              selectedItem = null;
            }
          }
        }

        foreach (var wItem in wNewItems)
        {
          BindItem(wItem.Value);
        }

        Items.AddRange(wNewItems.Values);
      }

      return selectedItem;
    }

    private void BindItem(Element wItem)
    {
      if (wItem == null) return;

      wItem.CollectionChanged += OnItemCollectionChanged;
      wItem.ItemChanged += OnItemSubItemChanged;
    }

    private void UnbindItem(Element wItem)
    {
      if (wItem == null) return;

      wItem.CollectionChanged -= OnItemCollectionChanged;
      wItem.ItemChanged -= OnItemSubItemChanged;
    }

    private Element CreateDictionaryFromValue(object value)
    {
      var wDict = new Element((object)null);

      wDict[cValue] = value;

      return wDict;
    }

    private Element DeserializeItem(JToken item)
    {
      Element wResult;

      switch (item.Type)
      {
        case JTokenType.Object:
          wResult = (Element)DeserializeObject(item);
          break;
        case JTokenType.Array:
          wResult = CreateDictionaryFromValue(item.Select(DeserializeObject).ToArray());
          break;
        default:
          wResult = CreateDictionaryFromValue(((JValue)item).Value);
          break;
      }

      wResult[cSource] = JsonConvert.SerializeObject(item);

      return wResult;
    }

    private object DeserializeObject(JToken token)
    {
      switch (token.Type)
      {
        case JTokenType.Object:
          var wDict = new Element(token
            .Children<JProperty>()
            .ToDictionary(d => d.Name, d => DeserializeObject(d.Value)));
          wDict.SetDefaultValue(null);
          return wDict;
        case JTokenType.Array:
          return token.Select(DeserializeObject).ToList();
        default:
          return ((JValue)token).Value;
      }
    }

    /// <summary>
    /// Shallow compares two dictionaries
    /// </summary>
    /// <returns>True if the dictionaries are containing the same values</returns>
    private bool IsSame(Element a, Element b)
    {
      if (a == b) return true;

      if (a == null || b == null) return false;

      if (a.Count != b.Count) return false;
      foreach (var item in a)
      {
        if (b[item.Key] != item.Value) return false;
      }

      return true;
    }

    /// <summary>
    /// Returns the original data in ValueUnitPair for the item
    /// </summary>
    protected override ValueUnitPair GetOriginalItem(Element item)
    {
      if (item != null)
      {
        var wIndex = (int)item[cIndexKey];

        if (!string.IsNullOrEmpty(SelectedValuePath))
        {
          object wValue;
          return new ValueUnitPair
          {
            Value = JsonConvert.SerializeObject(item.TryGetValue(SelectedValuePath, out wValue) ? wValue : null),
            Unit = string.Empty
          };
        }
        else if (mIdMapping == cIndexKey)
        {
          // We want the index to be used

          return new ValueUnitPair
          {
            Value = JsonConvert.SerializeObject(wIndex),
            Unit = string.Empty
          };
        }
        else
        {
          return new ValueUnitPair
          {
            Value = item[cSource],
            Unit = string.Empty
          };
        }
      }
      else
      {
        return string.IsNullOrEmpty(SelectedValuePath) || DefaultSelectedValue == null ? null : new ValueUnitPair
        {
          // Use the deserialized value
          Value = JsonConvert.SerializeObject(mDefaultSelectedValue),
          Unit = string.Empty
        };
      }
    }

    /// <summary>
    /// Get an item by id
    /// </summary>
    /// <param name="value">String format of the id</param>
    /// <returns>The item or null</returns>
    public override Element GetItemById(string value)
    {
      if (value == null) return null;

      double wDoubleId;
      if (double.TryParse(value, System.Globalization.NumberStyles.Float, System.Globalization.NumberFormatInfo.InvariantInfo, out wDoubleId))
      {
        return Items.FirstOrDefault(f => f != null && Convert.ToDouble(f[IdMapping]) == wDoubleId);
      }
      else
      {
        object wValue;
        return Items.FirstOrDefault(f => f != null && (f.TryGetValue(IdMapping, out wValue) && wValue != null ? wValue.ToInvariantString() : null) == value);
      }
    }

    protected override string GetItemId(Element item)
    {
      object wId;
      return item != null && item.TryGetValue(mIdMapping, out wId) && wId != null ? wId.ToString() : null;
    }

    protected override string GetIdFromSelectedItemResponse(string json)
    {
      if (!string.IsNullOrEmpty(SelectedValuePath))
      {
        var wValue = JsonConvert.DeserializeObject(json);
        return wValue != null ? wValue.ToString() : null;
      }
      else if (IdMapping == cIndexKey)
      {
        int wIndex;
        return int.TryParse(json, out wIndex) ? wIndex.ToString() : null;
      }
      else
      {
        var wTemp = JsonConvert.DeserializeObject<Element>(json);

        object wValue;
        return wTemp.TryGetValue(IdMapping, out wValue) && wValue != null ? wValue.ToString() : null;
      }
    }

    /// <summary>
    /// Updates the current values based on the visible row values
    /// </summary>
    private void UpdateCurrentValues(bool force)
    {
      if (IsVirtualDataQuery)
      {
        var wPrevCurrentFrom = CurrentFrom;

        var wDiff = FirstVisibleRow - (int)Math.Ceiling(VirtualPageBuffer * VisibleRowCount);
        var wNewCurrentFrom = Math.Max(0, wDiff);

        // force an update at the beginning of the list (case wDiff is < 0), to avoid empty line,
        // which due to buffering might never be querried
        if (!force && wDiff >= 0 && Math.Abs(wPrevCurrentFrom - wNewCurrentFrom) < VirtualPageBuffer * VisibleRowCount / 2)
        {
          return;
        }

        CurrentFrom = wNewCurrentFrom;
        CurrentCount = (int)Math.Ceiling((2 * VirtualPageBuffer + 1) * VisibleRowCount);
      }
      else
      {
        CurrentFrom = 0;
        CurrentCount = 0;
      }
    }

    protected override void ParseSelectedItemResponse()
    {
      if (IsMultiSelectEnabled)
      {
        var wValues = SelectedItemResponse.ParseValueAsList();

        if (wValues != null && wValues.Count > 0)
        {
          ItemIds = wValues;
        }
        else
        {
          ItemIds = null;
        }
      }
      else
      {
        base.ParseSelectedItemResponse();
      }

      if (ForceDefaultSelection)
      {
        UpdateSelected();
      }
    }

    public override void UpdateSelected()
    {
      if (IsMultiSelectEnabled)
      {
        if (!IsSettingSelectedItem)
        {
          if (ItemIds == null)
          {
            SelectedItems = null;
          }
          else
          {
            var wItems = ItemIds.Select(s => GetItemById(s)).Where(w => w != null).ToArray();

            if (!IsSame(SelectedItems, wItems))
            {
              SelectedItems = wItems;
            }
          }
        }

        IsSelected = SelectedItems != null && SelectedItems.Any();
      }
      else
      {
        if (!IsSettingSelectedItem)
        {
          if (string.IsNullOrEmpty(ItemId))
          {
            if (ForceDefaultSelection)
            {
              try
              {
                mIsForcingDefaultSelection = true;
                SelectedItem = Items.FirstOrDefault();
              }
              finally
              {
                mIsForcingDefaultSelection = false;
              }
            }
            else
            {
              SelectedItem = null;
            }
          }
          else
          {
            SelectedItem = GetItemById(ItemId);
          }
        }

        IsSelected = SelectedItem != null;
      }
    }

    private bool IsSame(IEnumerable<object> a, IEnumerable<object> b)
    {
      if (a == b) return true;
      if (a == null || b == null) return false;
      if (a.Count() != b.Count()) return false;

      foreach (var wItem in a)
      {
        if (!b.Contains(wItem))
        {
          return false;
        }
      }

      return true;
    }

    protected override void SetSelectedItem(Element selectedItem, bool setOnServer)
    {
      if (!IsMultiSelectEnabled)
      {
        base.SetSelectedItem(selectedItem, setOnServer);
      }
    }

    protected void SetSelectedItems(IEnumerable<Element> selectedItems, bool setOnServer)
    {
      if (!IsMultiSelectEnabled) return;

      try
      {
        IsSettingSelectedItem = true;

        // Set the server value locally if we want it is not null or we want to change it on the server
        // It is possible that the selected value is updated first and after the list where the value exists
        if (selectedItems != null || setOnServer)
        {
          ItemIds = selectedItems != null ? selectedItems.Select(GetItemId).ToArray() : null;
        }

        if (setOnServer)
        {
          SetSelectedItemsOnServer(selectedItems, SetOnServerDelay);
        }

        if (selectedItems != null && selectedItems.Count() != 0)
        {
          SelectedExecuteActions();
        }
        else
        {
          UnSelectedExecuteActions();
        }
      }
      finally
      {
        IsSettingSelectedItem = false;
      }
    }

    private void SetSelectedItemsOnServer(IEnumerable<Element> selectedItems, int delay)
    {
      if (!string.IsNullOrEmpty(SelectedItemLocalKeyExpression))
      {
        ResourceController.SetValue(new ResourceDescriptor
        {
          Urn = SelectedItemLocalKeyExpression,
          ValueUnitPair = new ValueUnitPair
          {
            Value = JsonConvert.SerializeObject(selectedItems.Select(GetOriginalItem).ToArray()),
            Unit = string.Empty
          }
        }, true, false, delay, GetElementName(this));
      }

      if (!string.IsNullOrEmpty(SelectedItemId))
      {
        ResourceController.SetValue(new ResourceDescriptor
        {
          Urn = SelectedItemId,
          ValueUnitPair = new ValueUnitPair
          {
            Value = JsonConvert.SerializeObject(selectedItems.Select(GetOriginalItem).ToArray()),
            Unit = string.Empty
          }
        }, false, false, delay, GetElementName(this));
      }
    }

  }
}