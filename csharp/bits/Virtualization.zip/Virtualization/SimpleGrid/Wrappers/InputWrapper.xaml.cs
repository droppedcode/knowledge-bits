﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid.Wrappers
{
  /// <summary>
  /// Interaction logic for InputWrapper.xaml
  /// </summary>
  partial class InputWrapper : UserControl
  {
    public bool IsSelected
    {
      get { return (bool)GetValue(IsSelectedProperty); }
      set { SetValue(IsSelectedProperty, value); }
    }

    public static readonly DependencyProperty IsSelectedProperty = DependencyProperty.Register("IsSelected", typeof(bool), typeof(InputWrapper), new PropertyMetadata(false, OnIsSelectedChanged));

    private static void OnIsSelectedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((InputWrapper)d).OnIsSelectedChanged((bool)e.NewValue);
    }

    private void OnIsSelectedChanged(bool isSelected)
    {
      if (Resources != null)
      {
        Resources.Remove("PageEditor-100Opacity-TextBrush");
      }
      else
      {
        Resources = new ResourceDictionary();
      }

      if (isSelected)
      {
        var wBrush = TryFindResource("PageEditor-100Opacity-BackgroundBrush");
        if (wBrush != null)
        {
          Resources.Add("PageEditor-100Opacity-TextBrush", wBrush);
        }
      }
    }

    public string Value
    {
      get { return (string)GetValue(ValueProperty); }
      set { SetValue(ValueProperty, value); }
    }

    public static readonly DependencyProperty ValueProperty = DependencyProperty.Register("Value", typeof(string), typeof(InputWrapper), new FrameworkPropertyMetadata(null, OnValuePropertyChanged) { BindsTwoWayByDefault = true, DefaultUpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });

    private static void OnValuePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      var wSelf = (InputWrapper)d;
      if (wSelf.InputVM != null)
      {
        wSelf.UpdateValue();
      }
    }

    public string Unit
    {
      get { return (string)GetValue(UnitProperty); }
      set { SetValue(UnitProperty, value); }
    }

    public static readonly DependencyProperty UnitProperty = DependencyProperty.Register("Unit", typeof(string), typeof(InputWrapper), new PropertyMetadata(null, OnUnitPropertyChanged));

    private static void OnUnitPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      var wSelf = (InputWrapper)d;
      if (wSelf.InputVM != null)
      {
        wSelf.UpdateValue();
      }
    }

    private void UpdateValue()
    {
      InputVM.InstructionResponse = new Foundation.Contracts.InstructionResponse() { Items = new List<Foundation.Contracts.InstructionItem>() { new Foundation.Contracts.InstructionItem() { Value = Value != null ? Value.ToString() : null, UnitSymbol = Unit } } };
    }

    public InputWrapper()
    {
      InitializeComponent();
    }

    internal Input Input
    {
      get { return input; }
    }

    public InputVM InputVM
    {
      get { return input.ViewModel; }
      set
      {
        if (input.ViewModel == value) return;

        if (input.ViewModel != null)
        {
          input.ViewModel.PropertyChanged -= OnPropertyChanged;
        }

        input.ViewModel = value;
        input.DataContext = value;

        if (value != null)
        {
          value.Mode = Synapse.PageEditor.Presentation.Helpers.PageEditorTextBoxMode.Flat;
          value.IsInRuntime = true;

          value.PropertyChanged += OnPropertyChanged;
        }
      }
    }

    private void OnPropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      if (e.PropertyName == "Value")
      {
        Value = InputVM.Value;
      }
    }

  }
}
