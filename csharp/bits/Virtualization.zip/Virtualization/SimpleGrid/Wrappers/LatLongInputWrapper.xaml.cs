﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Cae.Iss.IosControlLibrary.Controls.LatLong;
using Cae.Iss.IosControlLibrary.Helpers;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid.Wrappers
{
  /// <summary>
  /// Interaction logic for LatLongInputWrapper.xaml
  /// </summary>
  internal partial class LatLongInputWrapper : UserControl
  {
    public bool IsSelected
    {
      get { return (bool)GetValue(IsSelectedProperty); }
      set { SetValue(IsSelectedProperty, value); }
    }

    public static readonly DependencyProperty IsSelectedProperty = DependencyProperty.Register("IsSelected", typeof(bool), typeof(LatLongInputWrapper), new PropertyMetadata(false, OnIsSelectedChanged));

    private static void OnIsSelectedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((LatLongInputWrapper)d).OnIsSelectedChanged((bool)e.NewValue);
    }

    private void OnIsSelectedChanged(bool isSelected)
    {
      if (Resources != null)
      {
        Resources.Remove("PageEditor-100Opacity-TextBrush");
      }
      else
      {
        Resources = new ResourceDictionary();
      }

      if (isSelected)
      {
        var wBrush = TryFindResource("PageEditor-100Opacity-BackgroundBrush");
        if (wBrush != null)
        {
          Resources.Add("PageEditor-100Opacity-TextBrush", wBrush);
        }
      }
    }

    public double? Latitude
    {
      get { return (double?)GetValue(LatitudeProperty); }
      set { SetCurrentValue(LatitudeProperty, value); }
    }

    public static readonly DependencyProperty LatitudeProperty = DependencyProperty.Register("Latitude", typeof(double?), typeof(LatLongInputWrapper), new FrameworkPropertyMetadata(null, OnLatitudePropertyChanged) { BindsTwoWayByDefault = true, DefaultUpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });

    private static void OnLatitudePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      var wSelf = (LatLongInputWrapper)d;
      if (wSelf.InputVM != null)
      {
        wSelf.InputVM.LatitudeResponse = new Foundation.Contracts.InstructionResponse() { Items = new List<Foundation.Contracts.InstructionItem>() { new Foundation.Contracts.InstructionItem() { Value = e.NewValue != null ? e.NewValue.ToString(): "0", Format = GetLatitudeFormat(wSelf.LatLongPrecisionMode) } } };
      }
    }

    private static string GetLatitudeFormat(LatLongPrecisionMode latLongPrecisionMode)
    {
      switch (latLongPrecisionMode)
      {
        case LatLongPrecisionMode.TwoDecimalsMinute:
          return "XX:XX.XX";
        case LatLongPrecisionMode.ThreeDecimalsMinute:
          return "XX:XX.XXX";
        case LatLongPrecisionMode.OneDecimalSecond:
          return "XX:XX:XX.X";
        case LatLongPrecisionMode.TwoDecimalsSecond:
        default:
          return "XX:XX:XX.XX";
      }
    }

    public double? Longitude
    {
      get { return (double?)GetValue(LongitudeProperty); }
      set { SetCurrentValue(LongitudeProperty, value); }
    }

    public static readonly DependencyProperty LongitudeProperty = DependencyProperty.Register("Longitude", typeof(double?), typeof(LatLongInputWrapper), new FrameworkPropertyMetadata(null, OnLongitudePropertyChanged) { BindsTwoWayByDefault = true, DefaultUpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });

    private static void OnLongitudePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      var wSelf = (LatLongInputWrapper)d;
      if (wSelf.InputVM != null)
      {
        wSelf.InputVM.LongitudeResponse = new Foundation.Contracts.InstructionResponse() { Items = new List<Foundation.Contracts.InstructionItem>() { new Foundation.Contracts.InstructionItem() { Value = e.NewValue != null ? e.NewValue.ToString() : "0", Format = GetLongitudeFormat(wSelf.LatLongPrecisionMode) } } };
      }
    }

    private static string GetLongitudeFormat(LatLongPrecisionMode latLongPrecisionMode)
    {
      switch (latLongPrecisionMode)
      {
        case LatLongPrecisionMode.TwoDecimalsMinute:
          return "XXX:XX.XX";
        case LatLongPrecisionMode.ThreeDecimalsMinute:
          return "XXX:XX.XXX";
        case LatLongPrecisionMode.OneDecimalSecond:
          return "XXX:XX:XX.X";
        case LatLongPrecisionMode.TwoDecimalsSecond:
        default:
          return "XXX:XX:XX.XX";
      }
    }

    public LatLongPrecisionMode LatLongPrecisionMode
    {
      get { return (LatLongPrecisionMode)GetValue(LatLongPrecisionModeProperty); }
      set { SetValue(LatLongPrecisionModeProperty, value); }
    }

    public static readonly DependencyProperty LatLongPrecisionModeProperty = DependencyProperty.Register("LatLongPrecisionMode", typeof(LatLongPrecisionMode), typeof(LatLongInputWrapper), new PropertyMetadata(LatLongPrecisionMode.TwoDecimalsSecond));

    public LatLongInputWrapper()
    {
      InitializeComponent();
    }

    public LatLongInput Input
    {
      get { return input; }
    }

    public LatLongInputVM InputVM
    {
      get { return input.ViewModel; }
      set
      {
        if (input.ViewModel == value) return;

        if (input.ViewModel != null)
        {
          input.ViewModel.LatInputField.PropertyChanged -= OnLatPropertyChanged;
          input.ViewModel.LonInputField.PropertyChanged -= OnLonPropertyChanged;
        }

        input.ViewModel = value;
        input.DataContext = value;

        if (value != null)
        {
          value.Mode = Synapse.PageEditor.Presentation.Helpers.PageEditorTextBoxMode.Flat;
          value.IsInRuntime = true;

          value.LatInputField.PropertyChanged += OnLatPropertyChanged;
          value.LonInputField.PropertyChanged += OnLonPropertyChanged;
        }
      }
    }

    private void OnLatPropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      if (e.PropertyName == "FormatedValue")
      {
        Latitude = InputVM.LatInputField.FormatedValue;
      }
    }

    private void OnLonPropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      if (e.PropertyName == "FormatedValue")
      {
        Longitude = InputVM.LonInputField.FormatedValue;
      }
    }
  }
}
