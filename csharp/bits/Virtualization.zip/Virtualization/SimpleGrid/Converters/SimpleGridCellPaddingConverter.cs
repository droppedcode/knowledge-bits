﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid.Converters
{
  /// <summary>
  /// Creates padding for a textblock in a cell simulating the vertical center positioning
  /// </summary>
  public class SimpleGridCellPaddingConverter : IMultiValueConverter
  {
    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
    {
      // values:
      // [0] Left/right padding
      // [1] Font size
      // [2] Row height

      return new Thickness(System.Convert.ToDouble(values[0]), (System.Convert.ToDouble(values[2]) - System.Convert.ToDouble(values[1])) / 2, System.Convert.ToDouble(values[0]), 0);
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }
}
