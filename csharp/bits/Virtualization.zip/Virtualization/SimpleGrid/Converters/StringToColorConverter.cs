﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid.Converters
{
  public class StringToColorConverter : IValueConverter
  {
    private static Dictionary<string, Brush> mColorCache = new Dictionary<string, Brush>();

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      Brush wBrush;
      var wValue = value as string;

      if (string.IsNullOrEmpty(wValue))
      {
        return DependencyProperty.UnsetValue;
      }

      if (!mColorCache.TryGetValue(wValue, out wBrush))
      {
        mColorCache[wValue] = wBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(wValue));
      }

      return wBrush;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }
}
