﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid.Converters
{
  public class ToDoubleConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      if (value == null) return 0d;
      if (value is double) return (double)value;

      var wType = value.GetType();

      try
      {
        return System.Convert.ToDouble(value);
      }
      catch
      {
        return 0d;
      }
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      return value;
    }
  }
}
