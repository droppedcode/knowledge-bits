﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace Cae.Iss.IosControlLibrary.Controls.SimpleGrid.Converters
{
  public class TextTrimConverter : IMultiValueConverter
  {
    private string mCacheKey;
    private Dictionary<string, double> mSizeCache = new Dictionary<string, double>();

    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
    {
      if (values.Length < 2) return DependencyProperty.UnsetValue;

      var wTextBlock = values[0] as TextBlock;

      if (wTextBlock == null) return DependencyProperty.UnsetValue;

      var wText = values[1] as string;

      if (wText == null) return null;

      var wSeparator = values.Length > 2 ? values[2] as string : null;

      var wWidth = wTextBlock.ActualWidth - wTextBlock.Padding.Left - wTextBlock.Padding.Right;

      if (wWidth >= MeasureString(wTextBlock, wText))
      {
        return wText;
      }
      else if (wWidth <= MeasureString(wTextBlock, "..."))
      {
        return "...";
      }
      else
      {
        var wSize = MeasureString(wTextBlock, wText);

        while (wSize > wWidth)
        {
          var wIndex = string.IsNullOrEmpty(wSeparator) ? 1 : (wText.IndexOf(wSeparator) + 1);
          wText = wIndex > 0 ? wText.Substring(wIndex).TrimStart() : "";
          wSize = MeasureString(wTextBlock, "..." + wText);
        }

        return "..." + wText;
      }
    }

    private double MeasureString(TextBlock textBlock, string candidate)
    {
      var wKey = string.Concat(textBlock.FontFamily, textBlock.FontStyle, textBlock.FontWeight, textBlock.FontStretch, textBlock.FontSize);

      if (wKey != mCacheKey)
      {
        mCacheKey = wKey;
        mSizeCache = new Dictionary<string, double>();
      }

      double wSize;
      if (mSizeCache.TryGetValue(candidate, out wSize))
      {
        return wSize;
      }

      var wFormattedText = new FormattedText(
        candidate,
        CultureInfo.CurrentCulture,
        FlowDirection.LeftToRight,
        new Typeface(textBlock.FontFamily, textBlock.FontStyle, textBlock.FontWeight, textBlock.FontStretch),
        textBlock.FontSize,
        Brushes.Black,
        new NumberSubstitution(),
        TextFormattingMode.Display
      );

      wSize = wFormattedText.Width;

      mSizeCache[candidate] = wSize;

      return wSize;
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }
}
