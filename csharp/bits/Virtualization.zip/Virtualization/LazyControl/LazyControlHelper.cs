﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Animation;

namespace Insight.Presentation.Helpers
{
  public static class LazyControlHelper
  {
    private static List<Tuple<FrameworkElement, Action>> mLazyList = new List<Tuple<FrameworkElement, Action>>();

    public static void LoadLazy(FrameworkElement control, Action initialize)
    {
      control.Opacity = 0;
      mLazyList.Add(new Tuple<FrameworkElement, Action>(control, initialize));

      if (mLazyList.Count == 1)
      {
        LoadNextIdle();
      }
    }

    private static void LoadNextIdle()
    {
      Application.Current.Dispatcher.BeginInvoke(new Action(LoadNext), System.Windows.Threading.DispatcherPriority.ApplicationIdle);
    }

    private static void LoadNext()
    {
      if (mLazyList.Count == 0) return;

      var wCurrent = mLazyList[0];
      mLazyList.RemoveAt(0);

      wCurrent.Item2();
      wCurrent.Item1.Dispatcher.BeginInvoke(new Action<FrameworkElement>(Show), System.Windows.Threading.DispatcherPriority.ApplicationIdle, wCurrent.Item1);
    }

    private static void Show(FrameworkElement control)
    {
      DoubleAnimation wOpacityAnimation = new DoubleAnimation();
      wOpacityAnimation.To = 1;
      wOpacityAnimation.Duration = new Duration(TimeSpan.FromSeconds(0.05d));
      wOpacityAnimation.AutoReverse = false;
      control.BeginAnimation(FrameworkElement.OpacityProperty, wOpacityAnimation);

      LoadNextIdle();
    }

  }

}
