﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insight.Presentation.Controls.VirtualGrid
{
  public enum Direction
  {
    None,
    Left,
    Right,
    Up,
    Down,
    PageUp,
    PageDown
  }
}
