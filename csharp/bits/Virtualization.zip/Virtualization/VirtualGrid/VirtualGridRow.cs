﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Insight.Presentation.Controls.VirtualGrid
{
  public class VirtualGridRow : Border
  {
    static VirtualGridRow()
    {
      DefaultStyleKeyProperty.OverrideMetadata(typeof(VirtualGridRow), new FrameworkPropertyMetadata(typeof(VirtualGridRow)));
    }

    public RowVisualData Row
    {
      get { return (RowVisualData)GetValue(RowProperty); }
      set { SetValue(RowProperty, value); }
    }

    public static readonly DependencyProperty RowProperty =
        DependencyProperty.Register("Row", typeof(RowVisualData), typeof(VirtualGridRow), new PropertyMetadata(null));

  }
}
