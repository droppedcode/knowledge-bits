﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Insight.Presentation.Controls.VirtualGrid
{
  /// <summary>
  ///     A control for displaying a cell of the VirtualGrid.
  /// </summary>
  public class VirtualGridCell : ContentControl, IVirtualGridCellPresenter
  {
    #region Constructors

    /// <summary>
    ///     Instantiates global information.
    /// </summary>
    static VirtualGridCell()
    {
      DefaultStyleKeyProperty.OverrideMetadata(typeof(VirtualGridCell), new FrameworkPropertyMetadata(typeof(VirtualGridCell)));
      KeyboardNavigation.TabNavigationProperty.OverrideMetadata(typeof(VirtualGridCell), new FrameworkPropertyMetadata(KeyboardNavigationMode.Local));

      // Set SnapsToDevicePixels to true so that this element can draw grid lines.  The metadata options are so that the property value doesn't inherit down the tree from here.
      SnapsToDevicePixelsProperty.OverrideMetadata(typeof(VirtualGridCell), new FrameworkPropertyMetadata(true, FrameworkPropertyMetadataOptions.AffectsArrange));

      EventManager.RegisterClassHandler(typeof(VirtualGridCell), MouseLeftButtonDownEvent, new MouseButtonEventHandler(OnAnyMouseLeftButtonDownThunk), true);
    }

    private static void OnAnyMouseLeftButtonDownThunk(object sender, MouseButtonEventArgs e)
    {
      ((VirtualGridCell)sender).OnAnyMouseLeftButtonDownThunk(e);
    }

    private void OnAnyMouseLeftButtonDownThunk(MouseButtonEventArgs e)
    {
      if (e.Handled) return;
      if (Cell.IsEditing) return;

      if (e.ClickCount == 1)
      {
        if (Keyboard.Modifiers == ModifierKeys.Shift)
        {
          Cell.Column.Grid.Select(SelectionSource.Cell, SelectionMode.Extend, Cell);
        }
        else if (Keyboard.Modifiers == ModifierKeys.Control)
        {
          Cell.Column.Grid.Select(SelectionSource.Cell, SelectionMode.Append, Cell);
        }
        else
        {
          Cell.Column.Grid.Select(SelectionSource.Cell, SelectionMode.Start, Cell);
        }
      }

      if (!Cell.Column.Column.IsReadOnly)
      {
        if ((Cell.Column.Grid.EditTriggers | VirtualGridEditTriggers.DoubleClick) == Cell.Column.Grid.EditTriggers && e.ClickCount == 2)
        {
          Cell.Column.Grid.EditCell(Cell);
        }
        else if ((Cell.Column.Grid.EditTriggers | VirtualGridEditTriggers.Click) == Cell.Column.Grid.EditTriggers && e.ClickCount == 1)
        {
          Cell.Column.Grid.EditCell(Cell);
        }
      }
    }

    public static int Created { get; set; }

    /// <summary>
    ///     Instantiates a new instance of this class.
    /// </summary>
    public VirtualGridCell()
    {
      Created++;
      //Application.Current.MainWindow.Title = "Created: " + Created;
    }

    #endregion

    public CellVisualData Cell
    {
      get { return (CellVisualData)GetValue(CellProperty); }
      set { SetValue(CellProperty, value); }
    }

    public static readonly DependencyProperty CellProperty =
        DependencyProperty.Register("Cell", typeof(CellVisualData), typeof(VirtualGridCell), new PropertyMetadata(null));

  }
}
