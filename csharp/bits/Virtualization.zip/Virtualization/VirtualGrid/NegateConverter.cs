﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace Insight.Presentation.Controls.VirtualGrid
{
  internal class NegateConverter : IValueConverter
  {
    public readonly static NegateConverter Instance = new NegateConverter();

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      var wValue = (double)value;
      return -wValue;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      var wValue = (double)value;
      return -wValue;
    }
  }
}
