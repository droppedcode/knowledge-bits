﻿namespace Insight.Presentation.Controls.VirtualGrid
{
  public interface IIsVisible
  {
    bool IsVisible { get; set; }
  }
}