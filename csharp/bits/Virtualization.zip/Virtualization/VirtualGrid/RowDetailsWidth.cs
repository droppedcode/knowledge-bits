﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insight.Presentation.Controls.VirtualGrid
{
  public enum RowDetailsWidth
  {
    /// <summary>
    /// Detail width will be measured
    /// </summary>
    Auto,
    /// <summary>
    /// The detail is fixed to the visible width
    /// </summary>
    VisibleWidth,
    /// <summary>
    /// The detail is the size of all of the columns
    /// </summary>
    TotalWidth
  }
}
