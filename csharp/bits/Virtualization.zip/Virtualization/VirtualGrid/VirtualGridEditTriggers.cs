﻿using System;

namespace Insight.Presentation.Controls.VirtualGrid
{
  [Flags]
  public enum VirtualGridEditTriggers
  {
    None = 0,
    Click = 1,
    DoubleClick = 2,
    Default = 2
  }
}