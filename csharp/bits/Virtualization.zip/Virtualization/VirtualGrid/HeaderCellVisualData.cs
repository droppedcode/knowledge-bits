﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insight.Presentation.Controls.VirtualGrid
{
  public class HeaderCellVisualData : CellVisualData
  {
    public HeaderCellVisualData(ColumnVisualData column, RowVisualData row) : base(column, row, null)
    {
    }
  }
}
