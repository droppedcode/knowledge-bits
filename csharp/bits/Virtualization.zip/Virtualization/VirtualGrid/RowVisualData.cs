﻿using Cae.OneUi.Foundation.Toolkit.Commands;
using Insight.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace Insight.Presentation.Controls.VirtualGrid
{
  public class RowVisualData : ObjectBase, IIsVisible
  {
    protected VirtualGrid Grid { get; private set; }
    private VirtualGridRow mElement;
    private FrameworkElement mDetailElement;

    public RowVisualData(VirtualGrid grid)
    {
      Grid = grid;
      Height = grid.RowHeight;
    }

    private int mIsNotifingCount;
    private bool mNotifyUpdateAvarageVirtualHeight;
    private bool mNotifyUpdateHorizontalPosition;
    private bool mNotifyUpdateVerticalVisibility;

    protected override void OnPropertyChanged([CallerMemberName] string propertyName = null)
    {
      base.OnPropertyChanged(propertyName);

      mIsNotifingCount++;

      if (!mIsSettingCells)
      {
        var wHeightChange = propertyName == "Height";
        var wCalculatedHeight = propertyName == "CalculatedHeight";
        if (wHeightChange || propertyName == "IsMeasured" || propertyName == "IsAllMeasured" || wCalculatedHeight)
        {
          mNotifyUpdateVerticalVisibility = true;
        }
        if (propertyName == "DetailWidth")
        {
          mNotifyUpdateHorizontalPosition = true;
        }
        if (wHeightChange)
        {
          mNotifyUpdateAvarageVirtualHeight = true;
          NotifyPropertyChanged("CalculatedHeight");
          NotifyPropertyChanged("DetailTop");
        }
        if (wCalculatedHeight)
        {
          NotifyPropertyChanged("CellCalculatedHeight");
        }
      }

      mIsNotifingCount--;

      if (mIsNotifingCount == 0)
      {
        if (mNotifyUpdateAvarageVirtualHeight)
        {
          Grid.UpdateAvarageVirtualHeight();
          mNotifyUpdateAvarageVirtualHeight = false;
        }
        if (mNotifyUpdateHorizontalPosition)
        {
          Grid.UpdateHorizontalPosition();
          mNotifyUpdateHorizontalPosition = false;
        }
        if (mNotifyUpdateVerticalVisibility)
        {
          Grid.UpdateVerticalVisibility();
          mNotifyUpdateVerticalVisibility = false;
        }
      }
    }

    private double mTop = double.NaN;

    public double Top
    {
      get { return mTop; }
      set
      {
        if (mTop == value) return;

        mTop = value;

        NotifyPropertyChanged();
        NotifyPropertyChanged("DetailTop");
      }
    }

    public double AbsoluteTop { get; internal set; }

    public double DetailTop
    {
      get { return Top + Height; }
    }

    private bool mHeightIsDefault = true;
    private double mHeight = double.NaN;

    public double Height
    {
      get { return mHeight; }
      set
      {
        if (mHeight == value && !mHeightIsDefault) return;

        mHeightIsDefault = false;
        mHeight = value;
        IsMeasured = !double.IsNaN(value);

        NotifyPropertyChanged();
      }
    }

    private bool mDetailHeightIsDefault = true;
    private double mDetailHeight = double.NaN;

    public double DetailHeight
    {
      get { return mDetailHeight; }
      set
      {
        if (mDetailHeight == value && !mDetailHeightIsDefault) return;

        mDetailHeightIsDefault = false;
        mDetailHeight = value;
        IsMeasured = !double.IsNaN(value);

        NotifyPropertyChanged();
        NotifyPropertyChanged("CalculatedHeight");
      }
    }

    private double mDetailWidth = double.NaN;

    public double DetailWidth
    {
      get { return mDetailWidth; }
      private set
      {
        if (mDetailWidth == value) return;

        mDetailWidth = value;

        NotifyPropertyChanged();
      }
    }

    private double mMinHeight = double.NaN;

    public double MinHeight
    {
      get { return mMinHeight; }
      set
      {
        if (mMinHeight == value) return;

        mMinHeight = value;
        NotifyPropertyChanged();
      }
    }

    private double mMaxHeight = double.NaN;

    public double MaxHeight
    {
      get { return mMaxHeight; }
      set
      {
        if (mMaxHeight == value) return;

        mMaxHeight = value;
        NotifyPropertyChanged();
      }
    }

    public double CellCalculatedHeight
    {
      get
      {
        return double.IsNaN(Height) ? Grid.AvarageRowHeight : Height;
      }
    }

    public double CalculatedHeight
    {
      get
      {
        var wHeight = IsOpened ? (Height + DetailHeight) : Height;
        return double.IsNaN(wHeight) ? Grid.AvarageRowHeight : wHeight;
      }
    }

    private bool mIsMeasured;

    public bool IsMeasured
    {
      get { return mIsMeasured; }
      private set
      {
        if (mIsMeasured == value) return;

        mIsMeasured = value;
        NotifyPropertyChanged();
      }
    }

    private bool mIsDetailMeasured;

    public bool IsDetailMeasured
    {
      get { return mIsDetailMeasured; }
      set
      {
        if (mIsDetailMeasured == value) return;

        mIsDetailMeasured = value;
        NotifyPropertyChanged();
      }
    }

    private bool mIsAllMeasured;

    public bool IsAllMeasured
    {
      get { return mIsAllMeasured; }
      private set
      {
        if (mIsAllMeasured == value) return;

        mIsAllMeasured = value;
        NotifyPropertyChanged();
      }
    }

    private bool mIsVisible;

    public bool IsVisible
    {
      get { return mIsVisible; }
      set
      {
        if (mIsVisible == value) return;

        mIsVisible = value;

        if (mIsVisible)
        {
          EnsureCells();
          AssignRowElement();
          if (IsOpened)
          {
            AssignDetailElement();
          }
        }
        else
        {
          FreeRowElement();
          if (IsOpened)
          {
            FreeDetailElement();
          }
        }

        NotifyPropertyChanged();
      }
    }

    private void AssignRowElement()
    {
      if (mElement == null)
      {
        mElement = Grid.GetRowElement(IsFrozen);
        mElement.Row = this;
      }
    }

    private void FreeRowElement()
    {
      if (mElement != null)
      {
        mElement.Row = null;
        Grid.FreeRowElement(mElement);
        mElement = null;
      }
    }

    private void AssignDetailElement()
    {
      if (mDetailElement == null)
      {
        mDetailElement = Grid.GetRowDetailElement(IsFrozen);
        mDetailElement.Tag = this;
        mDetailElement.DataContext = Data;
        mDetailElement.SizeChanged += DetailElement_SizeChanged;
        mDetailElement.Loaded += DetailElement_Loaded;

        if (!IsDetailMeasured)
        {
          Grid.MeasureDetail(this);
        }
        if (mDetailElement.IsLoaded)
        {
          UpdateDetailSize();
        }
      }
    }

    private void UpdateDetailSize()
    {
      DetailHeight = mDetailElement.ActualHeight;
      DetailWidth = mDetailElement.ActualWidth;
    }

    private void DetailElement_Loaded(object sender, RoutedEventArgs e)
    {
      UpdateDetailSize();
    }

    private void FreeDetailElement()
    {
      if (mDetailElement != null)
      {
        mDetailElement.Loaded -= DetailElement_Loaded;
        mDetailElement.SizeChanged -= DetailElement_SizeChanged;
        mDetailElement.DataContext = null;
        mDetailElement.Tag = null;
        Grid.FreeRowDetailElement(mDetailElement);
        mDetailElement = null;
      }
    }

    private void DetailElement_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      UpdateDetailSize();
    }

    private bool mIsOpened;

    public bool IsOpened
    {
      get { return mIsOpened; }
      set
      {
        if (mIsOpened == value) return;

        mIsOpened = value;

        if (mIsOpened)
        {
          if (IsVisible)
          {
            AssignDetailElement();
          }
        }
        else
        {
          if (IsVisible)
          {
            FreeDetailElement();
          }
        }

        NotifyPropertyChanged();
        NotifyPropertyChanged("CalculatedHeight");
      }
    }

    private ICommand mToggleOpenCommand;

    public ICommand ToggleOpenCommand
    {
      get { return mToggleOpenCommand ?? (mToggleOpenCommand = new RelayCommand((parameter) => ToggleOpen())); }
    }

    public void ToggleOpen()
    {
      IsOpened = !IsOpened;
    }

    List<string> mEnsureCellsCallers = new List<string>();

    internal void EnsureCells()
    {
      if (mIsSettingCells) return;
      mIsSettingCells = true;

      if (mCells.Count == 0)
      {
        CreateCells();
        foreach (var wCell in mCells)
        {
          Grid.MeasureCell(wCell);
        }
        IsAllMeasured = mCells.Count != 0 && mCells.All(a => a.IsMeasured || (a.Column.IsMeasured && a.Row.IsMeasured));
      }

      if (IsOpened)
      {
        AssignDetailElement();
      }
      if (IsVisible)
      {
        AssignRowElement();
      }

      foreach (var wCell in mCells)
      {
        if (wCell.IsVisible)
        {
          wCell.AssignElement();
        }
      }

      mIsSettingCells = false;
    }

    protected virtual void CreateCells()
    {
      foreach (var wColumn in Grid.ColumnDatas)
      {
        new CellVisualData(wColumn, this, Data);
      }
    }

    private bool mIsFrozen;

    public bool IsFrozen
    {
      get { return mIsFrozen; }
      set
      {
        if (mIsFrozen == value) return;

        mIsFrozen = value;
        NotifyPropertyChanged();
      }
    }

    private bool mIsSettingCells;

    private List<CellVisualData> mCells = new List<CellVisualData>();
    public IEnumerable<CellVisualData> Cells { get { return mCells; } }

    internal void AddCell(CellVisualData cell)
    {
      if (mCells.Count > Grid.ColumnDatas.Count)
      {
        System.Diagnostics.Debugger.Break();
      }

      mCells.Add(cell);
      if (!mIsSettingCells)
      {
        Grid.MeasureCell(cell);
        IsAllMeasured = mCells.Count != 0 && mCells.All(a => a.IsMeasured || (a.Column.IsMeasured && a.Row.IsMeasured));
      }
    }

    internal void RemoveCell(CellVisualData cell)
    {
      mCells.Remove(cell);
      IsAllMeasured = mCells.Count != 0 && mCells.All(a => a.IsMeasured || (a.Column.IsMeasured && a.Row.IsMeasured));
    }

    private object mData;

    public object Data
    {
      get { return mData; }
      set
      {
        if (mData == value) return;

        mData = value;

        foreach (var wCell in mCells)
        {
          wCell.Data = mData;
        }

        NotifyPropertyChanged();
      }
    }

    public void RemoveCellsFromGrid()
    {
      FreeRowElement();
      FreeDetailElement();
      foreach (var wCell in mCells.ToArray())
      {
        wCell.RemoveFromGrid();
      }
      mCells.Clear();
    }

    public void FreeElements()
    {
      FreeRowElement();
      FreeDetailElement();
      foreach (var wCell in mCells)
      {
        if (wCell.Element != null)
        {
          wCell.FreeElement();
        }
      }
    }

    private Brush mBackground;

    public Brush Background
    {
      get { return mBackground; }
      set
      {
        if (mBackground == value) return;

        mBackground = value;
        NotifyPropertyChanged();
      }
    }

    public override string ToString()
    {
      return "Top" + ": " + Top + ", " +
             "IsVisible" + ": " + IsVisible + ", " +
             "IsFrozen" + ": " + IsFrozen;
    }

    internal void CellMeasured(CellVisualData cell)
    {
      if (!IsMeasured)
      {
        var wHeight = Height;
        if (double.IsNaN(wHeight) || cell.MeasuredSize.Value.Height > wHeight)
        {
          wHeight = cell.MeasuredSize.Value.Height;
        }
        UpdateHeight(wHeight);
        IsMeasured = mCells.All(a => a.IsMeasured);
      }
      if (cell.IsMeasured)
      {
        IsAllMeasured = mCells.All(a => a.IsMeasured || (a.Column.IsMeasured && a.Row.IsMeasured));
      }
    }

    private void UpdateHeight(double height)
    {
      if (!double.IsNaN(MinHeight) && MinHeight > height)
      {
        height = MinHeight;
      }
      if (!double.IsNaN(MaxHeight) && MaxHeight < height)
      {
        height = MaxHeight;
      }
      if (mHeight != height)
      {
        mHeight = height;
        NotifyPropertyChanged("Height");
      }
    }

    public void AutoSize()
    {
      var wCells = mCells.Where(w => w.IsMeasured).ToList();
      if (wCells.Count > 0)
      {
        UpdateHeight(wCells.Max(m => m.MeasuredSize.Value.Height));
      }
      else
      {
        UpdateHeight(0);
      }
    }

  }
}
