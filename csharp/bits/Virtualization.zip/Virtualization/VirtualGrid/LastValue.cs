﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Insight.Presentation.Controls.VirtualGrid
{
  public class LastValue : FrameworkElement
  {
    public object Value
    {
      get { return (object)GetValue(ValueProperty); }
      set { SetValue(ValueProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Value.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ValueProperty =
        DependencyProperty.Register("Value", typeof(object), typeof(LastValue), new PropertyMetadata(null, null, new CoerceValueCallback(OnCoerceValue)));

    private static object OnCoerceValue(DependencyObject d, object value)
    {
      return ((LastValue)d).OnCoerceValue(value);
    }

    private object mLastValue;

    private object OnCoerceValue(object value)
    {
      if (value != null)
      {
        mLastValue = value;
      }
      return mLastValue;
    }

  }
}
