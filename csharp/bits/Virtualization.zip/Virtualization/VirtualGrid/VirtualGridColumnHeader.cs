﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;

namespace Insight.Presentation.Controls.VirtualGrid
{
  /// <summary>
  /// Represents the header for each column of the DataGrid
  /// </summary>
  [TemplatePart(Name = LeftHeaderGripperTemplateName, Type = typeof(Thumb))]
  [TemplatePart(Name = RightHeaderGripperTemplateName, Type = typeof(Thumb))]
  [TemplatePart(Name = HeaderDragTemplateName, Type = typeof(Thumb))]
  public class VirtualGridColumnHeader : ContentControl, IVirtualGridCellPresenter
  {
    static VirtualGridColumnHeader()
    {
      DefaultStyleKeyProperty.OverrideMetadata(typeof(VirtualGridColumnHeader), new FrameworkPropertyMetadata(typeof(VirtualGridColumnHeader)));

      FocusableProperty.OverrideMetadata(typeof(VirtualGridColumnHeader), new FrameworkPropertyMetadata(false));
    }

    #region Layout

    /// <summary>
    ///     Property that indicates the brush to use when drawing seperators between headers.
    /// </summary>
    public Brush SeparatorBrush
    {
      get { return (Brush)GetValue(SeparatorBrushProperty); }
      set { SetValue(SeparatorBrushProperty, value); }
    }

    /// <summary>
    ///     DependencyProperty for SeperatorBrush.
    /// </summary>
    public static readonly DependencyProperty SeparatorBrushProperty =
        DependencyProperty.Register("SeparatorBrush", typeof(Brush), typeof(VirtualGridColumnHeader), new FrameworkPropertyMetadata(null));

    /// <summary>
    ///     Property that indicates the Visibility for the header seperators.
    /// </summary>
    public Visibility SeparatorVisibility
    {
      get { return (Visibility)GetValue(SeparatorVisibilityProperty); }
      set { SetValue(SeparatorVisibilityProperty, value); }
    }

    /// <summary>
    ///     DependencyProperty for SeperatorBrush.
    /// </summary>
    public static readonly DependencyProperty SeparatorVisibilityProperty =
        DependencyProperty.Register("SeparatorVisibility", typeof(Visibility), typeof(VirtualGridColumnHeader), new FrameworkPropertyMetadata(Visibility.Visible));

    #endregion

    #region Column Communication

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();

      // Grippers will now be in the Visual tree.
      HookupGripperEvents();
    }

    #endregion

    #region Selection

    /// <summary>
    ///     Indicates whether the owning DataGridColumn is selected.
    /// </summary>
    [Bindable(true), Category("Appearance")]
    public bool IsColumnSelected
    {
      get { return (bool)GetValue(IsColumnSelectedProperty); }
    }

    private static readonly DependencyPropertyKey IsColumnSelectedPropertyKey =
        DependencyProperty.RegisterReadOnly(
            "IsColumnSelected",
            typeof(bool),
            typeof(VirtualGridColumnHeader),
            new FrameworkPropertyMetadata(false));

    /// <summary>
    ///     The DependencyProperty for the IsColumnSelected property.
    /// </summary>
    public static readonly DependencyProperty IsColumnSelectedProperty = IsColumnSelectedPropertyKey.DependencyProperty;

    #endregion

    #region Column Resizing

    /// <summary>
    /// Find grippers and register drag events
    ///
    /// The default style for DataGridHeader is
    /// +-------------------------------+
    /// +---------+           +---------+
    /// + Gripper +  Header   + Gripper +
    /// +         +           +         +
    /// +---------+           +---------+
    /// +-------------------------------+
    ///
    /// The reason we have two grippers is we can't extend the right gripper to straddle the line between two
    /// headers; the header to the right would render on left of it.
    /// We resize a column by grabbing the gripper to the right; the leftmost gripper thus adjusts the width of
    /// the column to its left.
    /// </summary>
    private void HookupGripperEvents()
    {
      UnhookGripperEvents();

      mLeftGripper = GetTemplateChild(LeftHeaderGripperTemplateName) as Thumb;
      mRightGripper = GetTemplateChild(RightHeaderGripperTemplateName) as Thumb;
      mDragger = GetTemplateChild(HeaderDragTemplateName) as Thumb;

      if (mLeftGripper != null)
      {
        mLeftGripper.DragStarted += new DragStartedEventHandler(OnPrevColumnHeaderResizeStarted);
        mLeftGripper.DragDelta += new DragDeltaEventHandler(OnColumnHeaderResize);
        mLeftGripper.DragCompleted += new DragCompletedEventHandler(OnColumnHeaderResizeCompleted);
        mLeftGripper.MouseDoubleClick += new MouseButtonEventHandler(OnPrevGripperDoubleClicked);

        if (!Cell.Column.Column.CanUserResize)
        {
          mLeftGripper.Visibility = Visibility.Collapsed;
        }
      }

      if (mRightGripper != null)
      {
        mRightGripper.DragStarted += new DragStartedEventHandler(OnColumnHeaderResizeStarted);
        mRightGripper.DragDelta += new DragDeltaEventHandler(OnColumnHeaderResize);
        mRightGripper.DragCompleted += new DragCompletedEventHandler(OnColumnHeaderResizeCompleted);
        mRightGripper.MouseDoubleClick += new MouseButtonEventHandler(OnGripperDoubleClicked);

        if (!Cell.Column.Column.CanUserResize)
        {
          mRightGripper.Visibility = Visibility.Collapsed;
        }
      }

      if (mDragger != null)
      {
        mDragger.DragStarted += new DragStartedEventHandler(OnColumnDragStarted);
        mDragger.DragDelta += new DragDeltaEventHandler(OnColumnHeaderDrag);
        mDragger.DragCompleted += new DragCompletedEventHandler(OnColumnHeaderDragCompleted);

        mDragger.PreviewMouseLeftButtonDown += OnMouseLeftButtonDown;
        mDragger.PreviewMouseLeftButtonUp += OnMouseLeftButtonUp;

        if (!Cell.Column.Column.CanUserReorder)
        {
          mDragger.Visibility = Visibility.Collapsed;
        }
      }
    }

    /// <summary>
    /// Clear gripper event
    /// </summary>
    private void UnhookGripperEvents()
    {
      if (mLeftGripper != null)
      {
        mLeftGripper.DragStarted -= new DragStartedEventHandler(OnPrevColumnHeaderResizeStarted);
        mLeftGripper.DragDelta -= new DragDeltaEventHandler(OnColumnHeaderResize);
        mLeftGripper.DragCompleted -= new DragCompletedEventHandler(OnColumnHeaderResizeCompleted);
        mLeftGripper.MouseDoubleClick -= new MouseButtonEventHandler(OnPrevGripperDoubleClicked);
        mLeftGripper = null;
      }

      if (mRightGripper != null)
      {
        mRightGripper.DragStarted -= new DragStartedEventHandler(OnColumnHeaderResizeStarted);
        mRightGripper.DragDelta -= new DragDeltaEventHandler(OnColumnHeaderResize);
        mRightGripper.DragCompleted -= new DragCompletedEventHandler(OnColumnHeaderResizeCompleted);
        mRightGripper.MouseDoubleClick -= new MouseButtonEventHandler(OnGripperDoubleClicked);
        mRightGripper = null;
      }

      if (mDragger != null)
      {
        mDragger.DragStarted -= new DragStartedEventHandler(OnColumnDragStarted);
        mDragger.DragDelta -= new DragDeltaEventHandler(OnColumnHeaderDrag);
        mDragger.DragCompleted -= new DragCompletedEventHandler(OnColumnHeaderDragCompleted);

        mDragger.PreviewMouseLeftButtonDown -= OnMouseLeftButtonDown;
        mDragger.PreviewMouseLeftButtonUp -= OnMouseLeftButtonUp;

        mDragger = null;
      }
    }

    private DateTime? mMouseLeftButtonDownTime;

    private void OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      mMouseLeftButtonDownTime = DateTime.Now;
    }

    private void OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      if (mMouseLeftButtonDownTime.HasValue && mMouseLeftButtonDownTime.Value.AddMilliseconds(250) > DateTime.Now && e.ClickCount == 1)
      {
        if (Cell.Column.Column.CanUserSort)
        {
          if (Cell.Column.Column.SortDirection.HasValue)
          {
            if (Cell.Column.Column.SortDirection == ListSortDirection.Ascending)
            {
              Cell.Column.Column.SortDirection = ListSortDirection.Descending;
            }
            else
            {
              Cell.Column.Column.SortDirection = null;
            }
          }
          else
          {
            Cell.Column.Column.SortDirection = ListSortDirection.Ascending;
          }

          Cell.Column.Grid.SortBy(Cell.Column);
        }
      }
      mMouseLeftButtonDownTime = null;
    }

    private ColumnVisualData mResizeColumn;

    private void OnPrevColumnHeaderResizeStarted(object sender, DragStartedEventArgs e)
    {
      if (Cell.Column.Index > 0)
      {
        mResizeColumn = Cell.Column.Grid.OrderedColumnDatas[Cell.Column.Index - 1];
        Cell.Column.Grid.Resizing(mResizeColumn.AbsoluteLeft + mResizeColumn.Width + e.HorizontalOffset, true);
      }
      e.Handled = true;
    }

    private void OnPrevGripperDoubleClicked(object sender, MouseButtonEventArgs e)
    {
      if (Cell.Column.Index > 0)
      {
        var wColumn = Cell.Column.Grid.OrderedColumnDatas[Cell.Column.Index - 1];
        wColumn.AutoSize();
      }
      e.Handled = true;
    }

    private void OnColumnHeaderResizeStarted(object sender, DragStartedEventArgs e)
    {
      mResizeColumn = Cell.Column;
      Cell.Column.Grid.Resizing(mResizeColumn.AbsoluteLeft + mResizeColumn.Width + e.HorizontalOffset, true);
    }

    private void OnColumnHeaderResize(object sender, DragDeltaEventArgs e)
    {
      Cell.Column.Grid.Resizing(mResizeColumn.AbsoluteLeft + mResizeColumn.Width + e.HorizontalChange, true);
      e.Handled = true;
    }

    private void OnColumnHeaderResizeCompleted(object sender, DragCompletedEventArgs e)
    {
      mResizeColumn.Width += e.HorizontalChange;
      Cell.Column.Grid.EndResize();
      Cell.Column.Grid.UpdateHorizontalVisibility();
    }

    private void OnGripperDoubleClicked(object sender, MouseButtonEventArgs e)
    {
      Cell.Column.AutoSize();
      e.Handled = true;
    }

    private double mDragStartLeft;

    private void OnColumnDragStarted(object sender, DragStartedEventArgs e)
    {
      if (Cell.Column.IsFrozen) return;
      if (!Cell.Column.Grid.CanUserReorderColumns) return;

      Canvas.SetZIndex(this, 1);
      mDragStartLeft = Cell.Left;
      e.Handled = true;
    }

    private void OnColumnHeaderDrag(object sender, DragDeltaEventArgs e)
    {
      if (Cell.Column.IsFrozen) return;
      if (!Cell.Column.Grid.CanUserReorderColumns) return;

      var wLeft = Cell.Left + e.HorizontalChange;
      if (wLeft < 0)
      {
        wLeft = 0;
      }
      if (Cell.Column.Index == Cell.Column.Grid.OrderedColumnDatas.Length - 1 && wLeft > mDragStartLeft)
      {
        wLeft = mDragStartLeft;
      }

      var wBefore = Cell.Column.Grid.OrderedColumnDatas.SkipWhile(s => s.IsFrozen || s.Left < 0).FirstOrDefault(t => t.Left >= wLeft);

      if (wBefore != null)
      {
        var wNewIndex = wBefore.Index;
        Cell.Column.Grid.SetColumnIndex(Cell.Column, wNewIndex);
      }

      var wScrollLeft = Cell.Column.Grid.VirtualScrollLeft + e.HorizontalChange;
      if (wScrollLeft < 0)
      {
        wScrollLeft = 0;
      }
      Cell.Column.Grid.VirtualScrollLeft = wScrollLeft;

      Cell.Drag(wLeft, Cell.Top);
      e.Handled = true;
    }

    private void OnColumnHeaderDragCompleted(object sender, DragCompletedEventArgs e)
    {
      if (Cell.Column.IsFrozen) return;
      if (!Cell.Column.Grid.CanUserReorderColumns) return;

      Canvas.SetZIndex(this, 0);
      Cell.DragEnd();

      e.Handled = true;
    }

    public bool IsLeftGripperVisibile
    {
      get { return (bool)GetValue(IsLeftGripperVisibileProperty); }
      set { SetValue(IsLeftGripperVisibileProperty, value); }
    }

    public static readonly DependencyProperty IsLeftGripperVisibileProperty =
        DependencyProperty.Register("IsLeftGripperVisibile", typeof(bool), typeof(VirtualGrid), new PropertyMetadata(true));

    public bool IsRightGripperVisibile
    {
      get { return (bool)GetValue(IsRightGripperVisibileProperty); }
      set { SetValue(IsRightGripperVisibileProperty, value); }
    }

    public static readonly DependencyProperty IsRightGripperVisibileProperty =
        DependencyProperty.Register("IsRightGripperVisibile", typeof(bool), typeof(VirtualGrid), new PropertyMetadata(true));

    #endregion

    public CellVisualData Cell
    {
      get { return (CellVisualData)GetValue(CellProperty); }
      set { SetValue(CellProperty, value); }
    }

    public static readonly DependencyProperty CellProperty =
        DependencyProperty.Register("Cell", typeof(CellVisualData), typeof(VirtualGridColumnHeader), new PropertyMetadata(null));

    private Thumb mLeftGripper, mRightGripper, mDragger;
    private const string LeftHeaderGripperTemplateName = "PART_LeftHeaderGripper";
    private const string RightHeaderGripperTemplateName = "PART_RightHeaderGripper";
    private const string HeaderDragTemplateName = "PART_HeaderDrag";
  }
}
