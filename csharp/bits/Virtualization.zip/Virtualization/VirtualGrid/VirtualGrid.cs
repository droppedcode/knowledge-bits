﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Insight.Presentation.Helpers;

namespace Insight.Presentation.Controls.VirtualGrid
{
  [TemplatePart(Name = PART_BackgroundCanvasName, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_FrozenRowCanvasName, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_RowCanvasName, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_FrozenColumnCanvasName, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_ColumnCanvasName, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_FrozenCellCanvasName, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_FrozenColumnCellCanvasName, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_FrozenRowCellCanvasName, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_CellCanvasName, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_FrozenDetailCanvas, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_DetailCanvas, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_OverlayCanvasName, Type = typeof(Canvas))]
  [TemplatePart(Name = PART_MeasureCanvasName, Type = typeof(Canvas))]
  public class VirtualGrid : UserControl
  {
    static VirtualGrid()
    {
      DefaultStyleKeyProperty.OverrideMetadata(typeof(VirtualGrid),
                                               new FrameworkPropertyMetadata(typeof(VirtualGrid)));
    }

    private const string PART_BackgroundCanvasName = "PART_BackgroundCanvas";
    private const string PART_FrozenRowCanvasName = "PART_FrozenRowCanvas";

    private const string PART_RowCanvasName = "PART_RowCanvas";
    private const string PART_FrozenColumnCanvasName = "PART_FrozenColumnCanvas";
    private const string PART_ColumnCanvasName = "PART_ColumnCanvas";
    private const string PART_FrozenCellCanvasName = "PART_FrozenCellCanvas";

    private const string PART_FrozenColumnCellCanvasName = "PART_FrozenColumnCellCanvas";
    private const string PART_FrozenRowCellCanvasName = "PART_FrozenRowCellCanvas";
    private const string PART_CellCanvasName = "PART_CellCanvas";

    private const string PART_FrozenDetailCanvas = "PART_FrozenDetailCanvas";
    private const string PART_DetailCanvas = "PART_DetailCanvas";

    private const string PART_OverlayCanvasName = "PART_OverlayCanvas";
    private const string PART_MeasureCanvasName = "PART_MeasureCanvas";

    private const string PART_VerticalScrollBar = "PART_VerticalScrollBar";
    private const string PART_HorizontalScrollBar = "PART_HorizontalScrollBar";

    private int mHeaderRowCount = 1; //Only the header
    private int mFrozenRowCount = 1; //The header and any other frozen row

    private int mItemsCount;
    public int VisibleRows { get; private set; }
    public int VisibleColumns { get; private set; }

    private Canvas mBackgroundCanvas;
    private Canvas mFrozenRowCanvas;
    private Canvas mRowCanvas;
    private Canvas mFrozenColumnCanvas;
    private Canvas mColumnCanvas;
    private Canvas mFrozenCellCanvas;
    private Canvas mFrozenColumnCellCanvas;
    private Canvas mFrozenRowCellCanvas;
    private Canvas mCellCanvas;
    private Canvas mOverlayCanvas;
    private Canvas mMeasureCanvas;
    private Canvas mFrozenDetailCanvas;
    private Canvas mDetailCanvas;
    private ScrollBar mVerticalScrollBar;
    private ScrollBar mHorizontalScrollBar;

    private int mSuspendLayout;

    public VirtualGrid()
    {
      RowDatas = new RowVisualData[0];
      mColumns = new ObservableCollection<DataGridColumn>();
      mColumns.CollectionChanged += ColumnsCollectionChanged;
      Loaded += VirtualGrid_Loaded;
      SizeChanged += VirtualGrid_SizeChanged;
      MouseWheel += VirtualGrid_MouseWheel;
      KeyDown += VirtualGrid_KeyDown;
      IsVisibleChanged += VirtualGrid_IsVisibleChanged;

      SelectedCells = new ReadOnlyObservableCollection<CellVisualData>(mSelectedCells);
      SelectedItems = new ReadOnlyObservableCollection<object>(mSelectedItems);
      ContextMenuColumnDatas = new ReadOnlyObservableCollection<Controls.VirtualGrid.ColumnVisualData>(mContextMenuColumnDatas);
    }

    #region Grid

    public bool IsReadOnly
    {
      get { return (bool)GetValue(IsReadOnlyProperty); }
      set { SetValue(IsReadOnlyProperty, value); }
    }

    public static readonly DependencyProperty IsReadOnlyProperty =
        DependencyProperty.Register("IsReadOnly", typeof(bool), typeof(VirtualGrid), new PropertyMetadata(false));


    public DataGridGridLinesVisibility GridLinesVisibility
    {
      get { return (DataGridGridLinesVisibility)GetValue(GridLinesVisibilityProperty); }
      set { SetValue(GridLinesVisibilityProperty, value); }
    }

    // Using a DependencyProperty as the backing store for GridLinesVisibility.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty GridLinesVisibilityProperty =
        DependencyProperty.Register("GridLinesVisibility", typeof(DataGridGridLinesVisibility), typeof(VirtualGrid), new PropertyMetadata(DataGridGridLinesVisibility.All));

    public Brush HorizontalGridLinesBrush
    {
      get { return (Brush)GetValue(HorizontalGridLinesBrushProperty); }
      set { SetValue(HorizontalGridLinesBrushProperty, value); }
    }

    public static readonly DependencyProperty HorizontalGridLinesBrushProperty =
        DependencyProperty.Register("HorizontalGridLinesBrush", typeof(Brush), typeof(VirtualGrid), new PropertyMetadata(null));

    public void RemoveColumn(DataGridColumn column)
    {
      ColumnDatas.RemoveAll(r => r.Column == column);
      UpdateColumnOrder();
    }

    public void RemoveColumn(ColumnVisualData column)
    {
      ColumnDatas.Remove(column);
      UpdateColumnOrder();
    }

    public Brush VerticalGridLinesBrush
    {
      get { return (Brush)GetValue(VerticalGridLinesBrushProperty); }
      set { SetValue(VerticalGridLinesBrushProperty, value); }
    }

    public void OrderColumns(IEnumerable<string> columnIds)
    {
      var wTemp = 0;

      var wColumns = ColumnDatas.ToDictionary(d => d.Id ?? (wTemp++).ToString());
      var wColumnIds = new HashSet<string>(columnIds.Where(w => w != null && wColumns.ContainsKey(w)));
      var wLeft = 0d;

      //We set an arbitary order by the left and after let the grid order it
      foreach (var wColumn in wColumnIds.Select(s => wColumns[s]).Concat(ColumnDatas.Where(w => !wColumnIds.Contains(w.Id))))
      {
        wColumn.Left = wLeft;
        wLeft += wColumn.Width;
      }
      UpdateColumnOrder();
    }

    public void SetColumnIndex(ColumnVisualData column, int index)
    {
      if (index < 0) return;

      if (index >= OrderedColumnDatas.Length)
      {
        index = OrderedColumnDatas.Length - 1;
      }

      if (column.Index != index)
      {
        if (column.Index > index)
        {
          //Move left
          column.Left = OrderedColumnDatas[index].Left;
          for (var i = index; i < column.Index; i++)
          {
            OrderedColumnDatas[i].Left += column.Width;
          }
        }
        else
        {
          //Move right
          column.Left = OrderedColumnDatas[index].Left;
          for (var i = column.Index + 1; i <= index; i++)
          {
            OrderedColumnDatas[i].Left -= column.Width;
          }
        }
        UpdateColumnOrder();
      }
    }

    public static readonly DependencyProperty VerticalGridLinesBrushProperty =
        DependencyProperty.Register("VerticalGridLinesBrush", typeof(Brush), typeof(VirtualGrid), new PropertyMetadata(null));

    #endregion

    #region Selection

    public DataGridSelectionMode SelectionMode
    {
      get { return (DataGridSelectionMode)GetValue(SelectionModeProperty); }
      set { SetValue(SelectionModeProperty, value); }
    }

    // Using a DependencyProperty as the backing store for SelectionMode.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty SelectionModeProperty =
        DependencyProperty.Register("SelectionMode", typeof(DataGridSelectionMode), typeof(VirtualGrid), new PropertyMetadata(DataGridSelectionMode.Single, new PropertyChangedCallback(OnSelectionTypeChanged)));


    public DataGridSelectionUnit SelectionUnit
    {
      get { return (DataGridSelectionUnit)GetValue(SelectionUnitProperty); }
      set { SetValue(SelectionUnitProperty, value); }
    }

    public void SelectCell(CellVisualData cell, Controls.VirtualGrid.SelectionMode mode)
    {
      Select(SelectionSource.Cell, mode, cell);
    }

    public CellVisualData GetCellFromPosition(Point position)
    {
      var wRow = RowDatas.FirstOrDefault(f => f.AbsoluteTop <= position.Y && f.AbsoluteTop + f.Height >= position.Y);

      if (wRow == null) return null;

      var wColumn = ColumnDatas.FirstOrDefault(f => f.AbsoluteLeft <= position.X && f.AbsoluteLeft + f.Width >= position.X);

      if (wColumn == null) return null;

      wRow.EnsureCells();

      return wRow.Cells.First(f => f.Column == wColumn);
    }

    // Using a DependencyProperty as the backing store for SelectionUnit.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty SelectionUnitProperty =
        DependencyProperty.Register("SelectionUnit", typeof(DataGridSelectionUnit), typeof(VirtualGrid), new PropertyMetadata(DataGridSelectionUnit.Cell, new PropertyChangedCallback(OnSelectionTypeChanged)));

    private static void OnSelectionTypeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((VirtualGrid)d).OnSelectionTypeChanged();
    }

    private void OnSelectionTypeChanged()
    {

    }

    #endregion

    #region Row

    /// <summary>
    ///     The default row background brush for use on every other row.
    /// </summary>
    /// <remarks>
    ///     Setting this property to a non-null value will coerce AlternationCount to 2.
    /// </remarks>
    public Brush AlternatingRowBackground
    {
      get { return (Brush)GetValue(AlternatingRowBackgroundProperty); }
      set { SetValue(AlternatingRowBackgroundProperty, value); }
    }

    /// <summary>
    ///     DependencyProperty for AlternatingRowBackground.
    /// </summary>
    public static readonly DependencyProperty AlternatingRowBackgroundProperty =
        DependencyProperty.Register("AlternatingRowBackground", typeof(Brush), typeof(VirtualGrid), new FrameworkPropertyMetadata(null, new PropertyChangedCallback(OnAlternationChanged)));

    private static void OnAlternationChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((VirtualGrid)d).OnAlternationChanged();
    }

    /// <summary>
    ///     The default row background brush for use on every row.
    /// </summary>
    public Brush RowBackground
    {
      get { return (Brush)GetValue(RowBackgroundProperty); }
      set { SetValue(RowBackgroundProperty, value); }
    }

    /// <summary>
    ///     DependencyProperty for RowBackground.
    /// </summary>
    public static readonly DependencyProperty RowBackgroundProperty =
        DependencyProperty.Register("RowBackground", typeof(Brush), typeof(VirtualGrid), new FrameworkPropertyMetadata(null, new PropertyChangedCallback(OnAlternationChanged)));

    internal void Resizing(object p, bool v)
    {
      throw new NotImplementedException();
    }

    public int AlternationCount
    {
      get { return (int)GetValue(AlternationCountProperty); }
      set { SetValue(AlternationCountProperty, value); }
    }

    public static readonly DependencyProperty AlternationCountProperty =
        DependencyProperty.Register("AlternationCount", typeof(int), typeof(VirtualGrid), new PropertyMetadata(0, new PropertyChangedCallback(OnAlternationChanged)));

    public double RowHeight
    {
      get { return (double)GetValue(RowHeightProperty); }
      set { SetValue(RowHeightProperty, value); }
    }

    // Using a DependencyProperty as the backing store for RowHeight.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty RowHeightProperty =
        DependencyProperty.Register("RowHeight", typeof(double), typeof(VirtualGrid), new PropertyMetadata(double.NaN, OnRowHeightChanged));

    private static void OnRowHeightChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
    {
      ((VirtualGrid)sender).OnRowHeightChanged(e);
    }

    public Style RowStyle
    {
      get { return (Style)GetValue(RowStyleProperty); }
      set { SetValue(RowStyleProperty, value); }
    }

    public static readonly DependencyProperty RowStyleProperty =
        DependencyProperty.Register("RowStyle", typeof(Style), typeof(VirtualGrid), new PropertyMetadata(null));

    public StyleSelector RowStyleSelector
    {
      get { return (StyleSelector)GetValue(RowStyleSelectorProperty); }
      set { SetValue(RowStyleSelectorProperty, value); }
    }

    public static readonly DependencyProperty RowStyleSelectorProperty =
        DependencyProperty.Register("RowStyleSelector", typeof(StyleSelector), typeof(VirtualGrid), new PropertyMetadata(null));

    #endregion

    #region RowHeader

    public Style RowHeaderStyle
    {
      get { return (Style)GetValue(RowHeaderStyleProperty); }
      set { SetValue(RowHeaderStyleProperty, value); }
    }

    public static readonly DependencyProperty RowHeaderStyleProperty =
        DependencyProperty.Register("RowHeaderStyle", typeof(Style), typeof(VirtualGrid), new PropertyMetadata(null));

    public DataTemplate RowHeaderTemplate
    {
      get { return (DataTemplate)GetValue(RowHeaderTemplateProperty); }
      set { SetValue(RowHeaderTemplateProperty, value); }
    }

    public static readonly DependencyProperty RowHeaderTemplateProperty =
        DependencyProperty.Register("RowHeaderTemplate", typeof(DataTemplate), typeof(VirtualGrid), new PropertyMetadata(null));

    public DataTemplateSelector RowHeaderTemplateSelector
    {
      get { return (DataTemplateSelector)GetValue(RowHeaderTemplateSelectorProperty); }
      set { SetValue(RowHeaderTemplateSelectorProperty, value); }
    }

    public static readonly DependencyProperty RowHeaderTemplateSelectorProperty =
        DependencyProperty.Register("RowHeaderTemplateSelector", typeof(DataTemplateSelector), typeof(VirtualGrid), new PropertyMetadata(null));

    public double RowHeaderWidth
    {
      get { return (double)GetValue(RowHeaderWidthProperty); }
      set { SetValue(RowHeaderWidthProperty, value); }
    }

    public static readonly DependencyProperty RowHeaderWidthProperty =
        DependencyProperty.Register("RowHeaderWidth", typeof(double), typeof(VirtualGrid), new PropertyMetadata(double.NaN));

    #endregion

    #region Column

    /// <summary>
    ///     A property that specifies whether the user can reorder columns in the UI by dragging the column headers.
    /// </summary>
    public bool CanUserReorderColumns
    {
      get { return (bool)GetValue(CanUserReorderColumnsProperty); }
      set { SetValue(CanUserReorderColumnsProperty, value); }
    }

    /// <summary>
    ///     The DependencyProperty that represents the CanUserReorderColumns property.
    /// </summary>
    public static readonly DependencyProperty CanUserReorderColumnsProperty =
        DependencyProperty.Register("CanUserReorderColumns", typeof(bool), typeof(VirtualGrid), new FrameworkPropertyMetadata(true, new PropertyChangedCallback(OnMeasureInvalid)));

    /// <summary>
    ///     A property that specifies whether the user can resize columns in the UI by dragging the column headers.
    /// </summary>
    /// <remarks>
    ///     This does not affect whether column widths can be changed programmatically via a property such as Column.Width.
    /// </remarks>
    public bool CanUserResizeColumns
    {
      get { return (bool)GetValue(CanUserResizeColumnsProperty); }
      set { SetValue(CanUserResizeColumnsProperty, value); }
    }

    /// <summary>
    ///     The DependencyProperty that represents the CanUserResizeColumns property.
    /// </summary>
    public static readonly DependencyProperty CanUserResizeColumnsProperty =
        DependencyProperty.Register("CanUserResizeColumns", typeof(bool), typeof(VirtualGrid), new FrameworkPropertyMetadata(true, new PropertyChangedCallback(OnMeasureInvalid)));

    private static void OnMeasureInvalid(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((VirtualGrid)d).OnMeasureInvalid();
    }

    /// <summary>
    ///     Specifies the width of the header and cells within all the columns.
    /// </summary>
    public DataGridLength ColumnWidth
    {
      get { return (DataGridLength)GetValue(ColumnWidthProperty); }
      set { SetValue(ColumnWidthProperty, value); }
    }

    /// <summary>
    ///     The DependencyProperty that represents the ColumnWidth property.
    /// </summary>
    public static readonly DependencyProperty ColumnWidthProperty =
        DependencyProperty.Register("ColumnWidth", typeof(DataGridLength), typeof(VirtualGrid), new FrameworkPropertyMetadata(DataGridLength.SizeToHeader, new PropertyChangedCallback(OnMeasureInvalid)));

    /// <summary>
    ///     Specifies the minimum width of the header and cells within all columns.
    /// </summary>
    public double MinColumnWidth
    {
      get { return (double)GetValue(MinColumnWidthProperty); }
      set { SetValue(MinColumnWidthProperty, value); }
    }

    /// <summary>
    ///     The DependencyProperty that represents the MinColumnWidth property.
    /// </summary>
    public static readonly DependencyProperty MinColumnWidthProperty =
        DependencyProperty.Register(
            "MinColumnWidth",
            typeof(double),
            typeof(VirtualGrid),
            new FrameworkPropertyMetadata(20d, new PropertyChangedCallback(OnMeasureInvalid)),
            new ValidateValueCallback(ValidateMinColumnWidth));

    /// <summary>
    ///     Specifies the maximum width of the header and cells within all columns.
    /// </summary>
    public double MaxColumnWidth
    {
      get { return (double)GetValue(MaxColumnWidthProperty); }
      set { SetValue(MaxColumnWidthProperty, value); }
    }

    /// <summary>
    ///     The DependencyProperty that represents the  MaxColumnWidth property.
    /// </summary>
    public static readonly DependencyProperty MaxColumnWidthProperty =
        DependencyProperty.Register(
            "MaxColumnWidth",
            typeof(double),
            typeof(VirtualGrid),
            new FrameworkPropertyMetadata(double.PositiveInfinity, new PropertyChangedCallback(OnMeasureInvalid)),
            new ValidateValueCallback(ValidateMaxColumnWidth));

    /// <summary>
    /// Validates that the minimum column width is an acceptable value
    /// </summary>
    private static bool ValidateMinColumnWidth(object v)
    {
      double value = (double)v;
      return !(value < 0d || double.IsNaN(value) || Double.IsPositiveInfinity(value));
    }

    /// <summary>
    /// Validates that the maximum column width is an acceptable value
    /// </summary>
    private static bool ValidateMaxColumnWidth(object v)
    {
      double value = (double)v;
      return !(value < 0d || double.IsNaN(value));
    }

    #endregion

    #region ColumnHeader

    public Style ColumnHeaderStyle
    {
      get { return (Style)GetValue(ColumnHeaderStyleProperty); }
      set { SetValue(ColumnHeaderStyleProperty, value); }
    }

    public static readonly DependencyProperty ColumnHeaderStyleProperty =
        DependencyProperty.Register("ColumnHeaderStyle", typeof(Style), typeof(VirtualGrid), new PropertyMetadata(null));

    public DataTemplate ColumnHeaderTemplate
    {
      get { return (DataTemplate)GetValue(ColumnHeaderTemplateProperty); }
      set { SetValue(ColumnHeaderTemplateProperty, value); }
    }

    public static readonly DependencyProperty ColumnHeaderTemplateProperty =
        DependencyProperty.Register("ColumnHeaderTemplate", typeof(DataTemplate), typeof(VirtualGrid), new PropertyMetadata(null));

    public DataTemplateSelector ColumnHeaderTemplateSelector
    {
      get { return (DataTemplateSelector)GetValue(ColumnHeaderTemplateSelectorProperty); }
      set { SetValue(ColumnHeaderTemplateSelectorProperty, value); }
    }

    public static readonly DependencyProperty ColumnHeaderTemplateSelectorProperty =
        DependencyProperty.Register("ColumnHeaderTemplateSelector", typeof(DataTemplateSelector), typeof(VirtualGrid), new PropertyMetadata(null));

    public double ColumnHeaderHeight
    {
      get { return (double)GetValue(ColumnHeaderHeightProperty); }
      set { SetValue(ColumnHeaderHeightProperty, value); }
    }

    public static readonly DependencyProperty ColumnHeaderHeightProperty =
        DependencyProperty.Register("ColumnHeaderHeight", typeof(double), typeof(VirtualGrid), new PropertyMetadata(double.NaN));

    #endregion

    #region Cell

    public Style CellStyle
    {
      get { return (Style)GetValue(CellStyleProperty); }
      set { SetValue(CellStyleProperty, value); }
    }

    public static readonly DependencyProperty CellStyleProperty =
        DependencyProperty.Register("CellStyle", typeof(Style), typeof(VirtualGrid), new PropertyMetadata(null));

    public VirtualGridEditTriggers EditTriggers
    {
      get { return (VirtualGridEditTriggers)GetValue(EditTriggersProperty); }
      set { SetValue(EditTriggersProperty, value); }
    }

    public static readonly DependencyProperty EditTriggersProperty =
        DependencyProperty.Register("EditTriggers", typeof(VirtualGridEditTriggers), typeof(VirtualGrid), new PropertyMetadata(VirtualGridEditTriggers.Default));

    #endregion

    #region Event handlers

    private void VirtualGrid_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      UpdateVisibility();
    }

    private void VirtualGrid_Loaded(object sender, RoutedEventArgs e)
    {
      UpdateColumns();
      UpdateVisibility();
    }

    private void VirtualGrid_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
      UpdateVisibility();
    }

    #endregion

    #region ContextMenu

    private ObservableCollection<ColumnVisualData> mContextMenuColumnDatas = new ObservableCollection<ColumnVisualData>();

    public ReadOnlyObservableCollection<ColumnVisualData> ContextMenuColumnDatas
    {
      get { return (ReadOnlyObservableCollection<ColumnVisualData>)GetValue(ContextMenuColumnDatasProperty); }
      private set { SetValue(ContextMenuColumnDatasPropertyKey, value); }
    }
    private static DependencyPropertyKey ContextMenuColumnDatasPropertyKey =
        DependencyProperty.RegisterReadOnly("ContextMenuColumnDatas", typeof(ReadOnlyObservableCollection<ColumnVisualData>), typeof(VirtualGrid), new PropertyMetadata(null));
    public static DependencyProperty ContextMenuColumnDatasProperty = ContextMenuColumnDatasPropertyKey.DependencyProperty;

    public string ContextMenuColumnFilter
    {
      get { return (string)GetValue(ContextMenuColumnFilterProperty); }
      set { SetValue(ContextMenuColumnFilterProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ContextMenuColumnFilter.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ContextMenuColumnFilterProperty =
        DependencyProperty.Register("ContextMenuColumnFilter", typeof(string), typeof(VirtualGrid), new PropertyMetadata(null, new PropertyChangedCallback(OnContextMenuColumnFilter)));

    private static void OnContextMenuColumnFilter(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((VirtualGrid)d).OnContextMenuColumnFilter();
    }

    private void OnContextMenuColumnFilter()
    {
      UpdateContextMenuColumns();
    }

    private void UpdateContextMenuColumns()
    {
      mContextMenuColumnDatas.Clear();

      if (string.IsNullOrEmpty(ContextMenuColumnFilter))
      {
        foreach (var wData in OrderedColumnDatas)
        {
          var wHeader = wData.Column.Header as string;
          if (!string.IsNullOrEmpty(wHeader))
          {
            mContextMenuColumnDatas.Add(wData);
          }
        }
      }
      else
      {
        foreach (var wData in OrderedColumnDatas)
        {
          var wHeader = wData.Column.Header as string;
          if (!string.IsNullOrEmpty(wHeader) &&
            wHeader.IndexOf(ContextMenuColumnFilter, StringComparison.OrdinalIgnoreCase) >= 0)
          {
            mContextMenuColumnDatas.Add(wData);
          }
        }
      }
    }

    #endregion

    #region RowDetails

    public DataTemplate RowDetailsTemplate
    {
      get { return (DataTemplate)GetValue(RowDetailsTemplateProperty); }
      set { SetValue(RowDetailsTemplateProperty, value); }
    }

    // Using a DependencyProperty as the backing store for RowDetailsTemplate.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty RowDetailsTemplateProperty =
        DependencyProperty.Register("RowDetailsTemplate", typeof(DataTemplate), typeof(VirtualGrid), new PropertyMetadata(null));


    public RowDetailsWidth RowDetailsWidth
    {
      get { return (RowDetailsWidth)GetValue(RowDetailsWidthProperty); }
      set { SetValue(RowDetailsWidthProperty, value); }
    }

    // Using a DependencyProperty as the backing store for RowDetailsWidth.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty RowDetailsWidthProperty =
        DependencyProperty.RegisterAttached("RowDetailsWidth", typeof(RowDetailsWidth), typeof(VirtualGrid), new PropertyMetadata(RowDetailsWidth.TotalWidth));

    #endregion

    #region Sorting

    public event System.Windows.Controls.DataGridSortingEventHandler Sorting;

    public ColumnVisualData SortedBy { get; private set; }
    private bool mIsSortedByEvent;

    public void SortBy(ColumnVisualData column)
    {
      if (SortedBy != null && column != SortedBy)
      {
        SortedBy.Column.SortDirection = null;
      }

      SortedBy = column;

      if (column != null)
      {
        var wHandler = Sorting;
        if (wHandler != null)
        {
          var wEventArgs = new DataGridSortingEventArgs(column.Column);
          wHandler(this, wEventArgs);
          mIsSortedByEvent = wEventArgs.Handled;
        }
        else
        {
          mIsSortedByEvent = false;
        }
      }

      UpdateItemsSource();
    }

    private object GetDeepPropertyValue(object instance, string path)
    {
      var wPathParts = path.Split('.');
      Type wType = instance.GetType();
      foreach (var wPropertyName in wPathParts)
      {
        PropertyInfo wPropertyInfo = wType.GetProperty(wPropertyName);
        if (wPropertyInfo != null)
        {
          instance = wPropertyInfo.GetValue(instance, null);
          wType = wPropertyInfo.PropertyType;
        }
        else
        {
          throw new ArgumentException("Properties path is not correct");
        }
      }
      return instance;
    }

    #endregion

    private bool mIsTemplateApplied;

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      mBackgroundCanvas = GetTemplateChild(PART_BackgroundCanvasName) as Canvas;
      mFrozenRowCanvas = GetTemplateChild(PART_FrozenRowCanvasName) as Canvas;
      mRowCanvas = GetTemplateChild(PART_RowCanvasName) as Canvas;
      mFrozenColumnCanvas = GetTemplateChild(PART_FrozenColumnCanvasName) as Canvas;
      mColumnCanvas = GetTemplateChild(PART_ColumnCanvasName) as Canvas;
      mFrozenCellCanvas = GetTemplateChild(PART_FrozenCellCanvasName) as Canvas;
      mFrozenColumnCellCanvas = GetTemplateChild(PART_FrozenColumnCellCanvasName) as Canvas;
      mFrozenRowCellCanvas = GetTemplateChild(PART_FrozenRowCellCanvasName) as Canvas;
      mCellCanvas = GetTemplateChild(PART_CellCanvasName) as Canvas;
      mOverlayCanvas = GetTemplateChild(PART_OverlayCanvasName) as Canvas;
      mMeasureCanvas = GetTemplateChild(PART_MeasureCanvasName) as Canvas;
      mFrozenDetailCanvas = GetTemplateChild(PART_FrozenDetailCanvas) as Canvas;
      mDetailCanvas = GetTemplateChild(PART_DetailCanvas) as Canvas;
      mVerticalScrollBar = GetTemplateChild(PART_VerticalScrollBar) as ScrollBar;
      mHorizontalScrollBar = GetTemplateChild(PART_HorizontalScrollBar) as ScrollBar;
      mIsTemplateApplied = true;

      UpdateColumns();
      UpdateVisibility();
    }

    private void OnMeasureInvalid()
    {

    }

    private void OnAlternationChanged()
    {
      if (AlternatingRowBackground != null && AlternationCount < 2)
      {
        AlternationCount = 2;
        return;
      }

      UpdateRowBackground();
    }

    private void UpdateRowBackground()
    {
      if (RowDatas == null) return;

      var wAlternationCount = AlternationCount - 1;
      var wAlternate = wAlternationCount;
      var wIsAlternate = true;
      foreach (var wRow in RowDatas.Where(w => w != null && !(w is HeaderRowVisualData)))
      {
        wRow.Background = wIsAlternate ? AlternatingRowBackground : RowBackground;
        wAlternate--;
        if (wAlternate == 0)
        {
          wIsAlternate = !wIsAlternate;
          wAlternate = wAlternationCount;
        }
      }
    }

    private void OnRowHeightChanged(DependencyPropertyChangedEventArgs e)
    {
      foreach (var wRow in RowDatas)
      {
        wRow.Height = (double)e.NewValue;
      }
    }

    public double VirtualHeight
    {
      get { return (double)GetValue(VirtualHeightProperty); }
      set { SetValue(VirtualHeightProperty, value); }
    }

    public static readonly DependencyProperty VirtualHeightProperty =
        DependencyProperty.Register("VirtualHeight", typeof(double), typeof(VirtualGrid), new PropertyMetadata(0d));

    public double VirtualWidth
    {
      get { return (double)GetValue(VirtualWidthProperty); }
      set { SetValue(VirtualWidthProperty, value); }
    }

    public static readonly DependencyProperty VirtualWidthProperty =
        DependencyProperty.Register("VirtualWidth", typeof(double), typeof(VirtualGrid), new PropertyMetadata(0d));

    public double FrozenHeight
    {
      get { return (double)GetValue(FrozenHeightProperty); }
      set { SetValue(FrozenHeightProperty, value); }
    }

    public static readonly DependencyProperty FrozenHeightProperty =
        DependencyProperty.Register("FrozenHeight", typeof(double), typeof(VirtualGrid), new PropertyMetadata(0d));

    public double FrozenWidth
    {
      get { return (double)GetValue(FrozenWidthProperty); }
      set { SetValue(FrozenWidthProperty, value); }
    }

    public static readonly DependencyProperty FrozenWidthProperty =
        DependencyProperty.Register("FrozenWidth", typeof(double), typeof(VirtualGrid), new PropertyMetadata(0d));

    public double TotalHeight
    {
      get { return (double)GetValue(TotalHeightProperty); }
      set { SetValue(TotalHeightProperty, value); }
    }

    public static readonly DependencyProperty TotalHeightProperty =
        DependencyProperty.Register("TotalHeight", typeof(double), typeof(VirtualGrid), new PropertyMetadata(0d));

    public double TotalWidth
    {
      get { return (double)GetValue(TotalWidthProperty); }
      set { SetValue(TotalWidthProperty, value); }
    }

    public static readonly DependencyProperty TotalWidthProperty =
        DependencyProperty.Register("TotalWidth", typeof(double), typeof(VirtualGrid), new PropertyMetadata(0d));

    public double VirtualScrollLeft
    {
      get { return (double)GetValue(VirtualScrollLeftProperty); }
      set { SetValue(VirtualScrollLeftProperty, value); }
    }

    public static readonly DependencyProperty VirtualScrollLeftProperty =
        DependencyProperty.Register("VirtualScrollLeft", typeof(double), typeof(VirtualGrid), new PropertyMetadata(0d, OnLeftChanged, OnCoerceLeftChanged));

    private static object OnCoerceLeftChanged(DependencyObject d, object baseValue)
    {
      return ((VirtualGrid)d).OnCoerceLeftChanged((double)baseValue);
    }

    private object OnCoerceLeftChanged(double value)
    {
      if (value < 0) return 0d;
      if (value > VirtualWidth) return VirtualWidth;
      return value;
    }

    private static void OnLeftChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
    {
      ((VirtualGrid)sender).OnLeftChanged(e);
    }

    private void OnLeftChanged(DependencyPropertyChangedEventArgs e)
    {
      UpdateHorizontalVisibility(true);
    }

    public double VirtualScrollTop
    {
      get { return (double)GetValue(VirtualScrollTopProperty); }
      set { SetValue(VirtualScrollTopProperty, value); }
    }

    // Using a DependencyProperty as the backing store for VirtualScrollTop.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty VirtualScrollTopProperty =
        DependencyProperty.Register("VirtualScrollTop", typeof(double), typeof(VirtualGrid), new PropertyMetadata(0d, OnTopChanged, OnCoerceTopChange));

    private static object OnCoerceTopChange(DependencyObject d, object baseValue)
    {
      return ((VirtualGrid)d).OnCoerceTopChange((double)baseValue);
    }

    private object OnCoerceTopChange(double value)
    {
      if (value < 0) return 0d;
      if (value > VirtualHeight) return VirtualHeight;
      return value;
    }

    private static void OnTopChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
    {
      ((VirtualGrid)sender).OnTopChanged(e);
    }

    private void OnTopChanged(DependencyPropertyChangedEventArgs e)
    {
      UpdateVerticalVisibility(true);
    }

    private ObservableCollection<DataGridColumn> mColumns;

    public ObservableCollection<DataGridColumn> Columns
    {
      get { return mColumns; }
    }

    public event EventHandler ColumnsUpdated;

    private void UpdateColumns()
    {
      if (!IsLoaded || !mIsTemplateApplied) return;

      try
      {
        SuspendLayout();

        if (ColumnDatas == null)
        {
          ColumnDatas = new List<ColumnVisualData>();
        }

        foreach (var wRow in RowDatas)
        {
          wRow.RemoveCellsFromGrid();
        }
        RowDatas = new RowVisualData[]
        {
          new HeaderRowVisualData(this)
        };

        ColumnDatas.Clear();
        mLastSelectedCell = null;
        mSelectedCells.Clear();

        var wColumns = Columns;
        if (wColumns != null)
        {
          foreach (var wColumn in wColumns)
          {
            var wData = new ColumnVisualData(VirtualGrid.GetColumnId(wColumn), this, wColumn);
            wData.IsFrozen = GetIsFrozen(wColumn);
            wData.PropertyChanged += ColumnData_PropertyChanged;
            ColumnDatas.Add(wData);
          }
        }

        UpdateColumnOrder();

        UpdateItemsSource();
      }
      finally
      {
        ResumeLayout();
      }

      var wHandler = ColumnsUpdated;
      if (wHandler != null) wHandler(this, new EventArgs());
    }

    internal void UpdateColumnOrder()
    {
      try
      {
        SuspendLayout();

        if (OrderedColumnDatas != null && OrderedColumnDatas.Length > 0)
        {
          OrderedColumnDatas[0].IsLeftGripperVisibile = true;
          OrderedColumnDatas[OrderedColumnDatas.Length - 1].IsRightGripperVisibile = true;
        }

        OrderedColumnDatas = ColumnDatas.OrderBy(o => o.IsFrozen ? 0 : 1).ThenBy(o => o.Left).ToArray();
        UpdateContextMenuColumns();

        var wIndex = 0;
        foreach (var wColumn in OrderedColumnDatas)
        {
          wColumn.Index = wIndex++;
        }

        if (OrderedColumnDatas.Length > 0)
        {
          OrderedColumnDatas[0].IsLeftGripperVisibile = false;
          OrderedColumnDatas[OrderedColumnDatas.Length - 1].IsRightGripperVisibile = false;
        }
      }
      finally
      {
        ResumeLayout();
      }
    }

    private void ColumnData_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
      if (e.PropertyName == "Order")
      {
        UpdateColumnOrder();
        UpdateHorizontalVisibility(true);
      }
    }

    private void ColumnsCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
      UpdateColumns();
    }

    public IEnumerable ItemsSource
    {
      get { return (IEnumerable)GetValue(ItemsSourceProperty); }
      set { SetValue(ItemsSourceProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ItemsSource.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(VirtualGrid), new PropertyMetadata(null, OnItemsSourceChanged));

    private static void OnItemsSourceChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
    {
      ((VirtualGrid)sender).OnItemsSourceChanged(e);
    }

    private void OnItemsSourceChanged(DependencyPropertyChangedEventArgs e)
    {
      var wOld = e.OldValue as INotifyCollectionChanged;
      if (wOld != null)
      {
        wOld.CollectionChanged -= ItemsSourceCollectionChanged;
      }

      var wNew = e.NewValue as INotifyCollectionChanged;
      if (wNew != null)
      {
        wNew.CollectionChanged += ItemsSourceCollectionChanged;
      }

      UpdateItemsSource();
    }

    public static object GetSortBy(DependencyObject obj)
    {
      return (object)obj.GetValue(SortByProperty);
    }

    public static void SetSortBy(DependencyObject obj, object value)
    {
      obj.SetValue(SortByProperty, value);
    }

    public static readonly DependencyProperty SortByProperty =
        DependencyProperty.RegisterAttached("SortBy", typeof(object), typeof(VirtualGrid), new PropertyMetadata(null));

    public static bool GetIsFrozen(DependencyObject obj)
    {
      return (bool)obj.GetValue(IsFrozenProperty);
    }

    public static void SetIsFrozen(DependencyObject obj, bool value)
    {
      obj.SetValue(IsFrozenProperty, value);
    }

    public static readonly DependencyProperty IsFrozenProperty =
        DependencyProperty.RegisterAttached("IsFrozen", typeof(bool), typeof(VirtualGrid), new PropertyMetadata(false));

    public static string GetColumnId(DependencyObject obj)
    {
      return (string)obj.GetValue(ColumnIdProperty);
    }

    public static void SetColumnId(DependencyObject obj, string value)
    {
      obj.SetValue(ColumnIdProperty, value);
    }

    public static readonly DependencyProperty ColumnIdProperty =
        DependencyProperty.RegisterAttached("ColumnId", typeof(string), typeof(VirtualGrid), new PropertyMetadata(null));

    public static bool GetIsVisibilityEditableInContextMenu(DependencyObject obj)
    {
      return (bool)obj.GetValue(IsVisibilityEditableInContextMenuProperty);
    }

    public static void SetIsVisibilityEditableInContextMenu(DependencyObject obj, bool value)
    {
      obj.SetValue(IsVisibilityEditableInContextMenuProperty, value);
    }

    public static readonly DependencyProperty IsVisibilityEditableInContextMenuProperty =
        DependencyProperty.RegisterAttached("IsVisibilityEditableInContextMenu", typeof(bool), typeof(VirtualGrid), new PropertyMetadata(true));

    internal List<ColumnVisualData> ColumnDatas { get; private set; }

    public ColumnVisualData[] OrderedColumnDatas { get; private set; }

    internal RowVisualData[] RowDatas { get; private set; }

    private void ItemsSourceCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
      switch (e.Action)
      {
        case NotifyCollectionChangedAction.Add:
        case NotifyCollectionChangedAction.Remove:
        case NotifyCollectionChangedAction.Replace:
          UpdateItemsSourceDispatched();
          break;
        case NotifyCollectionChangedAction.Reset:
          UpdateItemsSource();
          break;
      }
    }

    private bool mUpdateItemsSourceCalled;

    private void UpdateItemsSourceDispatched()
    {
      if (mUpdateItemsSourceCalled) return;
      mUpdateItemsSourceCalled = true;
      Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() => UpdateItemsSource()));
    }

    private void UpdateItemsSource()
    {
      if (!IsLoaded) return;

      mUpdateItemsSourceCalled = false;

      try
      {
        SuspendLayout();

        if (ColumnDatas == null)
        {
          UpdateColumns();
        }

        var wOldRowDatas = RowDatas;
        var wOldRowDatasDict = RowDatas.Where(w => w != null && w.Data != null).ToDictionary(d => d.Data, d => d);

        mItemsCount = ItemsSource != null ? ItemsSource.Cast<object>().Count() : 0;

        RowDatas = new RowVisualData[mHeaderRowCount + mItemsCount];

        if (wOldRowDatas.Length > 0)
        {
          for (var i = 0; i < mHeaderRowCount; i++)
          {
            RowDatas[i] = wOldRowDatas[i] ?? new HeaderRowVisualData(this);
          }
        }

        if (ItemsSource != null)
        {
          var wSource = ItemsSource.OfType<object>();

          if ((Sorting == null || !mIsSortedByEvent) && SortedBy != null && SortedBy.Column.SortDirection.HasValue && !string.IsNullOrEmpty(SortedBy.Column.SortMemberPath))
          {
            if (SortedBy.Column.SortDirection == System.ComponentModel.ListSortDirection.Ascending)
            {
              wSource = wSource.OrderBy(o => GetDeepPropertyValue(o, SortedBy.Column.SortMemberPath));
            }
            else
            {
              wSource = wSource.OrderByDescending(o => GetDeepPropertyValue(o, SortedBy.Column.SortMemberPath));
            }
          }

          var wIndex = mHeaderRowCount;
          foreach (var wItem in wSource)
          {
            RowVisualData wData;
            RowDatas[wIndex] = wOldRowDatasDict.TryGetValue(wItem, out wData) ? wData : new RowVisualData(this) { Data = wItem };
            wOldRowDatasDict.Remove(wItem);
            if (wData != null)
            {
              wData.FreeElements();
            }
            wIndex++;
          }
        }

        foreach (var wItem in wOldRowDatasDict)
        {
          wItem.Value.RemoveCellsFromGrid();
        }

        //Quick fix to remove all elements
        //mBackgroundCanvas.Children.Clear();
        //mFrozenRowCanvas.Children.Clear();
        //mRowCanvas.Children.Clear();
        //mFrozenColumnCanvas.Children.Clear();
        //mColumnCanvas.Children.Clear();
        //mFrozenCellCanvas.Children.Clear();
        //mFrozenColumnCellCanvas.Children.Clear();
        //mFrozenRowCellCanvas.Children.Clear();
        //mCellCanvas.Children.Clear();
        //mOverlayCanvas.Children.Clear();
        //mMeasureCanvas.Children.Clear();
        //mFrozenDetailCanvas.Children.Clear();
        //mDetailCanvas.Children.Clear();


        InvalidateMeasure();

        UpdateRowBackground();

        UpdateAvarageVirtualHeight();

        //Update height
        UpdateVisibility();
      }
      finally
      {
        ResumeLayout();
      }
    }

    public void UpdateVisibility()
    {
      if (IsLayoutSuspended) return;
      if (ColumnDatas == null) return;
      if (!IsLoaded) return;
      if (!mIsTemplateApplied) return;

      UpdateHorizontalVisibility(false);
      UpdateVerticalVisibility(false);
      RunElementActions();
    }

    private void UpdatePosition()
    {
      if (IsLayoutSuspended) return;

      UpdateHorizontalPosition();
      UpdateVerticalPosition();
    }

    internal void UpdateHorizontalPosition()
    {
      if (IsLayoutSuspended) return;
      if (!IsLoaded) return;

      var wFrozen = 0d;
      var wValue = -VirtualScrollLeft;

      foreach (var wItem in OrderedColumnDatas)
      {
        if (wItem.IsFrozen)
        {
          wItem.Left = wFrozen;
          if (!wItem.IsHidden)
          {
            wFrozen += wItem.Width;
          }
        }
        else
        {
          wItem.Left = wValue;
          if (!wItem.IsHidden)
          {
            wValue += wItem.Width;
          }
        }
      }

      foreach (var wItem in OrderedColumnDatas)
      {
        if (wItem.IsFrozen)
        {
          wItem.AbsoluteLeft = wItem.Left;
        }
        else
        {
          wItem.AbsoluteLeft = wFrozen + wItem.Left;
        }
      }

      var wDetailWidth = 0d;
      if (RowDatas != null)
      {
        foreach (var wRow in RowDatas)
        {
          if (!double.IsNaN(wRow.DetailWidth))
          {
            if (wDetailWidth < wRow.DetailWidth)
            {
              wDetailWidth = wRow.DetailWidth;
            }
          }
        }
      }

      VirtualWidth = Math.Max(wDetailWidth - mCellCanvas.ActualWidth, Math.Max(0, wValue - mCellCanvas.ActualWidth + VirtualScrollLeft));
      var wTotalWidth = Math.Max(wDetailWidth, wFrozen + wValue + VirtualScrollLeft);
      if (wTotalWidth != TotalWidth)
      {
        TotalWidth = wTotalWidth;
        InvalidateMeasure();
      }
      FrozenWidth = wFrozen;
      if (VirtualWidth < VirtualScrollLeft)
      {
        VirtualScrollLeft = VirtualWidth;
      }
    }

    private void UpdateVerticalPosition()
    {
      if (!IsLoaded) return;
      if (IsLayoutSuspended) return;
      if (RowDatas == null) return;

      var wFrozen = 0d;
      var wValue = -VirtualScrollTop;

      foreach (var wItem in RowDatas)
      {
        if (wItem.IsFrozen)
        {
          wItem.Top = wFrozen;
          wFrozen += wItem.CalculatedHeight;
        }
        else
        {
          wItem.Top = wValue;
          wValue += wItem.CalculatedHeight;
        }
      }

      foreach (var wItem in RowDatas)
      {
        if (wItem.IsFrozen)
        {
          wItem.AbsoluteTop = wItem.Top;
        }
        else
        {
          wItem.AbsoluteTop = wFrozen + wItem.Top;
        }
      }

      VirtualHeight = Math.Max(0, wValue - mCellCanvas.ActualHeight + VirtualScrollTop);

      var wTotalHeight = wFrozen + wValue + VirtualScrollTop;
      if (wTotalHeight != TotalHeight)
      {
        TotalHeight = wTotalHeight;
        InvalidateMeasure();
      }
      FrozenHeight = wFrozen;

      if (VirtualHeight < VirtualScrollTop)
      {
        VirtualScrollTop = VirtualHeight;
      }

      InvalidateMeasure();
    }

    protected override Size MeasureOverride(Size constraint)
    {
      var wWidth = TotalWidth;
      var wHeight = TotalHeight;

      if (constraint.Height < wHeight || (constraint.Width < wWidth && constraint.Height < wHeight + mHorizontalScrollBar.Height))
      {
        wHeight = constraint.Height;
        mVerticalScrollBar.Visibility = Visibility.Visible;
      }
      else
      {
        mVerticalScrollBar.Visibility = Visibility.Collapsed;
      }

      if (constraint.Width < wWidth || (mVerticalScrollBar.Visibility == Visibility.Visible && constraint.Width < wWidth + mVerticalScrollBar.Width))
      {
        wWidth = constraint.Width;
        mHorizontalScrollBar.Visibility = Visibility.Visible;
      }
      else
      {
        mHorizontalScrollBar.Visibility = Visibility.Collapsed;
      }

      if (ColumnDatas != null)
      {
        var wStarWidthColumns = ColumnDatas.Where(w => !w.IsMeasured && w.Column.Width.IsStar).ToList();
        var wHasWidthColumns = ColumnDatas.Where(w => w.IsMeasured || !w.Column.Width.IsStar).ToList();
        if (wStarWidthColumns.Count > 0)
        {
          var wSum = wStarWidthColumns.Sum(s => s.Column.Width.Value);
          var wAvailable = constraint.Width;
          if (mVerticalScrollBar.Visibility == Visibility.Visible)
          {
            wAvailable -= mVerticalScrollBar.Width;
          }
          if (wHasWidthColumns.Count > 0)
          {
            wAvailable -= wHasWidthColumns.Sum(s => s.Width);
          }
          var wPerStar = wAvailable / wSum;

          foreach (var wColumn in wStarWidthColumns)
          {
            wColumn.Width = wPerStar * wColumn.Column.Width.Value;
          }
        }
      }

      return new Size(wWidth, wHeight);
    }

    public void UpdateHorizontalVisibility()
    {
      UpdateHorizontalVisibility(true);
    }

    private bool mShouldRunUpdateHorizontalVisibility;

    private void UpdateHorizontalVisibility(bool runActions)
    {
      if (IsLayoutSuspended) return;
      if (!IsLoaded) return;

      if (mIsRunningElementActions)
      {
        mShouldRunUpdateHorizontalVisibility = true;
        return;
      }

      VisibleColumns = 0;

      UpdateHorizontalPosition();

      foreach (var wColumn in ColumnDatas)
      {
        if (!wColumn.IsHidden && (wColumn.IsFrozen || (wColumn.Left + wColumn.Width > 0) && (wColumn.Left < mCellCanvas.ActualWidth)))
        {
          if (!wColumn.IsVisible)
          {
            mSetVisibleTrue.Add(wColumn);
          }
          VisibleColumns++;
        }
        else
        {
          if (wColumn.IsVisible)
          {
            mSetVisibleFalse.Add(wColumn);
          }
        }
      }

      if (runActions)
      {
        RunElementActions();
      }
    }

    public void UpdateVerticalVisibility()
    {
      UpdateVerticalVisibility(true);
    }

    private bool mShouldRunUpdateVerticalVisibility;

    private void UpdateVerticalVisibility(bool runActions)
    {
      if (IsLayoutSuspended) return;
      if (!IsLoaded) return;

      if (mIsRunningElementActions)
      {
        mShouldRunUpdateVerticalVisibility = true;
        return;
      }

      VisibleRows = 0;

      UpdateVerticalPosition();

      var wCellCanvasHeight = mCellCanvas.ActualHeight;

      foreach (var wRow in RowDatas)
      {
        if (wRow.IsFrozen || ((wRow.Top + wRow.CalculatedHeight > 0) && (wRow.Top < wCellCanvasHeight)))
        {
          VisibleRows++;
          if (!wRow.IsVisible)
          {
            mSetVisibleTrue.Add(wRow);
          }

          wRow.EnsureCells();
        }
        else
        {
          if (wRow.IsVisible)
          {
            mSetVisibleFalse.Add(wRow);
          }
        }
      }

      if (runActions)
      {
        RunElementActions();
      }
    }

    private Dictionary<FrameworkElement, Canvas> mElementActions = new Dictionary<FrameworkElement, Canvas>();
    private List<IIsVisible> mSetVisibleTrue = new List<IIsVisible>();
    private List<IIsVisible> mSetVisibleFalse = new List<IIsVisible>();

    public void AddElement(CellVisualData cell, FrameworkElement element)
    {
      if (cell.Column.IsFrozen && cell.Row.IsFrozen)
      {
        mElementActions[element] = mFrozenCellCanvas;
      }
      else if (cell.Column.IsFrozen)
      {
        mElementActions[element] = mFrozenColumnCellCanvas;
      }
      else if (cell.Row.IsFrozen)
      {
        mElementActions[element] = mFrozenRowCellCanvas;
      }
      else
      {
        mElementActions[element] = mCellCanvas;
      }
    }

    public void RemoveElement(FrameworkElement element)
    {
      mElementActions[element] = null;
    }

    private int mAdd = 0;
    private int mRemove = 0;

    private bool mIsRunningElementActions;

    private void RunElementActions()
    {
      mIsRunningElementActions = true;

      foreach (var wItem in mSetVisibleFalse)
      {
        wItem.IsVisible = false;
      }
      mSetVisibleFalse.Clear();

      foreach (var wItem in mSetVisibleTrue)
      {
        wItem.IsVisible = true;
      }
      mSetVisibleTrue.Clear();

      foreach (var wAction in mElementActions)
      {
        if (wAction.Key.Parent != wAction.Value)
        {
          if (wAction.Key.Parent != null)
          {
            mRemove++;
            ((Canvas)wAction.Key.Parent).Children.Remove(wAction.Key);
          }

          if (wAction.Value != null)
          {
            mAdd++;
            wAction.Value.Children.Add(wAction.Key);
          }
        }

        if (wAction.Value != null)
        {
          foreach (var wBinding in EnumerateBindingExpressions(wAction.Key))
          {
            wBinding.UpdateTarget();
          }
        }
      }

      foreach (var wColumn in ColumnDatas)
      {
        wColumn.ReleaseElements();
      }

      mElementActions.Clear();

      mIsRunningElementActions = false;

      if (mShouldRunUpdateHorizontalVisibility && mShouldRunUpdateVerticalVisibility)
      {
        mShouldRunUpdateHorizontalVisibility = false;
        mShouldRunUpdateVerticalVisibility = false;
        UpdateVisibility();
      }
      else if (mShouldRunUpdateHorizontalVisibility)
      {
        mShouldRunUpdateHorizontalVisibility = false;
        UpdateHorizontalVisibility();
      }
      else if (mShouldRunUpdateVerticalVisibility)
      {
        mShouldRunUpdateVerticalVisibility = false;
        UpdateVerticalVisibility();
      }
    }

    private static IEnumerable<BindingExpressionBase> EnumerateBindingExpressions(DependencyObject element)
    {
      if (element == null)
      {
        throw new ArgumentNullException("element");
      }

      var wEnumerator = element.GetLocalValueEnumerator();

      while (wEnumerator.MoveNext())
      {
        var wEntry = wEnumerator.Current;

        if (BindingOperations.IsDataBound(element, wEntry.Property))
        {
          yield return wEntry.Value as BindingExpressionBase;
        }
      }
    }

    private List<VirtualGridRow> mFreeRowElements = new List<VirtualGridRow>();

    internal VirtualGridRow GetRowElement(bool isFrozen)
    {
      VirtualGridRow wElement;
      if (mFreeRowElements.Count > 0)
      {
        wElement = mFreeRowElements[mFreeRowElements.Count - 1];
        mFreeRowElements.RemoveAt(mFreeRowElements.Count - 1);
        wElement.Visibility = Visibility.Visible;
      }
      else
      {
        wElement = new VirtualGridRow();
        wElement.SetBinding(VirtualGridRow.DataContextProperty, new Binding("Row.Data")
        {
          Source = wElement
        });
        wElement.SetBinding(VirtualGridRow.WidthProperty, new Binding("Parent.ActualWidth")
        {
          Source = wElement
        });
        wElement.SetBinding(Canvas.TopProperty, new Binding("Row.Top")
        {
          Source = wElement
        });
        wElement.SetBinding(VirtualGridRow.HeightProperty, new Binding("Row.CalculatedHeight")
        {
          Source = wElement
        });
        wElement.SetBinding(VirtualGridRow.MaxWidthProperty, new Binding("TotalWidth")
        {
          Source = this
        });
        wElement.SetBinding(VirtualGridRow.StyleProperty, new Binding("RowStyle")
        {
          Source = this
        });
        if (GridLinesVisibility == DataGridGridLinesVisibility.All || GridLinesVisibility == DataGridGridLinesVisibility.Horizontal)
        {
          wElement.SetBinding(Border.BorderBrushProperty, new Binding("HorizontalGridLinesBrush")
          {
            Source = this
          });
          wElement.BorderThickness = new Thickness(0, 0, 0, 1);
        }
      }

      mElementActions[wElement] = isFrozen ? mFrozenRowCanvas : mRowCanvas;
      return wElement;
    }

    internal void FreeRowElement(VirtualGridRow element)
    {
      if (mFreeRowElements.Count > VisibleRows + 2)
      {
        RemoveElement(element);
      }
      else
      {
        element.Visibility = Visibility.Collapsed;
        mFreeRowElements.Add(element);
      }
    }

    private List<Border> mFreeColumnElements = new List<Border>();

    internal Border GetColumnElement(bool isFrozen)
    {
      Border wElement;
      if (mFreeColumnElements.Count > 0)
      {
        wElement = mFreeColumnElements[mFreeColumnElements.Count - 1];
        mFreeColumnElements.RemoveAt(mFreeColumnElements.Count - 1);
        wElement.Visibility = Visibility.Visible;
      }
      else
      {
        wElement = new Border()
        {
          SnapsToDevicePixels = true
        };

        wElement.SetBinding(Border.HeightProperty, new Binding("Parent.ActualHeight")
        {
          Source = wElement
        });
        wElement.SetBinding(Canvas.LeftProperty, new Binding("Tag.Left")
        {
          Source = wElement
        });
        wElement.SetBinding(Border.WidthProperty, new Binding("Tag.Width")
        {
          Source = wElement
        });
        wElement.SetBinding(Border.BackgroundProperty, new Binding("Tag.Background")
        {
          Source = wElement
        });
        wElement.SetBinding(Border.MaxHeightProperty, new Binding("TotalHeight")
        {
          Source = this
        });
        if (GridLinesVisibility == DataGridGridLinesVisibility.All || GridLinesVisibility == DataGridGridLinesVisibility.Vertical)
        {
          wElement.SetBinding(Border.BorderBrushProperty, new Binding("VerticalGridLinesBrush")
          {
            Source = this
          });
          wElement.BorderThickness = new Thickness(0, 0, 1, 0);
        }
      }

      mElementActions[wElement] = isFrozen ? mFrozenColumnCanvas : mColumnCanvas;
      return wElement;
    }

    internal void FreeColumnElement(Border element)
    {
      if (mFreeColumnElements.Count > VisibleColumns * 2)
      {
        RemoveElement(element);
      }
      else
      {
        element.Visibility = Visibility.Collapsed;
        mFreeColumnElements.Add(element);
      }
    }

    private List<FrameworkElement> mFreeRowDetailElements = new List<FrameworkElement>();

    internal FrameworkElement GetRowDetailElement(bool isFrozen, bool forMeasure = false)
    {
      if (RowDetailsTemplate == null) return null;

      FrameworkElement wElement;
      if (!forMeasure && mFreeRowDetailElements.Count > 0)
      {
        wElement = mFreeRowDetailElements[mFreeRowDetailElements.Count - 1];
        mFreeRowDetailElements.RemoveAt(mFreeRowDetailElements.Count - 1);
        wElement.Visibility = Visibility.Visible;
      }
      else
      {
        var wElementPresenter = new ContentPresenter()
        {
          SnapsToDevicePixels = true,
          ContentTemplate = RowDetailsTemplate
        };
        var wBorderElement = new Border()
        {
          Child = wElementPresenter
        };
        wElement = wBorderElement;
        wElementPresenter.SetBinding(ContentPresenter.ContentProperty, new Binding("DataContext")
        {
          Source = wElement
        });
        switch (RowDetailsWidth)
        {
          case RowDetailsWidth.Auto:
            wElement.SetBinding(ContentPresenter.MinWidthProperty, new Binding("ActualWidth")
            {
              Source = mBackgroundCanvas
            });
            wElement.SetBinding(Canvas.LeftProperty, new Binding("VirtualScrollLeft")
            {
              Source = this,
              Converter = NegateConverter.Instance
            });
            break;
          case RowDetailsWidth.TotalWidth:
            wElement.SetBinding(ContentPresenter.WidthProperty, new Binding("TotalWidth")
            {
              Source = this
            });
            wElement.SetBinding(Canvas.LeftProperty, new Binding("VirtualScrollLeft")
            {
              Source = this,
              Converter = NegateConverter.Instance
            });
            break;
          case RowDetailsWidth.VisibleWidth:
            wElement.SetBinding(ContentPresenter.WidthProperty, new Binding("ActualWidth")
            {
              Source = mBackgroundCanvas
            });
            break;
        }
        wElement.SetBinding(Canvas.TopProperty, new Binding("Tag.DetailTop")
        {
          Source = wElement
        });
        //wElement.SetBinding(ContentPresenter.HeightProperty, new Binding("Tag.DetailHeight")
        //{
        //  Source = wElement
        //});
        wElement.SetBinding(Border.BackgroundProperty, new Binding("Tag.Background")
        {
          Source = wElement
        });
        if (GridLinesVisibility == DataGridGridLinesVisibility.All || GridLinesVisibility == DataGridGridLinesVisibility.Horizontal)
        {
          wElement.SetBinding(Border.BorderBrushProperty, new Binding("HorizontalGridLinesBrush")
          {
            Source = this
          });
          wBorderElement.BorderThickness = new Thickness(0, 1, 0, 1);
        }
      }

      if (!forMeasure)
      {
        mElementActions[wElement] = isFrozen ? mFrozenDetailCanvas : mDetailCanvas;
      }

      return wElement;
    }

    internal void FreeRowDetailElement(FrameworkElement element)
    {
      if (mFreeRowDetailElements.Count > VisibleRows * 2)
      {
        RemoveElement(element);
      }
      else
      {
        element.Visibility = Visibility.Collapsed;
        mFreeRowDetailElements.Add(element);
      }
    }

    private List<VirtualGridCell> mFreeElements = new List<VirtualGridCell>();
    private List<VirtualGridCell> mFreeEditElements = new List<VirtualGridCell>();
    private List<FrameworkElement> mMeasureElements = new List<FrameworkElement>();

    internal List<VirtualGridCell> GetTextColumnStore(bool isEditing)
    {
      return isEditing ? mFreeEditElements : mFreeElements;
    }

    internal List<FrameworkElement> GetTextMeasureElementStore()
    {
      return mMeasureElements;
    }

    private Line mResizeLine;

    internal void Resizing(double value, bool isHorizontal)
    {
      if (mResizeLine == null)
      {
        mResizeLine = new Line();
        mOverlayCanvas.Children.Add(mResizeLine);

        mResizeLine.Stroke = Brushes.DarkGray;
        mResizeLine.StrokeThickness = 1;
        var wCollection = new double[] { 3, 3 };
        mResizeLine.StrokeDashArray = new DoubleCollection(wCollection);
      }

      if (isHorizontal)
      {
        mResizeLine.X1 = value;
        mResizeLine.X2 = value;
        mResizeLine.Y1 = 0;
        mResizeLine.Y2 = mOverlayCanvas.ActualWidth;
      }
      else
      {
        mResizeLine.X1 = 0;
        mResizeLine.X1 = mOverlayCanvas.ActualHeight;
        mResizeLine.Y1 = value;
        mResizeLine.Y2 = value;
      }
    }

    internal void EndResize()
    {
      if (mResizeLine != null)
      {
        mOverlayCanvas.Children.Remove(mResizeLine);
        mResizeLine = null;
      }
    }

    #region CellMeasure

    private List<CellVisualData> mCellMeasuring = new List<CellVisualData>();
    private List<CellVisualData> mNextToCellMeasure = new List<CellVisualData>();
    private HashSet<CellVisualData> mToCellMeasure = new HashSet<CellVisualData>();

    private bool mCellMeasuringDispatched;
    private bool mIsCellMeasuringCellsInternal;

    internal void MeasureCell(CellVisualData cell)
    {
      if (cell.IsMeasured || !cell.IsVisible)
      {
        return;
      }

      mToCellMeasure.Add(cell);
      CellMeasureNext();
    }

    private void MeasureCellInternal(CellVisualData cell)
    {
      if (cell == null || cell.Column == null)
      {
        CellMeasureNext();
      }
      else
      {
        mCellMeasuring.Add(cell);

        var wElement = cell.Column.GetMeasureElement(cell);

        wElement.Loaded += CellMeasure_Loaded;

        mMeasureCanvas.Children.Add(wElement);
      }
    }

    private void CellMeasure_Loaded(object sender, RoutedEventArgs e)
    {
      var wElement = (FrameworkElement)sender;
      var wCell = ((IVirtualGridCellPresenter)sender).Cell;

      wElement.Loaded -= CellMeasure_Loaded;

      CellMeasured(wCell, wElement);
    }

    private void CellMeasured(CellVisualData cell, FrameworkElement element)
    {
      cell.MeasuredSize = element.DesiredSize;
      mCellMeasuring.Remove(cell);

      mMeasureCanvas.Children.Remove(element);
      //cell.Column.FreeCellMeasureElement(element);

      CellMeasureNext();
    }

    private void CellMeasureNext()
    {
      if (mIsCellMeasuringCellsInternal) return;

      if (mToCellMeasure.Count > 0)
      {
        while (mNextToCellMeasure.Count < 20 && mToCellMeasure.Count > 0)
        {
          var wCell = mToCellMeasure.First();

          mToCellMeasure.Remove(wCell);

          if (wCell.IsVisible)
          {
            mNextToCellMeasure.Add(wCell);
          }
        }
      }

      if (!mCellMeasuringDispatched && mNextToCellMeasure.Count > 0 && mCellMeasuring.Count == 0)
      {
        mCellMeasuringDispatched = true;
        Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ContextIdle, new Action(MeasureCellsInternal));
      }
    }

    private void MeasureCellsInternal()
    {
      mIsCellMeasuringCellsInternal = true;

      foreach (var wCell in mNextToCellMeasure)
      {
        MeasureCellInternal(wCell);
      }

      mNextToCellMeasure.Clear();
      mIsCellMeasuringCellsInternal = false;
      mCellMeasuringDispatched = false;

      RunElementActions();
    }

    #endregion

    #region DetailMeasure

    private List<RowVisualData> mDetailMeasuring = new List<RowVisualData>();
    private List<RowVisualData> mNextToDetailMeasure = new List<RowVisualData>();
    private HashSet<RowVisualData> mToDetailMeasure = new HashSet<RowVisualData>();

    private bool mDetailMeasuringDispatched;
    private bool mIsDetailMeasuringDetailsInternal;

    internal void MeasureDetail(RowVisualData row)
    {
      if (row.IsDetailMeasured || !row.IsVisible)
      {
        return;
      }

      mToDetailMeasure.Add(row);
      DetailMeasureNext();
    }

    private void MeasureDetailInternal(RowVisualData row)
    {
      mDetailMeasuring.Add(row);

      var wElement = GetRowDetailElement(false, true);
      wElement.Tag = row;
      wElement.DataContext = row.Data;

      wElement.Loaded += DetailMeasure_Loaded;

      mMeasureCanvas.Children.Add(wElement);
    }

    private void DetailMeasure_Loaded(object sender, RoutedEventArgs e)
    {
      var wElement = (FrameworkElement)sender;
      var wRow = (RowVisualData)wElement.Tag;

      wElement.Loaded -= DetailMeasure_Loaded;

      DetailMeasured(wRow, wElement);
    }

    private void DetailMeasured(RowVisualData row, FrameworkElement element)
    {
      row.IsDetailMeasured = true;
      row.DetailHeight = element.DesiredSize.Height;
      mDetailMeasuring.Remove(row);

      mMeasureCanvas.Children.Remove(element);
      //Detail.Column.FreeDetailMeasureElement(element);

      DetailMeasureNext();
    }

    private void DetailMeasureNext()
    {
      if (mIsDetailMeasuringDetailsInternal) return;

      if (mToDetailMeasure.Count > 0)
      {
        while (mNextToDetailMeasure.Count < 20 && mToDetailMeasure.Count > 0)
        {
          var wDetail = mToDetailMeasure.First();

          mToDetailMeasure.Remove(wDetail);

          if (wDetail.IsVisible)
          {
            mNextToDetailMeasure.Add(wDetail);
          }
        }
      }

      if (!mDetailMeasuringDispatched && mNextToDetailMeasure.Count > 0 && mDetailMeasuring.Count == 0)
      {
        mDetailMeasuringDispatched = true;
        Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ContextIdle, new Action(DetailMeasureDetailsInternal));
      }
    }

    private void DetailMeasureDetailsInternal()
    {
      mIsDetailMeasuringDetailsInternal = true;

      foreach (var wDetail in mNextToDetailMeasure)
      {
        MeasureDetailInternal(wDetail);
      }

      mNextToDetailMeasure.Clear();
      mIsDetailMeasuringDetailsInternal = false;
      mDetailMeasuringDispatched = false;

      RunElementActions();
    }

    #endregion

    bool IsLayoutSuspended
    {
      get { return mSuspendLayout > 0; }
    }

    void SuspendLayout()
    {
      mSuspendLayout++;
    }

    void ResumeLayout()
    {
      mSuspendLayout--;

      if (mSuspendLayout == 0)
      {
        UpdateVisibility();
        if (mShouldUpdateAvarageVirtualHeight)
        {
          UpdateAvarageVirtualHeight();
        }
      }
    }

    private CellVisualData mEditedCell;

    internal void EditCell(CellVisualData cell)
    {
      if (mEditedCell != null)
      {
        mEditedCell.IsEditing = false;
      }

      if (IsReadOnly || cell.Column.Column.IsReadOnly)
      {
        mEditedCell = null;
      }
      else
      {
        mEditedCell = cell;

        if (mEditedCell != null)
        {
          mEditedCell.IsEditing = true;
        }
      }
    }

    internal double AvarageRowHeight { get; private set; }

    private bool mShouldUpdateAvarageVirtualHeight;

    internal void UpdateAvarageVirtualHeight()
    {
      if (IsLayoutSuspended)
      {
        mShouldUpdateAvarageVirtualHeight = true;
        return;
      }

      mShouldUpdateAvarageVirtualHeight = false;

      if (RowDatas != null)
      {
        if (RowDatas.Any(w => w != null && !double.IsNaN(w.Height)))
        {
          AvarageRowHeight = Math.Ceiling(RowDatas.Where(w => w != null && !double.IsNaN(w.Height)).Average(a => a.Height));
        }
        else
        {
          AvarageRowHeight = 30;
        }
      }
    }

    #region Input

    private void VirtualGrid_MouseWheel(object sender, System.Windows.Input.MouseWheelEventArgs e)
    {
      VirtualScrollTop -= e.Delta;
      e.Handled = true;
    }

    private void VirtualGrid_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
      if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.A)
      {
        SelectAll();
      }
      else
      {
        var wDirection = GetDirection(e.Key);
        if (wDirection == Direction.None) return;

        MoveSelection(wDirection);
      }
      e.Handled = true;
    }

    #endregion

    #region Selection

    private ObservableCollection<object> mSelectedItems = new ObservableCollection<object>();

    public ReadOnlyObservableCollection<object> SelectedItems
    {
      get { return (ReadOnlyObservableCollection<object>)GetValue(SelectedItemsProperty); }
      private set { SetValue(SelectedItemsPropertyKey, value); }
    }
    private static DependencyPropertyKey SelectedItemsPropertyKey =
        DependencyProperty.RegisterReadOnly("SelectedItems", typeof(ReadOnlyObservableCollection<object>), typeof(VirtualGrid), new PropertyMetadata(null));
    public static DependencyProperty SelectedItemsProperty = SelectedItemsPropertyKey.DependencyProperty;

    public ReadOnlyObservableCollection<CellVisualData> SelectedCells
    {
      get { return (ReadOnlyObservableCollection<CellVisualData>)GetValue(SelectedCellsProperty); }
      private set { SetValue(SelectedCellsPropertyKey, value); }
    }

    private static DependencyPropertyKey SelectedCellsPropertyKey =
        DependencyProperty.RegisterReadOnly("SelectedCells", typeof(ReadOnlyObservableCollection<CellVisualData>), typeof(VirtualGrid), new PropertyMetadata(null));
    public static DependencyProperty SelectedCellsProperty = SelectedCellsPropertyKey.DependencyProperty;

    public static readonly RoutedEvent SelectionChangingEvent = EventManager.RegisterRoutedEvent("SelectionChanging", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(VirtualGrid));

    public event RoutedEventHandler SelectionChanging
    {
      add { AddHandler(SelectionChangingEvent, value); }
      remove { RemoveHandler(SelectionChangingEvent, value); }
    }

    public static readonly RoutedEvent SelectionChangedEvent = EventManager.RegisterRoutedEvent("SelectionChanged", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(VirtualGrid));

    public event RoutedEventHandler SelectionChanged
    {
      add { AddHandler(SelectionChangedEvent, value); }
      remove { RemoveHandler(SelectionChangedEvent, value); }
    }

    private void MoveSelection(Direction direction)
    {
      if (mSelectedCells.Count == 0)
      {
        SelectFirst();
      }
      else
      {
        if (mSelectedCells.Count > 1)
        {
          if (SelectionUnit != DataGridSelectionUnit.FullRow) return;

          var wFirst = mSelectedCells.First().Row;

          if (!mSelectedCells.All(a => a.Row == wFirst)) return;
        }

        switch (direction)
        {
          case Direction.Down:
            MoveByRow(1);
            break;
          case Direction.PageDown:
            MoveByRow(VisibleRows);
            break;
          case Direction.Up:
            MoveByRow(-1);
            break;
          case Direction.PageUp:
            MoveByRow(-VisibleRows);
            break;
          case Direction.Left:
            MoveByColumn(-1);
            break;
          case Direction.Right:
            MoveByColumn(1);
            break;
        }
      }
    }

    private void MoveByRow(int diff)
    {
      var wFirstCell = mSelectedCells.First();
      var wIndex = Array.IndexOf(RowDatas, wFirstCell.Row) + diff;

      if (wIndex < mFrozenRowCount)
      {
        wIndex = mFrozenRowCount;
      }
      else if (wIndex >= RowDatas.Length)
      {
        wIndex = RowDatas.Length - 1;
      }

      var wRow = RowDatas[wIndex];
      wRow.EnsureCells();

      var wCell = wRow.Cells.First(f => f.Column == wFirstCell.Column);

      Select(SelectionSource.Cell, Controls.VirtualGrid.SelectionMode.Start, wCell);
    }

    private void MoveByColumn(int diff)
    {
      var wFirstCell = mSelectedCells.First();

      var wColumns = OrderedColumnDatas.Where(w => !w.IsHidden).ToArray();

      var wIndex = Array.IndexOf(wColumns, wFirstCell.Column) + diff;

      if (wIndex < 0)
      {
        wIndex = 0;
      }
      else if (wIndex >= wColumns.Length)
      {
        wIndex = wColumns.Length - 1;
      }

      var wCell = wFirstCell.Row.Cells.First(f => f.Column == wColumns[wIndex]);

      Select(SelectionSource.Cell, Controls.VirtualGrid.SelectionMode.Start, wCell);
    }

    private Direction GetDirection(Key key)
    {
      switch (key)
      {
        case Key.Left:
          return Direction.Left;
        case Key.Right:
          return Direction.Right;
        case Key.Up:
          return Direction.Up;
        case Key.Down:
          return Direction.Down;
        case Key.PageUp:
          return Direction.PageUp;
        case Key.PageDown:
          return Direction.PageDown;
        case Key.Tab:
          if (SelectionUnit != DataGridSelectionUnit.Cell) return Direction.None;

          return Keyboard.Modifiers.HasFlag(ModifierKeys.Control) ? Direction.Left : Direction.Right;
        default:
          return Direction.None;
      }
    }

    private void SelectFirst()
    {
      var wFirstRow = RowDatas.Skip(mHeaderRowCount).FirstOrDefault();

      if (wFirstRow == null) return;

      wFirstRow.EnsureCells();
      var wFirstCell = wFirstRow.Cells.FirstOrDefault();

      if (wFirstCell == null) return;

      Select(SelectionSource.Cell, Controls.VirtualGrid.SelectionMode.Start, wFirstCell);
    }

    private void SelectAll()
    {
      mSuspendBringCellIntoView++;

      SelectFirst();

      var wLastRow = RowDatas.Skip(mHeaderRowCount).LastOrDefault();

      if (wLastRow == null) return;

      wLastRow.EnsureCells();
      var wLastCell = wLastRow.Cells.LastOrDefault();

      if (wLastCell == null) return;

      Select(SelectionSource.Cell, Controls.VirtualGrid.SelectionMode.Extend, wLastCell);

      mSuspendBringCellIntoView--;
    }

    private bool IsSelectionValid(SelectionSource source, SelectionMode mode)
    {
      if (SelectionMode == DataGridSelectionMode.Single && mode != Controls.VirtualGrid.SelectionMode.Start) return false;

      if (source == SelectionSource.ColumnHeader) return false;
      if (SelectionUnit == DataGridSelectionUnit.Cell && source != SelectionSource.Cell) return false;

      return true;
    }

    private ObservableCollection<CellVisualData> mSelectedCells = new ObservableCollection<CellVisualData>();

    private CellVisualData mLastSelectedCell;
    private int mSuspendBringCellIntoView;

    internal void Select(SelectionSource source, SelectionMode mode, CellVisualData cell)
    {
      if (cell == null) return;
      if (!IsSelectionValid(source, mode)) return;

      RaiseEvent(new RoutedEventArgs(SelectionChangingEvent));

      if (mode == Controls.VirtualGrid.SelectionMode.Extend && mLastSelectedCell == null)
      {
        mode = Controls.VirtualGrid.SelectionMode.Start;
      }

      if (mode == Controls.VirtualGrid.SelectionMode.Start)
      {
        //Deselect all
        DeSelectAll();
      }

      if (mode == Controls.VirtualGrid.SelectionMode.Start || mode == Controls.VirtualGrid.SelectionMode.Append)
      {
        SelectCell(cell);
      }
      else
      {
        var wLastRowIndex = Array.IndexOf(RowDatas, mLastSelectedCell.Row);
        var wNewRowIndex = Array.IndexOf(RowDatas, cell.Row);

        var wLastColumnIndex = Array.IndexOf(OrderedColumnDatas, mLastSelectedCell.Column);
        var wNewColumnIndex = Array.IndexOf(OrderedColumnDatas, cell.Column);

        var wFromRowIndex = Math.Min(wLastRowIndex, wNewRowIndex);
        var wToRowIndex = Math.Max(wLastRowIndex, wNewRowIndex);

        var wFromColumnIndex = Math.Min(wLastColumnIndex, wNewColumnIndex);
        var wToColumnIndex = Math.Max(wLastColumnIndex, wNewColumnIndex);

        for (var wRowIndex = wFromRowIndex; wRowIndex <= wToRowIndex; wRowIndex++)
        {
          for (var wColumnIndex = wFromColumnIndex; wColumnIndex <= wToColumnIndex; wColumnIndex++)
          {
            var wRow = RowDatas[wRowIndex];
            wRow.EnsureCells();
            var wCell = wRow.Cells.First(f => f.Column == OrderedColumnDatas[wColumnIndex]);

            SelectCell(wCell, true);
          }
        }
      }

      mLastSelectedCell = cell;
      if (mLastSelectedCell.Element != null)
      {
        mLastSelectedCell.Element.Focus();
      }

      if (mSuspendBringCellIntoView == 0)
      {
        BringCellIntoView(mLastSelectedCell);
      }

      RaiseEvent(new RoutedEventArgs(SelectionChangedEvent));
    }

    private void SelectCell(CellVisualData cell, bool? change = null)
    {
      switch (SelectionUnit)
      {
        case DataGridSelectionUnit.Cell:
        case DataGridSelectionUnit.CellOrRowHeader:
          if (!mSelectedCells.Contains(cell))
          {
            if (change != false)
            {
              mSelectedCells.Add(cell);
              cell.IsSelected = true;

              if (!mSelectedItems.Contains(cell.Data))
              {
                mSelectedItems.Add(cell.Data);
              }
            }
          }
          else
          {
            if (change != true)
            {
              mSelectedCells.Remove(cell);
              cell.IsSelected = false;

              if (mSelectedCells.All(a => a.Data != cell.Data))
              {
                mSelectedItems.Remove(cell.Data);
              }
            }
          }
          break;
        case DataGridSelectionUnit.FullRow:
          if (!mSelectedCells.Contains(cell))
          {
            if (change != false)
            {
              foreach (var wCell in cell.Row.Cells)
              {
                mSelectedCells.Add(wCell);
                wCell.IsSelected = true;
              }
              mSelectedItems.Add(cell.Data);
            }
          }
          else
          {
            if (change != true)
            {
              foreach (var wCell in cell.Row.Cells)
              {
                mSelectedCells.Remove(wCell);
                wCell.IsSelected = false;
              }
              mSelectedItems.Remove(cell.Data);
            }
          }
          break;
      }
    }

    private void DeSelectAll()
    {
      foreach (var wCell in mSelectedCells)
      {
        wCell.IsSelected = false;
      }
      mSelectedCells.Clear();
      mSelectedItems.Clear();
      mLastSelectedCell = null;
    }

    public void SelectItems(IEnumerable items)
    {
      DeSelectAll();

      if (items != null)
      {
        var wItems = new HashSet<object>(items.OfType<object>());

        foreach (var wRow in RowDatas.Where(w => wItems.Contains(w.Data)))
        {
          wRow.EnsureCells();
          Select(SelectionSource.Cell, Controls.VirtualGrid.SelectionMode.Append, wRow.Cells.First());
        }
      }
    }

    #endregion

    private void BringCellIntoView(CellVisualData cell)
    {
      if (!cell.IsVisible)
      {
        if (!cell.Column.IsVisible)
        {
          if (cell.Left < 0)
          {
            VirtualScrollLeft += cell.Left;
          }
          else
          {
            VirtualScrollLeft += cell.Left + cell.Width - mCellCanvas.ActualWidth;
          }
        }
        if (!cell.Row.IsVisible)
        {
          if (cell.Top < 0)
          {
            VirtualScrollTop += cell.Top;
          }
          else
          {
            VirtualScrollTop += cell.Top + cell.Height - mCellCanvas.ActualHeight;
          }
        }
      }
    }

    public void OpenAllDetails(Func<object, bool> filter = null)
    {
      SuspendLayout();
      try
      {
        if (RowDatas == null) return;

        if (filter == null)
        {
          for (var i = mHeaderRowCount; i < RowDatas.Length; i++)
          {
            RowDatas[i].IsOpened = true;
          }
        }
        else
        {
          for (var i = mHeaderRowCount; i < RowDatas.Length; i++)
          {
            var wData = RowDatas[i];

            if (filter(wData.Data))
            {
              wData.IsOpened = true;
            }
          }
        }
      }
      finally
      {
        ResumeLayout();
      }
    }

    public void CloseAllDetails(Func<object, bool> filter = null)
    {
      SuspendLayout();
      try
      {
        if (RowDatas == null) return;

        if (filter == null)
        {
          for (var i = mHeaderRowCount; i < RowDatas.Length; i++)
          {
            RowDatas[i].IsOpened = false;
          }
        }
        else
        {
          for (var i = mHeaderRowCount; i < RowDatas.Length; i++)
          {
            var wData = RowDatas[i];

            if (filter(wData.Data))
            {
              wData.IsOpened = false;
            }
          }
        }
      }
      finally
      {
        ResumeLayout();
      }
    }

  }
}
