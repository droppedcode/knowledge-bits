﻿namespace Insight.Presentation.Controls.VirtualGrid
{
  public interface IVirtualGridCellPresenter
  {
    CellVisualData Cell { get; set; }
  }
}