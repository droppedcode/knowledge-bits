﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;

namespace Insight.Presentation.Controls.VirtualGrid
{
  /// <summary>
  /// Represents the header for each row of the DataGrid
  /// </summary>
  [TemplatePart(Name = "PART_TopHeaderGripper", Type = typeof(Thumb))]
  [TemplatePart(Name = "PART_BottomHeaderGripper", Type = typeof(Thumb))]
  public class VirtualGridRowHeader : ButtonBase, IVirtualGridCellPresenter
  {
    static VirtualGridRowHeader()
    {
      DefaultStyleKeyProperty.OverrideMetadata(typeof(VirtualGridRowHeader), new FrameworkPropertyMetadata(typeof(VirtualGridRowHeader)));

      ClickModeProperty.OverrideMetadata(typeof(VirtualGridRowHeader), new FrameworkPropertyMetadata(ClickMode.Press));
      FocusableProperty.OverrideMetadata(typeof(VirtualGridRowHeader), new FrameworkPropertyMetadata(false));
    }

    #region Layout

    /// <summary>
    ///     Property that indicates the brush to use when drawing seperators between headers.
    /// </summary>
    public Brush SeparatorBrush
    {
      get { return (Brush)GetValue(SeparatorBrushProperty); }
      set { SetValue(SeparatorBrushProperty, value); }
    }

    /// <summary>
    ///     DependencyProperty for SeperatorBrush.
    /// </summary>
    public static readonly DependencyProperty SeparatorBrushProperty =
        DependencyProperty.Register("SeparatorBrush", typeof(Brush), typeof(VirtualGridRowHeader), new FrameworkPropertyMetadata(null));

    /// <summary>
    ///     Property that indicates the Visibility for the header seperators.
    /// </summary>
    public Visibility SeparatorVisibility
    {
      get { return (Visibility)GetValue(SeparatorVisibilityProperty); }
      set { SetValue(SeparatorVisibilityProperty, value); }
    }

    /// <summary>
    ///     DependencyProperty for SeperatorBrush.
    /// </summary>
    public static readonly DependencyProperty SeparatorVisibilityProperty =
        DependencyProperty.Register("SeparatorVisibility", typeof(Visibility), typeof(VirtualGridRowHeader), new FrameworkPropertyMetadata(Visibility.Visible));

    #endregion

    #region Row Communication

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();

      // Grippers will now be in the Visual tree.
      HookupGripperEvents();
    }

    #endregion

    #region Selection

    /// <summary>
    ///     Indicates whether the owning DataGridRow is selected.
    /// </summary>
    [Bindable(true), Category("Appearance")]
    public bool IsRowSelected
    {
      get { return (bool)GetValue(IsRowSelectedProperty); }
    }

    private static readonly DependencyPropertyKey IsRowSelectedPropertyKey =
        DependencyProperty.RegisterReadOnly(
            "IsRowSelected",
            typeof(bool),
            typeof(VirtualGridRowHeader),
            new FrameworkPropertyMetadata(false));

    /// <summary>
    ///     The DependencyProperty for the IsRowSelected property.
    /// </summary>
    public static readonly DependencyProperty IsRowSelectedProperty = IsRowSelectedPropertyKey.DependencyProperty;

    /// <summary>
    ///     Called when the header is clicked.
    /// </summary>
    protected override void OnClick()
    {
      base.OnClick();

      // The base implementation took capture. This prevents us from doing
      // drag selection, so release it.
      if (Mouse.Captured == this)
      {
        ReleaseMouseCapture();
      }

    }

    #endregion

    #region Row Resizing

    /// <summary>
    /// Find grippers and register drag events
    ///
    /// The default style for VirtualGridRowHeader is
    /// +-------------------------------+
    /// +-------------------------------+
    /// +           Gripper             +
    /// +-------------------------------+
    /// +            Header             +
    /// +-------------------------------+
    /// +           Gripper             +
    /// +-------------------------------+
    /// +-------------------------------+
    ///
    /// The reason we have two grippers is we can't extend the bottom gripper to straddle the line between two
    /// headers; the header below would render on top of it.
    /// We resize a Row by grabbing the gripper to the bottom; the top gripper thus adjusts the height of
    /// the row above it.
    /// </summary>
    private void HookupGripperEvents()
    {
      UnhookGripperEvents();

      _topGripper = GetTemplateChild(TopHeaderGripperTemplateName) as Thumb;
      _bottomGripper = GetTemplateChild(BottomHeaderGripperTemplateName) as Thumb;

      if (_topGripper != null)
      {
        _topGripper.DragStarted += new DragStartedEventHandler(OnRowHeaderGripperDragStarted);
        _topGripper.DragDelta += new DragDeltaEventHandler(OnRowHeaderResize);
        _topGripper.DragCompleted += new DragCompletedEventHandler(OnRowHeaderGripperDragCompleted);
        _topGripper.MouseDoubleClick += new MouseButtonEventHandler(OnGripperDoubleClicked);

        IsTopGripperVisibile = mIsTopGripperVisibile;
      }

      if (_bottomGripper != null)
      {
        _bottomGripper.DragStarted += new DragStartedEventHandler(OnRowHeaderGripperDragStarted);
        _bottomGripper.DragDelta += new DragDeltaEventHandler(OnRowHeaderResize);
        _bottomGripper.DragCompleted += new DragCompletedEventHandler(OnRowHeaderGripperDragCompleted);
        _bottomGripper.MouseDoubleClick += new MouseButtonEventHandler(OnGripperDoubleClicked);

        IsBottomGripperVisibile = mIsBottomGripperVisibile;
      }
    }

    private void OnRowHeaderGripperDragStarted(object sender, DragStartedEventArgs e)
    {
      throw new NotImplementedException();
    }

    private void OnRowHeaderResize(object sender, DragDeltaEventArgs e)
    {
      throw new NotImplementedException();
    }

    private void OnRowHeaderGripperDragCompleted(object sender, DragCompletedEventArgs e)
    {
      throw new NotImplementedException();
    }

    private void OnGripperDoubleClicked(object sender, MouseButtonEventArgs e)
    {
      throw new NotImplementedException();
    }

    /// <summary>
    /// Clear gripper event
    /// </summary>
    private void UnhookGripperEvents()
    {
      if (_topGripper != null)
      {
        _topGripper.DragStarted -= new DragStartedEventHandler(OnRowHeaderGripperDragStarted);
        _topGripper.DragDelta -= new DragDeltaEventHandler(OnRowHeaderResize);
        _topGripper.DragCompleted -= new DragCompletedEventHandler(OnRowHeaderGripperDragCompleted);
        _topGripper.MouseDoubleClick -= new MouseButtonEventHandler(OnGripperDoubleClicked);
        _topGripper = null;
      }

      if (_bottomGripper != null)
      {
        _bottomGripper.DragStarted -= new DragStartedEventHandler(OnRowHeaderGripperDragStarted);
        _bottomGripper.DragDelta -= new DragDeltaEventHandler(OnRowHeaderResize);
        _bottomGripper.DragCompleted -= new DragCompletedEventHandler(OnRowHeaderGripperDragCompleted);
        _bottomGripper.MouseDoubleClick -= new MouseButtonEventHandler(OnGripperDoubleClicked);
        _bottomGripper = null;
      }
    }

    private bool mIsTopGripperVisibile;
    public bool IsTopGripperVisibile
    {
      get { return mIsTopGripperVisibile; }
      set
      {
        mIsTopGripperVisibile = value;
        if (_topGripper != null)
        {
          _topGripper.Visibility = value ? Visibility.Visible : Visibility.Collapsed;
        }
      }
    }

    private bool mIsBottomGripperVisibile;
    public bool IsBottomGripperVisibile
    {
      get { return mIsBottomGripperVisibile; }
      set
      {
        mIsBottomGripperVisibile = value;
        if (_bottomGripper != null)
        {
          _bottomGripper.Visibility = value ? Visibility.Visible : Visibility.Collapsed;
        }
      }
    }

    #endregion

    public CellVisualData Cell
    {
      get { return (CellVisualData)GetValue(CellProperty); }
      set { SetValue(CellProperty, value); }
    }

    public static readonly DependencyProperty CellProperty =
        DependencyProperty.Register("Cell", typeof(CellVisualData), typeof(VirtualGridRowHeader), new PropertyMetadata(null));

    private Thumb _topGripper, _bottomGripper;
    private const string TopHeaderGripperTemplateName = "PART_TopHeaderGripper";
    private const string BottomHeaderGripperTemplateName = "PART_BottomHeaderGripper";
  }
}
