﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace Insight.Presentation.Controls.VirtualGrid
{
  public static class VirtualGridHelper
  {
    public static void AddBindingTo(FrameworkElement targetObject, DependencyProperty targetProperty, object sourceObject, string sourcePath, IValueConverter converter = null)
    {
      targetObject.SetBinding(targetProperty, new Binding(sourcePath)
      {
        Source = sourceObject,
        Converter = converter
      });
    }

    public static void AddPriorityBindingTo(FrameworkElement targetObject, DependencyProperty targetProperty, object sourceObject1, string sourcePath1, object sourceObject2, string sourcePath2)
    {
      var wBinding = new PriorityBinding();
      wBinding.Bindings.Add(new Binding(sourcePath1) { Source = sourceObject1 });
      wBinding.Bindings.Add(new Binding(sourcePath2) { Source = sourceObject2 });

      targetObject.SetBinding(targetProperty, wBinding);
    }

    public static BindingBase CloneBinding(BindingBase bindingBase)
    {
      var binding = bindingBase as Binding;
      if (binding != null)
      {
        var result = new Binding
        {
          Source = binding.Source,
          AsyncState = binding.AsyncState,
          BindingGroupName = binding.BindingGroupName,
          BindsDirectlyToSource = binding.BindsDirectlyToSource,
          Converter = binding.Converter,
          ConverterCulture = binding.ConverterCulture,
          ConverterParameter = binding.ConverterParameter,
          //ElementName = binding.ElementName,
          FallbackValue = binding.FallbackValue,
          IsAsync = binding.IsAsync,
          Mode = binding.Mode,
          NotifyOnSourceUpdated = binding.NotifyOnSourceUpdated,
          NotifyOnTargetUpdated = binding.NotifyOnTargetUpdated,
          NotifyOnValidationError = binding.NotifyOnValidationError,
          Path = binding.Path,
          //RelativeSource = binding.RelativeSource,
          StringFormat = binding.StringFormat,
          TargetNullValue = binding.TargetNullValue,
          UpdateSourceExceptionFilter = binding.UpdateSourceExceptionFilter,
          UpdateSourceTrigger = binding.UpdateSourceTrigger,
          ValidatesOnDataErrors = binding.ValidatesOnDataErrors,
          ValidatesOnExceptions = binding.ValidatesOnExceptions,
          XPath = binding.XPath,
        };

        foreach (var validationRule in binding.ValidationRules)
        {
          result.ValidationRules.Add(validationRule);
        }

        return result;
      }

      var multiBinding = bindingBase as MultiBinding;
      if (multiBinding != null)
      {
        var result = new MultiBinding
        {
          BindingGroupName = multiBinding.BindingGroupName,
          Converter = multiBinding.Converter,
          ConverterCulture = multiBinding.ConverterCulture,
          ConverterParameter = multiBinding.ConverterParameter,
          FallbackValue = multiBinding.FallbackValue,
          Mode = multiBinding.Mode,
          NotifyOnSourceUpdated = multiBinding.NotifyOnSourceUpdated,
          NotifyOnTargetUpdated = multiBinding.NotifyOnTargetUpdated,
          NotifyOnValidationError = multiBinding.NotifyOnValidationError,
          StringFormat = multiBinding.StringFormat,
          TargetNullValue = multiBinding.TargetNullValue,
          UpdateSourceExceptionFilter = multiBinding.UpdateSourceExceptionFilter,
          UpdateSourceTrigger = multiBinding.UpdateSourceTrigger,
          ValidatesOnDataErrors = multiBinding.ValidatesOnDataErrors,
          ValidatesOnExceptions = multiBinding.ValidatesOnDataErrors,
        };

        foreach (var validationRule in multiBinding.ValidationRules)
        {
          result.ValidationRules.Add(validationRule);
        }

        foreach (var childBinding in multiBinding.Bindings)
        {
          result.Bindings.Add(CloneBinding(childBinding));
        }

        return result;
      }

      var priorityBinding = bindingBase as PriorityBinding;
      if (priorityBinding != null)
      {
        var result = new PriorityBinding
        {
          BindingGroupName = priorityBinding.BindingGroupName,
          FallbackValue = priorityBinding.FallbackValue,
          StringFormat = priorityBinding.StringFormat,
          TargetNullValue = priorityBinding.TargetNullValue,
        };

        foreach (var childBinding in priorityBinding.Bindings)
        {
          result.Bindings.Add(CloneBinding(childBinding));
        }

        return result;
      }

      throw new NotSupportedException("Failed to clone binding");
    }

    public static double ValueOr(this double value, double orValue)
    {
      return double.IsNaN(value) ? orValue : value;
    }

  }
}
