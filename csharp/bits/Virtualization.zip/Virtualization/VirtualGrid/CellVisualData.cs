﻿using Insight.Common.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Insight.Presentation.Controls.VirtualGrid
{
  public class CellVisualData : ObjectBase
  {
    public CellVisualData(ColumnVisualData column, RowVisualData row, object data)
    {
      SuspendNotifications();

      Column = column;
      Row = row;
      Data = data;

      ResumeNotifications();

      UpdatePosition();
    }

    double mPrevLeft = double.NaN;
    double mPrevTop = double.NaN;
    double mPrevWidth = double.NaN;
    double mPrevHeight = double.NaN;
    double mPrevRight = double.NaN;
    double mPrevBottom = double.NaN;
    bool mPrevIsVisible;

    private RowVisualData mRow;

    public RowVisualData Row
    {
      get { return mRow; }
      private set
      {
        if (mRow == value) return;

        if (mRow != null)
        {
          mRow.RemoveCell(this);
          mRow.PropertyChanged -= Row_PropertyChanged;
        }

        mRow = value;

        if (mRow != null)
        {
          mRow.AddCell(this);
          mRow.PropertyChanged += Row_PropertyChanged;
        }

        UpdatePosition();

        NotifyPropertyChanged();
      }
    }

    private void Row_PropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      UpdatePosition();
    }

    private ColumnVisualData mColumn;

    public ColumnVisualData Column
    {
      get { return mColumn; }
      private set
      {
        if (mColumn == value) return;

        if (mColumn != null)
        {
          mColumn.RemoveCell(this);
          mColumn.PropertyChanged -= Column_PropertyChanged;
        }

        mColumn = value;

        if (mColumn != null)
        {
          mColumn.AddCell(this);
          mColumn.PropertyChanged += Column_PropertyChanged;
        }

        UpdatePosition();

        NotifyPropertyChanged();
      }
    }

    private void Column_PropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      UpdatePosition();
    }

    private double mTopOverride = double.NaN;

    public double Top
    {
      get
      {
        if (!double.IsNaN(mTopOverride)) return mTopOverride;
        if (Row == null) return double.NaN;

        return Row.Top;
      }
    }

    public double Bottom
    {
      get
      {
        if (Row == null) return double.NaN;

        return Row.Top + Row.Height;
      }
    }

    public double Height
    {
      get
      {
        if (Row == null) return double.NaN;

        return Row.CellCalculatedHeight;
      }
    }

    private double mLeftOverride = double.NaN;

    public double Left
    {
      get
      {
        if (!double.IsNaN(mLeftOverride)) return mLeftOverride;
        if (Column == null) return double.NaN;

        return Column.Left;
      }
    }

    public double Right
    {
      get
      {
        if (Column == null) return double.NaN;

        return Column.Left + Column.Width;
      }
    }

    public double Width
    {
      get
      {
        if (Column == null) return double.NaN;

        return Column.Width;
      }
    }

    public bool IsVisible
    {
      get
      {
        if (Column == null) return false;
        if (Row == null) return false;

        return Column.IsVisible && Row.IsVisible;
      }
    }

    private void UpdatePosition()
    {
      if (IsNotificationSuspended) return;
      if (IsDetached) return;

      var wValue = Top;
      if (wValue != mPrevTop)
      {
        NotifyPropertyChanged("Top");
        mPrevTop = wValue;
      }

      wValue = Left;
      if (wValue != mPrevLeft)
      {
        NotifyPropertyChanged("Left");
        mPrevLeft = wValue;
      }

      wValue = Width;
      if (wValue != mPrevWidth)
      {
        NotifyPropertyChanged("Width");
        mPrevWidth = wValue;
      }

      wValue = Height;
      if (wValue != mPrevHeight)
      {
        NotifyPropertyChanged("Height");
        mPrevHeight = wValue;
      }

      wValue = Right;
      if (wValue != mPrevRight)
      {
        NotifyPropertyChanged("Right");
        mPrevRight = wValue;
      }

      wValue = Bottom;
      if (wValue != mPrevBottom)
      {
        NotifyPropertyChanged("Bottom");
        mPrevBottom = wValue;
      }

      var wIsVisible = IsVisible;
      if (wIsVisible != mPrevIsVisible)
      {
        NotifyPropertyChanged("IsVisible");
        mPrevIsVisible = wIsVisible;

        if (wIsVisible)
        {
          if (!IsMeasured)
          {
            Column.Grid.MeasureCell(this);
          }
          AssignElement();
        }
        else if (!IsEditing)
        {
          FreeElement();
        }
      }
    }

    public void AssignElement()
    {
      if (IsDetached) return;

      if (Element == null)
      {
        Element = Column.GetElement(this);
      }
    }

    public void FreeElement()
    {
      if (IsDetached) return;

      if (Element is VirtualGridCell)
      {
        Column.FreeElement((VirtualGridCell)Element, IsEditing);
      }
      else if (Element is VirtualGridColumnHeader)
      {
        Column.FreeElement((VirtualGridColumnHeader)Element);
      }
      else if (Element is VirtualGridRowHeader)
      {
        Column.FreeElement((VirtualGridRowHeader)Element);
      }
      if (Element is IVirtualGridCellPresenter)
      {
        ((IVirtualGridCellPresenter)Element).Cell = null;
      }
      Element = null;
    }

    public void RemoveFromGrid()
    {
      FreeElement();
      Column.RemoveCell(this);
      Column = null;
      Row.RemoveCell(this);
      Row = null;
      Data = null;
    }

    private FrameworkElement mElement;

    public FrameworkElement Element
    {
      get { return mElement; }
      private set
      {
        if (mElement == value) return;

        mElement = value;

        NotifyPropertyChanged();
      }
    }

    private object mData;

    public object Data
    {
      get { return mData; }
      set
      {
        if (mData == value) return;

        mData = value;

        NotifyPropertyChanged();
      }
    }

    private bool mIsEditing;

    public bool IsEditing
    {
      get { return mIsEditing; }
      set
      {
        if (mIsEditing == value) return;
        if (IsDetached) return;

        if (!value && Column.IsTextColumn && Element != null)
        {
          Element.MoveFocus(new TraversalRequest(FocusNavigationDirection.Previous));
        }

        if (IsVisible)
        {
          FreeElement();
        }

        mIsEditing = value;

        if (IsVisible)
        {
          AssignElement();
        }

        NotifyPropertyChanged();

        Column.Grid.UpdateVisibility();
      }
    }

    public bool IsMeasured
    {
      get { return mMeasuredSize != null; }
    }

    private Size? mMeasuredSize;

    public Size? MeasuredSize
    {
      get { return mMeasuredSize; }
      set
      {
        if (mMeasuredSize == value) return;

        mMeasuredSize = value;
        NotifyPropertyChanged();
        NotifyPropertyChanged("IsMeasured");

        if (IsDetached) return;

        Row.CellMeasured(this);
        Column.CellMeasured(this);
      }
    }

    private bool mIsSelected;

    public bool IsSelected
    {
      get { return mIsSelected; }
      set
      {
        if (mIsSelected == value) return;

        mIsSelected = value;

        if (!mIsSelected)
        {
          IsEditing = false;
        }

        NotifyPropertyChanged();
      }
    }

    public override string ToString()
    {
      return "Left" + ": " + Left + ", " +
             "Top" + ": " + Top + ", " +
             "IsVisible" + ": " + IsVisible + ", " +
             "IsEditing" + ": " + IsEditing;
    }

    internal void Drag(double left, double top)
    {
      mLeftOverride = left;
      mTopOverride = top;

      NotifyPropertyChanged("Left");
      NotifyPropertyChanged("Top");
    }

    internal void DragEnd()
    {
      mLeftOverride = double.NaN;
      mTopOverride = double.NaN;

      NotifyPropertyChanged("Left");
      NotifyPropertyChanged("Top");
    }

    private bool IsDetached
    {
      get { return Column == null || Row == null; }         
    }

  }
}
