﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insight.Presentation.Controls.VirtualGrid
{
  public class HeaderRowVisualData : RowVisualData
  {
    public HeaderRowVisualData(VirtualGrid grid) : base(grid)
    {
      IsFrozen = true;
      Height = grid.ColumnHeaderHeight;
    }

    protected override void CreateCells()
    {
      foreach (var wColumn in Grid.ColumnDatas)
      {
        new HeaderCellVisualData(wColumn, this);
      }
    }

  }
}
