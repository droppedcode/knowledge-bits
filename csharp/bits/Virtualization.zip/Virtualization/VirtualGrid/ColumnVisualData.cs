﻿using Insight.Common.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;

namespace Insight.Presentation.Controls.VirtualGrid
{
  public class ColumnVisualData : ObjectBase, IIsVisible
  {
    public string Id { get; private set; }
    public VirtualGrid Grid { get; private set; }
    public DataGridColumn Column { get; private set; }
    private Border mElement;
    private bool mIsTextColumn;

    public ColumnVisualData(string id, VirtualGrid grid, DataGridColumn column)
    {
      Id = id;
      Grid = grid;
      Column = column;

      if (column.Width.IsAbsolute)
      {
        Width = column.Width.Value;
      }

      mIsTextColumn = Column is DataGridTextColumn;
      if (mIsTextColumn)
      {
        mFreeElements = grid.GetTextColumnStore(false);
        mFreeEditElements = grid.GetTextColumnStore(true);
        mMeasureElements = grid.GetTextMeasureElementStore();
      }
      else
      {
        mFreeElements = new List<VirtualGridCell>();
        mFreeEditElements = new List<VirtualGridCell>();
        mMeasureElements = new List<FrameworkElement>();
      }
    }

    internal bool IsTextColumn { get { return mIsTextColumn; } }

    protected override void OnPropertyChanged([CallerMemberName] string propertyName = null)
    {
      base.OnPropertyChanged(propertyName);

      if (propertyName == "Width" || propertyName == "IsMeasured" || propertyName == "IsAllMeasured" || propertyName == "IsHidden")
      {
        Grid.UpdateHorizontalVisibility();
      }
    }

    private double mLeft = double.NaN;

    public double Left
    {
      get { return mLeft; }
      set
      {
        if (mLeft == value) return;

        mLeft = value;

        NotifyPropertyChanged();
      }
    }

    public double AbsoluteLeft { get; internal set; }

    private bool mIsWidthDefault = true;
    private double mWidth = 100;

    public double Width
    {
      get { return mWidth; }
      set
      {
        if (mWidth == value && !mIsWidthDefault) return;

        mIsWidthDefault = false;
        mWidth = value;
        IsMeasured = !double.IsNaN(value);

        NotifyPropertyChanged();
      }
    }

    private double mMinWidth = double.NaN;

    public double MinWidth
    {
      get { return mMinWidth; }
      set
      {
        if (mMinWidth == value) return;

        mMinWidth = value;
        NotifyPropertyChanged();
      }
    }

    private double mMaxWidth = double.NaN;

    public double MaxWidth
    {
      get { return mMaxWidth; }
      set
      {
        if (mMaxWidth == value) return;

        mMaxWidth = value;
        NotifyPropertyChanged();
      }
    }

    private bool mIsLeftGripperVisibile = true;

    public bool IsLeftGripperVisibile
    {
      get { return mIsLeftGripperVisibile; }
      set
      {
        if (mIsLeftGripperVisibile == value) return;

        mIsLeftGripperVisibile = value;
        NotifyPropertyChanged();
      }
    }

    private bool mIsRightGripperVisibile = true;

    public bool IsRightGripperVisibile
    {
      get { return mIsRightGripperVisibile; }
      set
      {
        if (mIsRightGripperVisibile == value) return;

        mIsRightGripperVisibile = value;
        NotifyPropertyChanged();
      }
    }

    private bool mIsMeasured;

    public bool IsMeasured
    {
      get { return mIsMeasured; }
      private set
      {
        if (mIsMeasured == value) return;

        mIsMeasured = value;
        NotifyPropertyChanged();
      }
    }

    private bool mIsAllMeasured;

    public bool IsAllMeasured
    {
      get { return mIsAllMeasured; }
      private set
      {
        if (mIsAllMeasured == value) return;

        mIsAllMeasured = value;
        NotifyPropertyChanged();
      }
    }

    private bool mIsVisible;

    public bool IsVisible
    {
      get { return mIsVisible; }
      set
      {
        if (mIsVisible == value) return;

        mIsVisible = value;
        NotifyPropertyChanged();

        if (mIsVisible)
        {
          mElement = Grid.GetColumnElement(IsFrozen);
          mElement.Tag = this;
        }
        else
        {
          Grid.FreeColumnElement(mElement);
          foreach (var wItem in mFreeEditElements.Where(element => element.Parent != null))
          {
            Grid.RemoveElement(wItem);
          }
          foreach (var wItem in mFreeElements.Where(element => element.Parent != null))
          {
            Grid.RemoveElement(wItem);
          }
        }
      }
    }

    private bool mIsHidden;

    public bool IsHidden
    {
      get { return mIsHidden; }
      set
      {
        if (mIsHidden == value) return;

        mIsHidden = value;
        NotifyPropertyChanged();
      }
    }

    private bool mIsFrozen;

    public bool IsFrozen
    {
      get { return mIsFrozen; }
      set
      {
        if (mIsFrozen == value) return;

        mIsFrozen = value;
        NotifyPropertyChanged();
      }
    }

    private VirtualGridColumnHeader mHeader;
    private List<VirtualGridCell> mFreeElements;
    private List<VirtualGridCell> mFreeEditElements;

    public FrameworkElement GetElement(CellVisualData cell)
    {
      return GetElement(cell, false);
    }

    private List<FrameworkElement> mMeasureElements;

    public FrameworkElement GetMeasureElement(CellVisualData cell)
    {
      FrameworkElement wElement;

      if (mMeasureElements.Count > 0)
      {
        wElement = mMeasureElements[mMeasureElements.Count - 1];
        mMeasureElements.RemoveAt(mMeasureElements.Count - 1);
        ((IVirtualGridCellPresenter)wElement).Cell = cell;
      }
      else
      {
        wElement = GetElement(cell, true);
      }

      return wElement;
    }

    public void FreeMeasureElement(FrameworkElement element)
    {
      if (element is VirtualGridCell)
      {
        mMeasureElements.Add(element);
      }
    }

    private FrameworkElement GetElement(CellVisualData cell, bool forMeasure)
    {
      IVirtualGridCellPresenter wPresenter;
      FrameworkElement wElement;
      var wIsHeader = cell is HeaderCellVisualData;

      if (wIsHeader)
      {
        VirtualGridColumnHeader wHeader;
        if (mHeader != null && !forMeasure)
        {
          wHeader = mHeader;
        }
        else
        {
          wHeader = GetHeaderElement(forMeasure);
          if (!forMeasure)
          {
            mHeader = wHeader;
          }
        }
        wPresenter = wHeader;
        wElement = wHeader;
      }
      else
      {
        var wList = cell.IsEditing ? mFreeEditElements : mFreeElements;
        if (!forMeasure && wList.Count > 0)
        {
          wPresenter = wList[wList.Count - 1];
          wElement = wList[wList.Count - 1];
          wList.RemoveAt(wList.Count - 1);

          if (mIsTextColumn)
          {
            if (cell.IsEditing)
            {
              ((TextBox)((VirtualGridCell)wPresenter).Content).SetBinding(TextBox.TextProperty, ((DataGridTextColumn)Column).Binding);
            }
            else
            {
              ((TextBlock)((VirtualGridCell)wPresenter).Content).SetBinding(TextBlock.TextProperty, ((DataGridTextColumn)Column).Binding);
            }
          }
        }
        else
        {
          var wCell = new VirtualGridCell();
          wCell.SetBinding(VirtualGridCell.StyleProperty, new Binding("CellStyle")
          {
            Source = Grid
          });

          wPresenter = wCell;
          wElement = wCell;

          if (cell.Column.Column is DataGridTemplateColumn)
          {
            var wColumn = (DataGridTemplateColumn)Column;

            wCell.SetBinding(ContentPresenter.ContentProperty, new Binding("Cell.Data")
            {
              Source = wCell
            });

            if (wColumn.CellStyle != null)
            {
              wCell.SetBinding(VirtualGridCell.StyleProperty, new Binding("CellStyle")
              {
                Source = wColumn
              });
            }

            if (cell.IsEditing && (wColumn.CellEditingTemplate != null || wColumn.CellEditingTemplateSelector != null))
            {
              wCell.SetBinding(VirtualGridCell.ContentTemplateProperty, new Binding("CellEditingTemplate")
              {
                Source = wColumn
              });
              wCell.SetBinding(VirtualGridCell.ContentTemplateSelectorProperty, new Binding("CellEditingTemplateSelector")
              {
                Source = wColumn
              });
            }
            else
            {
              wCell.SetBinding(VirtualGridCell.ContentTemplateProperty, new Binding("CellTemplate")
              {
                Source = wColumn
              });
              wCell.SetBinding(VirtualGridCell.ContentTemplateSelectorProperty, new Binding("CellTemplateSelector")
              {
                Source = wColumn
              });
            }
          }
          else if (mIsTextColumn)
          {
            var wColumn = (DataGridTextColumn)Column;

            if (cell.IsEditing)
            {
              var wControl = new TextBox();
              wControl.IsVisibleChanged += TextBox_Loaded;
              wControl.SetBinding(TextBox.TextProperty, wColumn.Binding);
              wCell.Content = wControl;
            }
            else
            {
              var wControl = new TextBlock();
              wControl.SetBinding(TextBlock.TextProperty, wColumn.Binding);
              wCell.Content = wControl;
            }
          }
          else
          {
            throw new NotImplementedException();
          }

          if (!forMeasure)
          {
            BindCellPosition(wElement);
          }
          BindCellData(wElement);
        }
      }

      ((FrameworkElement)wPresenter).Visibility = Visibility.Visible;

      if (!forMeasure)
      {
        if (wElement.Parent == null || wElement.Tag == null || ((CellVisualData)wElement.Tag).Column != this || wIsHeader)
        {
          Grid.AddElement(cell, wElement);
        }
      }

      wPresenter.Cell = cell;

      return wElement;
    }

    private void TextBox_Loaded(object sender, DependencyPropertyChangedEventArgs e)
    {
      var wTextBox = (TextBox)sender;

      wTextBox.Dispatcher.InvokeAsync(() =>
      {
        wTextBox.Focus();
        if (wTextBox.Text != null)
        {
          wTextBox.Select(wTextBox.Text.Length, 0);
        }
      }, System.Windows.Threading.DispatcherPriority.Loaded);
    }

    internal void CellMeasured(CellVisualData cell)
    {
      if (!IsMeasured)
      {
        var wWidth = Width;
        if (double.IsNaN(wWidth) || cell.MeasuredSize.Value.Width > wWidth)
        {
          wWidth = cell.MeasuredSize.Value.Width;
        }
        UpdateWidth(wWidth);
        //IsMeasured = mCells.Count == Grid.RowDatas.Count && mCells.All(a => a.IsMeasured);
      }

      if (cell.IsMeasured)
      {
        IsAllMeasured = mCells.All(a => a.IsMeasured || (a.Column.IsMeasured && a.Row.IsMeasured));
      }
    }

    private void UpdateWidth(double width)
    {
      if (!double.IsNaN(MinWidth) && MinWidth > width)
      {
        width = MinWidth;
      }
      if (!double.IsNaN(MaxWidth) && MaxWidth < width)
      {
        width = MaxWidth;
      }
      if (mWidth != width)
      {
        mWidth = width;
        NotifyPropertyChanged("Width");
      }
    }

    public void AutoSize()
    {
      var wCells = mCells.Where(w => w.IsMeasured).ToList();
      if (wCells.Count > 0)
      {
        UpdateWidth(wCells.Max(m => m.MeasuredSize.Value.Width));
      }
      else
      {
        UpdateWidth(0);
      }
    }

    private VirtualGridColumnHeader GetHeaderElement(bool forMeasure)
    {
      var wColumnHeader = new VirtualGridColumnHeader();
      if (Column.HeaderTemplate != null)
      {
        wColumnHeader.ContentTemplate = Column.HeaderTemplate;
      }
      else if (Grid.ColumnHeaderTemplate != null)
      {
        wColumnHeader.ContentTemplate = Grid.ColumnHeaderTemplate;
      }

      if (Column.HeaderTemplateSelector != null)
      {
        wColumnHeader.ContentTemplateSelector = Column.HeaderTemplateSelector;
      }
      else if (Grid.ColumnHeaderTemplateSelector != null)
      {
        wColumnHeader.ContentTemplateSelector = Grid.ColumnHeaderTemplateSelector;
      }

      if (Column.HeaderStringFormat != null)
      {
        wColumnHeader.ContentStringFormat = Column.HeaderStringFormat;
      }

      if (Column.Header != null)
      {
        wColumnHeader.Content = Column.Header;
      }

      if (Column.HeaderStyle != null)
      {
        wColumnHeader.Style = Column.HeaderStyle;
      }
      else if (Grid.ColumnHeaderStyle != null)
      {
        wColumnHeader.Style = Grid.ColumnHeaderStyle;
      }

      wColumnHeader.SetBinding(VirtualGridColumnHeader.IsLeftGripperVisibileProperty, new Binding("IsLeftGripperVisibile") { Source = this });
      wColumnHeader.SetBinding(VirtualGridColumnHeader.IsRightGripperVisibileProperty, new Binding("IsRightGripperVisibile") { Source = this });

      if (!forMeasure)
      {
        BindCellPosition(wColumnHeader);
      }
      BindCellData(wColumnHeader);

      return wColumnHeader;
    }

    private void BindCellPosition(FrameworkElement wElement)
    {
      wElement.SetBinding(Canvas.TopProperty, new Binding("Cell.Top")
      {
        Source = wElement
      });
      wElement.SetBinding(FrameworkElement.HeightProperty, new Binding("Cell.Height")
      {
        Source = wElement
      });
      wElement.SetBinding(Canvas.LeftProperty, new Binding("Cell.Left")
      {
        Source = wElement
      });
      wElement.SetBinding(FrameworkElement.WidthProperty, new Binding("Cell.Width")
      {
        Source = wElement
      });
    }
    private void BindCellData(FrameworkElement wElement)
    {
      wElement.SetBinding(FrameworkElement.DataContextProperty, new Binding("Cell.Data")
      {
        Source = wElement
      });
    }

    public void FreeElement(VirtualGridCell element, bool isEditing)
    {
      var wList = isEditing ? mFreeEditElements : mFreeElements;

      element.Cell = null;
      element.Visibility = Visibility.Collapsed;

      wList.Add(element);
    }

    public void FreeElement(VirtualGridColumnHeader element)
    {
      Grid.RemoveElement(element);
    }

    public void FreeElement(VirtualGridRowHeader element)
    {
      Grid.RemoveElement(element);
    }

    public void ReleaseElements()
    {
      if (mFreeEditElements.Count > 0)
      {
        ReleaseElementsFromList(mFreeEditElements);
      }
      if (mFreeElements.Count > 0)
      {
        ReleaseElementsFromList(mFreeElements);
      }
    }

    private void ReleaseElementsFromList(List<VirtualGridCell> list)
    {
      var wMax = Math.Max(Grid.ColumnDatas.Count, Grid.VisibleRows) * 2;

      if (list.Count > wMax)
      {
        foreach (var wElement in list.Skip(wMax))
        {
          Grid.RemoveElement(wElement);
        }
        list.RemoveRange(wMax, list.Count - wMax);
      }
    }

    private Brush mBackground;

    public Brush Background
    {
      get { return mBackground; }
      set
      {
        if (mBackground == value) return;

        mBackground = value;
        NotifyPropertyChanged();
      }
    }

    private int mIndex;

    public int Index
    {
      get { return mIndex; }
      set
      {
        if (mIndex == value) return;

        mIndex = value;
        NotifyPropertyChanged();
      }
    }

    private List<CellVisualData> mCells = new List<CellVisualData>();

    internal void AddCell(CellVisualData cell)
    {
      mCells.Add(cell);
      IsAllMeasured = IsAllMeasured && cell.IsMeasured;
    }

    internal void RemoveCell(CellVisualData cell)
    {
      mCells.Remove(cell);
      if (!cell.IsMeasured)
      {
        IsAllMeasured = mCells.All(a => a.IsMeasured);
      }
    }

    public override string ToString()
    {
      return "Header: " + (Column.Header ?? "[NULL]") + ", " +
             "Left" + ": " + Left + ", " +
             "IsVisible" + ": " + IsVisible + ", " +
             "IsFrozen" + ": " + IsFrozen;
    }

  }
}
